# System Design Tutor — download package

This ZIP contains **two equivalent data layouts**, plus an archived copy of the supplied preparation plan:

- `native-skill/system-design-tutor/`: conventional directory-based skill with **one** manifest (`SKILL.md`) and references in `modules/`, `anchors/` and `concepts/`. It can be zipped independently for systems that support the Agent Skills standard.
- `chatgpt-project-flat/`: all reference files at one level, with **identical exact base filenames** and a `PROJECT_INSTRUCTIONS.txt` snippet. Use this for ChatGPT Projects that do not preserve folders in Project Sources.
- `source-archive/`: original roadmap for traceability. It is not a mandatory runtime reference.

## Native skill setup

Use the inner `system-design-tutor/` directory as the skill. See your target agent's skill installation path and registration instructions. `SKILL.md` has YAML frontmatter name + description, a routing contract, and file-level progressive loading. It is the **only** SKILL.md file within this native bundle.

The standalone download `system-design-tutor-native-skill.zip` has precisely one top-level `system-design-tutor/` folder for skill-zip import formats.

## ChatGPT Projects setup (flat files)

1. Create a ChatGPT Project.
2. Open Project settings and paste the text from `PROJECT_INSTRUCTIONS.txt` into **Project Instructions**.
3. Upload `SKILL.md`, `sdt-catalog.md`, all eight `sdt-module-*.md` files and `sdt-method-template.md` as Project Sources. Add the relevant `sdt-anchor-*.md` and `sdt-concept-*.md` files as needed; upload all if your plan's source limits allow.
4. Request e.g. **"Design a card authorization system using the tutor"**. The rules find the module by **filename**, and only the relevant anchor should be loaded when present.

**Important product distinction:** Uploading Markdown files to a ChatGPT Project does **not** register an executable native skill and does not guarantee exact-file retrieval. Project Instructions encourage selective context use. If a reference was not retrieved, the tutor must say so and avoid pretending it has read it. Projects' file limits vary by plan.

## Routing examples

| User request | Foldered reference(s) | Flat reference(s) |
|---|---|---|
| Payment gateway | `references/modules/sdt-module-02-payments.md` + `references/anchors/sdt-anchor-05-payment-gateway.md` | `sdt-module-02-payments.md` + `sdt-anchor-05-payment-gateway.md` |
| WhatsApp-style chat | `references/modules/sdt-module-03-scalable-apps.md` + `references/anchors/sdt-anchor-10-chat.md` | `sdt-module-03-scalable-apps.md` + `sdt-anchor-10-chat.md` |
| Explain CDC | `references/modules/sdt-module-05-data-streaming.md` + optionally `references/concepts/sdt-concept-02-messaging-workflows.md` | `sdt-module-05-data-streaming.md` + optionally `sdt-concept-02-messaging-workflows.md` |
| Compare Saga vs ACID | `references/modules/sdt-module-04-workflows.md` + `references/concepts/sdt-concept-01-correctness.md` | Same file base names with no folders |

## Learning behavior

Preserves the input roadmap's 73 numbered cases, eight modules, twenty connected foundation concepts, sixteen full-depth anchor cases, decision-first eleven-step method, and no-assessment learning preference. It is **general-purpose** with a financial-services/Solution Architect emphasis, not a representation of any company's private interview question bank.

Detailed worked anchors are educational starting designs with labeled assumptions. They do not claim verified vendor behavior, exact SLA levels, or applicability of specific regulatory requirements.

## Files and maintenance

- Edit the matching stable-base-name reference in **both** distributions if maintaining manually, or use one authoritative source and copy it to both outputs.
- Never rename case/module/anchor filenames without updating `SKILL.md`, `sdt-catalog.md`, and Project Instructions.
- Route using filename when a folder is unavailable; avoid fallback to loading every document.
- The manifest and file mapping can be audited in `file-manifest.json` in the outer package.

Official platform documentation (retrieved at packaging time):

- OpenAI Agent Skills: https://developers.openai.com/api/docs/guides/tools-skills
- ChatGPT Projects: https://help.openai.com/en/articles/10169521-projects-in-chatgpt
