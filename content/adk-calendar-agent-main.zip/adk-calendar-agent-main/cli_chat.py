#!/usr/bin/env python3
"""
Terminal chat loop for the Calendar Agent.
Run: python cli_chat.py
Requires the FastAPI server to be running on localhost:8000.
"""
import asyncio, httpx, webbrowser, time

BASE = "http://localhost:8000"
COOKIE_JAR = {}   # persist session cookie across requests

async def chat(message: str) -> dict:
    async with httpx.AsyncClient(base_url=BASE, cookies=COOKIE_JAR) as client:
        r = await client.post("/chat", json={"message": message})
        # Persist any Set-Cookie headers (session cookie)
        COOKIE_JAR.update(dict(r.cookies))
        return r.json()

def wait_for_auth():
    """Poll until the server session has Google credentials."""
    print("  [cli] Waiting for you to complete the OAuth flow in browser", end="", flush=True)
    for _ in range(120):   # wait up to 2 minutes
        time.sleep(1)
        print(".", end="", flush=True)
        try:
            r = httpx.get(f"{BASE}/auth/status", cookies=COOKIE_JAR)
            if r.json().get("authenticated"):
                print(" ✓")
                return True
        except Exception:
            pass
    print(" timed out.")
    return False

async def main():
    print("\n📅 Calendar Agent — CLI Chat")
    print("Type your question. Type 'quit' to exit.\n")

    pending = None

    while True:
        if pending:
            user_input = pending
            pending = None
            print(f"  [resuming] {user_input}")
        else:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                break

        if not user_input or user_input.lower() in ("quit", "exit"):
            break

        result = await chat(user_input)

        if result.get("auth_required"):
            print("\nAgent: 🔐 Calendar access required. Opening browser for sign-in…")
            webbrowser.open(f"{BASE}/login")
            if wait_for_auth():
                pending = user_input   # replay after auth
                continue
            else:
                print("Agent: Auth timed out. Please try again.")
        else:
            print(f"\nAgent: {result.get('reply', 'No response')}\n")

if __name__ == "__main__":
    asyncio.run(main())