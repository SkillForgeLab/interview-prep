from agent.calendar_agent import create_calendar_agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai.types import Content, Part

_session_svc = InMemorySessionService()   # shared across requests

# One agent instance per user_id — avoids re-creating on every request.
_agent_cache: dict[str, object] = {}


def _get_agent(user_id: str):
    if user_id not in _agent_cache:
        _agent_cache[user_id] = create_calendar_agent(user_id)
    return _agent_cache[user_id]


AUTH_SENTINEL = "__AUTH_REQUIRED__"

async def run_agent(user_id: str | None, message: str) -> dict:
    """
    Run the agent for a given user + message.
    Returns:
        {"reply": "..."}           — normal response
        {"auth_required": True}    — agent needs credentials, caller must auth

    Key change: we no longer short-circuit when user_id is None.
    The agent runs freely for any message. Auth is only demanded when
    a calendar tool is actually invoked and finds no credentials.
    If user_id is None the tools will return AUTH_SENTINEL; the agent
    echoes it back; we detect it here and return auth_required.
    """
    # Use a stable placeholder so InMemorySessionService always gets a string key.
    # Anonymous users get a shared "anon" session — fine since they have no
    # calendar data and will be asked to auth before anything sensitive runs.
    effective_uid = user_id or "anon"

    agent = _get_agent(effective_uid)

    # Reuse or create a session keyed by user_id (preserves conversation history)
    sessions = await _session_svc.list_sessions(
        app_name="calendar_agent", user_id=effective_uid
    )
    if sessions.sessions:
        session_id = sessions.sessions[0].id
    else:
        sess = await _session_svc.create_session(
            app_name="calendar_agent", user_id=effective_uid
        )
        session_id = sess.id

    runner = Runner(
        agent=agent,
        app_name="calendar_agent",
        session_service=_session_svc,
    )

    reply_parts = []
    async for event in runner.run_async(
        user_id=effective_uid,
        session_id=session_id,
        new_message=Content(role="user", parts=[Part(text=message)]),
    ):
        if event.is_final_response() and event.content:
            for part in event.content.parts:
                if part.text:
                    reply_parts.append(part.text)

    reply = " ".join(reply_parts).strip()

    # Auth sentinel: agent was instructed to echo AUTH_SENTINEL verbatim
    # when a tool returns it — we intercept it here before it reaches the UI.
    if AUTH_SENTINEL in reply:
        return {"auth_required": True}

    return {"reply": reply or "Sorry, I could not get a response."}