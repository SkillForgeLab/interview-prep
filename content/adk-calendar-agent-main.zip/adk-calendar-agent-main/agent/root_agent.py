# agent/root_agent.py
# Entry point for: adk web
# For local dev only — user_id is a placeholder.
# The tool will return __AUTH_REQUIRED__ if no Google creds exist for this id,
# which you can then trigger manually via the FastAPI auth flow.

from agent.calendar_agent import create_calendar_agent

DEV_USER_ID = "adk-web-dev-user"

root_agent = create_calendar_agent(DEV_USER_ID)

