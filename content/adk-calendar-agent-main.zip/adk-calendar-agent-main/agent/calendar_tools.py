from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from auth.token_store import get_google_credentials
from datetime import datetime, timezone


class AuthRequiredError(Exception):
    pass


def _service(user_id: str):
    creds = get_google_credentials(user_id)
    # The __AUTH_REQUIRED__ sentinel
    # travels from tool → agent reply → runner → FastAPI → frontend.
    # Each layer passes it up without modification
    # until the frontend intercepts it and starts the auth flow.
    if not creds:
        raise AuthRequiredError()
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
    return build("calendar", "v3", credentials=creds)


def get_upcoming_events(user_id: str, max_results: int = 10) -> list[dict]:
    svc = _service(user_id)
    now = datetime.now(timezone.utc).isoformat()
    items = svc.events().list(
        calendarId="primary", timeMin=now,
        maxResults=max_results, singleEvents=True, orderBy="startTime"
    ).execute().get("items", [])
    return [
        {
            "summary": e.get("summary", "No title"),
            "start": e["start"].get("dateTime") or e["start"].get("date"),
            "end": e["end"].get("dateTime") or e["end"].get("date"),
        }
        for e in items
    ]


def is_user_free(user_id: str, date_str: str) -> str:
    events = get_upcoming_events(user_id, max_results=50)
    day = [e for e in events if e["start"].startswith(date_str)]
    if not day:
        return f"You are free on {date_str} — no events found."
    lines = "\n".join(f"  • {e['summary']} at {e['start']}" for e in day)
    return f"You have {len(day)} event(s) on {date_str}:\n{lines}"
