from google.adk.agents import Agent
from google.adk.tools import BaseTool
from google.adk.tools.tool_context import ToolContext
from typing import Optional, Dict, Any
from agent.calendar_tools import get_upcoming_events, is_user_free, AuthRequiredError
from auth.token_store import has_google_credentials

AUTH_SENTINEL = "__AUTH_REQUIRED__"


def create_calendar_agent(user_id: str) -> Agent:
    """
    user_id may be "anon" for unauthenticated users.
    The tools handle that gracefully by returning AUTH_SENTINEL.
    """

    def tool_get_events(max_results: int = 5) -> str:
        """Get the user's upcoming calendar events."""
        # Auth check happens here — only when the LLM decides to call this tool.
        # A greeting like "Hi" will never reach this point.
        if not user_id or not has_google_credentials(user_id):
            return AUTH_SENTINEL
        try:
            events = get_upcoming_events(user_id, max_results)
            # Silent token refresh is handled inside get_upcoming_events →
            # _service() which calls creds.refresh(Request()) when expired.
        except AuthRequiredError:
            return AUTH_SENTINEL
        if not events:
            return "No upcoming events found."
        return "\n".join(
            f"{i+1}. {e['summary']} — {e['start']}"
            for i, e in enumerate(events)
        )

    def tool_check_availability(date: str) -> str:
        """Check if the user is free on a given date (YYYY-MM-DD)."""
        if not user_id or not has_google_credentials(user_id):
            return AUTH_SENTINEL
        try:
            # Silent token refresh handled in is_user_free → _service()
            return is_user_free(user_id, date)
        except AuthRequiredError:
            return AUTH_SENTINEL

    def _check_auth_sentinel(
        tool: BaseTool,
        args: Dict[str, Any],
        tool_context: ToolContext,
        tool_response: Any,
    ) -> Optional[Any]:
        """
        after_tool_callback — intercepts AUTH_SENTINEL before the LLM sees it.

        ADK passes tool_response as the raw return value of the tool function
        (a plain str for FunctionTools), not a wrapped dict.

        Returning the sentinel string unchanged triggers the agent instruction
        which tells the LLM to echo it verbatim — runner.py then catches it.
        """
        if isinstance(tool_response, str) and AUTH_SENTINEL in tool_response:
            return AUTH_SENTINEL   # pass through unchanged; agent echoes it
        return None  # normal path — let ADK process the response as usual

    return Agent(
        name="calendar_assistant",
        model="gemini-2.5-flash",
        description="Read-only conversational calendar assistant.",
        instruction=(
            "You are a helpful calendar assistant. You can answer general questions "
            "and have a normal conversation without needing any tools.\n\n"
            "You ONLY need to call a tool when the user explicitly asks about their "
            "calendar, schedule, events, or availability.\n\n"
            "If a tool returns the exact text '__AUTH_REQUIRED__', "
            "respond ONLY with that exact string and nothing else. "
            "Do not apologise, explain, or add any other text — the frontend handles it."
        ),
        tools=[tool_get_events, tool_check_availability],
        after_tool_callback=_check_auth_sentinel,
    )