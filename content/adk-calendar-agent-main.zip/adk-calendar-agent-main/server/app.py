import os, uvicorn
from pathlib import Path
from dotenv import load_dotenv

from fastapi import FastAPI, Request, Cookie
from fastapi.responses import RedirectResponse, JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from itsdangerous import URLSafeSerializer

from auth.entra_oidc import get_entra_login_flow, exchange_entra_code
from auth.google_oauth import get_google_auth_flow, exchange_google_code
from auth.token_store import save_google_credentials, has_google_credentials

from agent.runner import run_agent

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent  # always points to server/

app = FastAPI(title="ADK Calendar Agent")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

signer = URLSafeSerializer(os.getenv("APP_SECRET_KEY"), salt="session")

# Server-side session store — keyed by a random session_id in the cookie.
# Holds: { "uid": str, "entra_flow": dict, "google_flow": Flow }
# Replace with Redis in production.
_session_store: dict[str, dict] = {}


def make_session(data: dict) -> str:
    """Create a signed cookie value embedding a session_id."""
    import secrets
    sid = secrets.token_urlsafe(16)
    _session_store[sid] = data
    return signer.dumps({"sid": sid})


def read_session(token: str) -> dict | None:
    """Decode the cookie and return the server-side session dict, or None."""
    try:
        sid = signer.loads(token)["sid"]
        return _session_store.get(sid)
    except Exception:
        return None


def get_user_id(token: str | None) -> str | None:
    if not token:
        return None
    sess = read_session(token)
    return sess.get("uid") if sess else None


# ── Serve chat UI ──────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root():
    with open("static/chat.html") as f:
        return f.read()


# ── Auth entry point ───────────────────────────────────────────
@app.get("/login")
async def login():
    """Leg 1: initiate Entra auth code flow, store flow in session."""
    entra_flow = get_entra_login_flow()  # returns flow dict with auth_uri + verifier
    cookie_val = make_session(
        {"entra_flow": entra_flow})  # persist flow server-side
    response = RedirectResponse(entra_flow["auth_uri"])
    response.set_cookie(
        "session", cookie_val,
        httponly=True, samesite="lax", max_age=3600
    )
    return response


# ── Entra callback → kick off Google OAuth ────────────────────
@app.get("/auth/entra/callback")
async def entra_callback(
        request: Request,
        session: str = Cookie(default=None)):
    sess = read_session(session) if session else None
    if not sess or "entra_flow" not in sess:
        return JSONResponse({"error": "Session expired. Please try again."},
                            status_code=400)

    # Pass the full query string as auth_response (MSAL validates state + code)
    auth_response = dict(request.query_params)
    identity = exchange_entra_code(sess["entra_flow"], auth_response)
    user_id = identity["user_id"]

    # Start Google OAuth leg — store google_flow in session alongside user_id
    google_flow, google_url = get_google_auth_flow(state=user_id)
    sess.update(
        {"uid": user_id, "google_flow": google_flow, "entra_flow": None})

    response = RedirectResponse(google_url)
    response.set_cookie(
        "session", make_session(sess),
        httponly=True, samesite="lax", max_age=3600
    )
    return response


# ── Google callback → store token → return to chat ────────────
@app.get("/auth/google/callback")
async def google_callback(code: str, state: str,
                          session: str = Cookie(default=None)):
    """Leg 3: exchange Google code using the persisted flow object."""
    sess = read_session(session) if session else None
    if not sess or "google_flow" not in sess or not sess["google_flow"]:
        return JSONResponse({"error": "Session expired. Please try again."},
                            status_code=400)

    creds = exchange_google_code(sess["google_flow"], code)
    user_id = state  # Entra user_id passed as state
    save_google_credentials(user_id, creds)

    # Clean up flow objects, keep only uid
    sess.update({"google_flow": None})
    response = RedirectResponse("/?resume=1")
    response.set_cookie(
        "session", make_session(sess),
        httponly=True, samesite="lax", max_age=3600
    )
    return response


@app.get("/auth/status")
async def auth_status(session: str = Cookie(default=None)):
    user_id = get_user_id(
        session)  # read_session + uid extraction, both defined above in this file
    authed = bool(user_id and has_google_credentials(user_id))
    return {"authenticated": authed}


# ── Chat endpoint ──────────────────────────────────────────────
@app.post("/chat")
async def chat(request: Request, session: str = Cookie(default=None)):
    body = await request.json()
    message = body.get("message", "").strip()

    if not message:
        return JSONResponse({"error": "empty message"}, status_code=400)

    user_id = get_user_id(session)  # None if not yet authed
    result = await run_agent(user_id=user_id, message=message)

    if result.get("auth_required"):
        return JSONResponse({"auth_required": True}, status_code=200)

    return JSONResponse({"reply": result["reply"]})


if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
