### Step 1 — Register App in Microsoft Entra ID

### Step 2 — Create GCP OAuth 2.0 Credentials

### Step 3 — Project Structure

```
adk-calendar-agent/
├── .env                        # secrets (never commit!)
├── requirements.txt
├── google_client_secret.json   # from GCP console
│
├── auth/
│   ├── entra_oidc.py           # Leg 1: Entra ID OIDC login
│   ├── google_oauth.py         # Leg 2: Google delegated token
│   └── token_store.py          # In-memory token store (per user)
│
├── agent/
│   ├── calendar_agent.py       # Google ADK agent definition
│   ├── calendar_tools.py       # ADK tools: get_events, is_free
│   └── prompts.py              # System prompt
│
├── server/
│   └── app.py                  # FastAPI server (auth callbacks + agent endpoint)
│
└── README.md
```

## Combine ADK Web with your FastAPI auth server

> ADK Web and your FastAPI server run on different ports. The typical dev
> workflow is:

### Terminal 1 — ADK Web UI (chat + traces)

```shell
adk web --port 8001
```

### Terminal 2 — FastAPI (OAuth callbacks)

```shell
uv run python app.py # runs on port 8000
```

### Auth flow for ADK Web:

1. Chat in ADK Web → agent returns __AUTH_REQUIRED__
2. Manually open http://localhost:8000/login in browser
3. Complete Entra + Google consent
4. Credentials stored in token_store for DEV_USER_ID
5. Return to ADK Web, retry your question — now it works