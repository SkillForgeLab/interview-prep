# In production, replace with Redis or a database
_store: dict[str, object] = {}  # user_id -> google Credentials

def save_google_credentials(user_id: str, creds) -> None:
    _store[user_id] = creds

def get_google_credentials(user_id: str):
    return _store.get(user_id)

def has_google_credentials(user_id: str) -> bool:
    return user_id in _store