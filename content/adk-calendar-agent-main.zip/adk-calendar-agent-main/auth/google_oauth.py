import os

from pathlib import Path
from dotenv import load_dotenv

from google_auth_oauthlib.flow import Flow

load_dotenv()

SCOPES = ["https://www.googleapis.com/auth/calendar.readonly"]

BASE_DIR = Path(__file__).resolve().parent  # points to auth/

def _make_flow() -> Flow:
    return Flow.from_client_secrets_file(
        str(BASE_DIR.parent / "secrets" / "google_client_secret.json"),
        scopes=SCOPES,
        redirect_uri=os.getenv("GOOGLE_REDIRECT_URI")
    )


def get_google_auth_flow(state: str)-> tuple[Flow, str]:
    """Leg 2: Build Google OAuth consent URL. Returns (flow, auth_url).
    The caller must persist the flow object in session for use in
    exchange_google_code. """
    flow = _make_flow()
    auth_url, _ = flow.authorization_url(
        access_type="offline",  # request refresh token
        include_granted_scopes="true",
        state=state,  # carry Entra user_id through the flow
        code_challenge_method="S256",  # enable PKCE
    )
    return flow, auth_url


def exchange_google_code(flow: Flow, code: str) -> object:
    """Exchange Google code for delegated credentials (access + refresh token).
       Must receive the same flow object from get_google_auth_url
       (contains the code_verifier).
    """
    flow.fetch_token(code=code)
    return flow.credentials  # google.oauth2.credentials.Credentials object
