import msal, os
from dotenv import load_dotenv

load_dotenv()


def get_entra_app():
    return msal.ConfidentialClientApplication(
        client_id=os.getenv("ENTRA_CLIENT_ID"),
        client_credential=os.getenv("ENTRA_CLIENT_SECRET"),
        authority=f"https://login.microsoftonline.com/{os.getenv('ENTRA_TENANT_ID')}"
    )


def get_entra_login_flow() -> dict:
    """
    Leg 1: Initiate the auth code flow.

    Returns a flow dict that must be stored in the user's session
    and passed to exchange_entra_code() later.
    """
    app = get_entra_app()
    # For OIDC-only (id token, no access token), pass empty scopes.
    # Passing ["openid", "profile", "email"] explicitly raises an error in MSAL.
    return app.initiate_auth_code_flow(
        scopes=[],
        redirect_uri=os.getenv("ENTRA_REDIRECT_URI"),
    )
    # Callers redirect the user to flow["auth_uri"]


def exchange_entra_code(flow: dict, auth_response: dict) -> dict:
    """Complete the flow. Returns user identity claims.

    Args:
        flow: The dict returned by get_entra_login_flow(), retrieved from session.
        auth_response: The query-string params received at the redirect URI,
                       e.g. {"code": "...", "state": "...", "session_state": "..."}.
    """
    app = get_entra_app()
    result = app.acquire_token_by_auth_code_flow(
        auth_code_flow=flow,
        auth_response=auth_response,
    )
    if "id_token_claims" not in result:
        raise ValueError(
            f"Entra auth failed: {result.get('error_description')}")

    claims = result["id_token_claims"]
    return {
        "user_id": claims["oid"],  # Entra object ID (stable unique ID)
        "email": claims.get("email") or claims.get("preferred_username"),
        "name": claims.get("name", ""),
    }
