# Prompt Pack Usage

## What never changes
- combined_contract.yaml
- base.yaml

## What changes for a new POC
- Pick exactly one file from use_cases/
  - use_cases/travel_planner.yaml
  - use_cases/finance_copilot.yaml (example)

## What changes per stage
- Pick exactly one file from stages/
  - stages/stage_00.yaml ... stages/stage_12.yaml

## Assembly method (copy/paste, bulletproof)
1) Copy the full contents of combined_contract.yaml
2) Copy the full contents of base.yaml.
3) Append the full contents of the chosen use case file.
4) Append the full contents of the chosen stage file.
5) Paste the combined YAML as your “MASTER PROMPT” in ChatGPT.

Order must be:
1) combined_contract.yaml
2) base.yaml 
3) use case file
4) stage file

## Stage defaults
- If you want “default Stage 0 when unspecified”, always assemble with stage_00.yaml.
- When you want a specific stage, assemble with that stage file.

## Rules of editing
- Do not edit base.yaml.
- For a new POC, only edit a copy of a use case file.
- For new stages, only edit the stage file.

## Quick sanity check before you use a combined prompt
- Exactly one USE_CASE block exists.
- Exactly one STAGE block exists.
- STAGE.current_stage_id matches the stage file name.
