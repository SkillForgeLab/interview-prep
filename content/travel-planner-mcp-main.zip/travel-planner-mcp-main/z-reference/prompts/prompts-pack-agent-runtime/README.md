
You **do not** run files individually.  
You **assemble them once** into a single Stage Runner prompt and execute that.

---

## Files Involved

| File                                | Purpose                                                    |
|-------------------------------------|------------------------------------------------------------|
| `context-anchor.yaml`               | Defines role, audience, output rules, memory reinforcement |
| `common-design.yaml`                | Shared architecture principles & non-negotiables           |
| `governance.yaml`                   | Invariants, drift checks, README rules, completion gates   |
| `dependency-graph.yaml`             | Defines stages → required controls → required artifacts    |
| `prompt-pack-canonical-format.yaml` | Canonical execution wrapper + completion gate logic        |

---

## Step-by-Step: Running a Stage

### Step 1 — Choose the Stage
Decide which stage you are executing (example: `stage-02`).

> You run **one stage at a time**.  
> Stages never auto-advance.

---

### Step 2 — Find the Stage Contract
Open `dependency-graph.yaml` and locate **only** the section for your stage.

You are looking for:
- Required controls
- Required artifacts
- Definition of Done / completion gates

👉 You will paste **only this stage’s section**, not the entire graph.

---

### Step 3 — Assemble the Stage Runner Prompt

Create **one single prompt message** (one ChatGPT input) using the
**Stage Runner skeleton**.

Paste content in this **exact order**:

1. `prompt-pack-canonical-format.yaml`
2. `context-anchor.yaml`
3. `common-design.yaml`
4. `governance.yaml`
5. Stage section from `dependency-graph.yaml`
6. Repo tree / inputs / constraints

⚠️ Order matters.  
The canonical wrapper must come first.

---

### Step 4 — Provide Inputs (Optional but Recommended)

Include:
- Repository tree (`tree -L 4`)
- Existing files to be modified
- Known errors or constraints

Example constraints:
- No placeholders or stubs
- Stop after this stage
- Output drift-fix patches if misaligned

---

### Step 5 — Execute the Stage

Send the assembled Stage Runner prompt.

The model will:
- Execute **only the selected stage**
- Produce all required artifacts
- Enforce governance rules
- Run completion gates
- Stop at the stage boundary

---

## Expected Output Structure

A successful stage execution will include:

- ✅ All artifacts defined in the stage contract
- ✅ End-to-end execution flow
- ✅ Consolidated sequence diagrams (happy + failure paths)
- ✅ `README.md` updates with **macOS (Intel) run instructions**
- ✅ Explicit gate evaluation

The response will end with:

- GATE_STATUS: PASS | FAIL
- NEXT_ACTION: <what to do next>

---

```
## What If a Gate Fails?

If any completion gate fails, the output **must** include:

1. Why the gate failed  
2. Exact drift-fix patch list (file-by-file, line-level)  
3. Rerun instructions  

No next stage is allowed until gates pass.

---

## Common Mistakes (Avoid These)

❌ Running multiple stages in one prompt  
❌ Pasting files in random order  
❌ Skipping governance.yaml  
❌ Letting the model “continue to next stage”  
❌ Treating this like ad-hoc prompting  

This system is **deterministic by design**.

```
---

## Recommended Workflow
```yaml
Select Stage
↓
Extract Stage Contract
↓
Assemble Stage Runner Prompt
↓
Execute Stage
↓
Check Gates
↓
Commit Artifacts
↓
Proceed to Next Stage (new prompt)
```

---

```
## Summary (TL;DR)

- You run **stages**, not files
- You send **one composed prompt per stage**
- Canonical wrapper first, anchors next, stage contract last
- Completion gates decide whether you can move on

This is intentional.  
It’s how you get **repeatable, enterprise-grade agent execution**.

```

---
## Diagram version of README.md

---

```mermaid
flowchart TB
  %% ============================================================
  %% How to Run a Stage — Diagram (Mermaid)
  %% ============================================================

  A([Start]) --> B[Pick a stage ID<br/>e.g., stage-02]

  B --> C[Open dependency-graph.yaml<br/>Locate ONLY the selected stage section]
  C --> C1[Extract:<br/> required controls<br/> required artifacts<br/> definition-of-done / gates]

  C1 --> D[Assemble ONE Stage Runner prompt message<br/>in the required order]
  
  subgraph ORDER[Paste in this exact order]
    D1[1. prompt-pack-canonical-format.yaml<br/><i>Canonical executionwrapper + completion gates</i>]
    D2[2. context-anchor.yaml<br/><i>Role + audience + output contract</i>]
    D3[3. common-design.yaml<br/><i>Architecture rules + non-negotiables</i>]
    D4[4. governance.yaml<br/><i>Invariants + drift checks + README rules</i>]
    D5[5. Stage contract slice, from dependency-graph.yaml<br/><i>What to produce now</i>]
    D6[6. Inputs: repo tree / files / errors / constraints]
    D1 --> D2 --> D3 --> D4 --> D5 --> D6
  end

  D --> ORDER

  ORDER --> E[Execute the stage<br/>, send the assembled prompt]

  E --> F[Model produces artifacts + runs gates]
  F --> G{GATE_STATUS?}

  G -->|PASS| H[Commit artifacts<br/>Proceed to next stage using a NEW prompt]
  G -->|FAIL| I[Review gate failures]
  I --> J[Apply drift-fix patch list<br/>, exact file edits]
  J --> K[Rerun the SAME stage<br/>, new Stage Runner prompt]
  K --> E

  %% ============================================================
  %% Outputs expectations
  %% ============================================================
  F --> O1[Must include:<br/> required artifacts, stage<br/> end-to-end execution flow<br/> consolidated sequence diagrams, happy+failure<br/> README.md updates incl. macOS_Intel run steps]



  %% ============================================================
  %% Guardrails
  %% ============================================================
  L[[Common Mistakes]] --> L1[ X Multiple stages in one prompt]
  L --> L2[X Random paste order]
  L --> L3[X Skipping governance.yaml]
  L --> L4[X Proceeding after FAIL]
  L --> L5[X Missing mandatory artifacts]

  %% Visual emphasis
  classDef good fill:#eaffea,stroke:#2e7d32,stroke-width:1px,color:#1b5e20;
  classDef bad fill:#ffecec,stroke:#c62828,stroke-width:1px,color:#7f0000;
  classDef neutral fill:#eef3ff,stroke:#3949ab,stroke-width:1px,color:#1a237e;

  class A,B,C,C1,D,E,F,O1,H neutral;
  class G good;
  class I,J,K bad;
  class L,L1,L2,L3,L4,L5 bad;
  class ORDER neutral;
  class D1,D2,D3,D4,D5,D6 neutral;

```

## Diagram version of README.md

---

```mermaid
flowchart TB
  %% ============================================================
  %% How to Run a Stage — Diagram (Mermaid)
  %% ============================================================

  A([Start]) --> B[Pick a stage ID<br/>e.g., stage-02]

  B --> C[Open dependency-graph.yaml<br/>Locate ONLY the selected stage section]
  C --> C1[Extract:<br/> required controls<br/> required artifacts<br/> definition-of-done / gates]

  C1 --> D[Assemble ONE Stage Runner prompt message<br/>in the required order]
  
  subgraph ORDER[Paste in this exact order]
    D1[1. prompt-pack-canonical-format.yaml<br/><i>Canonical executionwrapper + completion gates</i>]
    D2[2. context-anchor.yaml<br/><i>Role + audience + output contract</i>]
    D3[3. common-design.yaml<br/><i>Architecture rules + non-negotiables</i>]
    D4[4. governance.yaml<br/><i>Invariants + drift checks + README rules</i>]
    D5[5. Stage contract slice, from dependency-graph.yaml<br/><i>What to produce now</i>]
    D6[6. Inputs: repo tree / files / errors / constraints]
    D1 --> D2 --> D3 --> D4 --> D5 --> D6
  end

  D --> ORDER

  ORDER --> E[Execute the stage<br/>, send the assembled prompt]

  E --> F[Model produces artifacts + runs gates]
  F --> G{GATE_STATUS?}

  G -->|PASS| H[Commit artifacts<br/>Proceed to next stage using a NEW prompt]
  G -->|FAIL| I[Review gate failures]
  I --> J[Apply drift-fix patch list<br/>, exact file edits]
  J --> K[Rerun the SAME stage<br/>, new Stage Runner prompt]
  K --> E

  %% ============================================================
  %% Outputs expectations
  %% ============================================================
  F --> O1[Must include:<br/> required artifacts, stage<br/> end-to-end execution flow<br/> consolidated sequence diagrams, happy+failure<br/> README.md updates incl. macOS_Intel run steps]



  %% ============================================================
  %% Guardrails
  %% ============================================================
  L[[Common Mistakes]] --> L1[ X Multiple stages in one prompt]
  L --> L2[X Random paste order]
  L --> L3[X Skipping governance.yaml]
  L --> L4[X Proceeding after FAIL]
  L --> L5[X Missing mandatory artifacts]

  %% Visual emphasis
  classDef good fill:#eaffea,stroke:#2e7d32,stroke-width:1px,color:#1b5e20;
  classDef bad fill:#ffecec,stroke:#c62828,stroke-width:1px,color:#7f0000;
  classDef neutral fill:#eef3ff,stroke:#3949ab,stroke-width:1px,color:#1a237e;

  class A,B,C,C1,D,E,F,O1,H neutral;
  class G good;
  class I,J,K bad;
  class L,L1,L2,L3,L4,L5 bad;
  class ORDER neutral;
  class D1,D2,D3,D4,D5,D6 neutral;

```


---

