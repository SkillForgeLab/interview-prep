# Prompt Pack Index

This document defines the structure, purpose, and dependency model for the Agent Runtime Prompt Pack.
Each file is modular, composable, and stage-aware, allowing selective assembly based on goals and maturity.

---

---
## Core anchors (always included)
- This is the non-negotiable spine. 
- Forms the foundation of every prompt composition.
- These files are mandatory for all stages.

---

**Why This Is Powerful (Brief, Factual)**
- Forces design-before-code
- Produces enterprise artifacts by default
- Optimized for learning + retention
- Future-proof: swap use cases, keep rigor
- Matches how staff+ engineers think and document

---

1️⃣ `context-anchor.yaml` (DEFAULT — ALWAYS INCLUDED)

**Purpose**: 
- Defines role and reader profile
- Establishes documentation contract
- Sets output constraints
- Provides memory reinforcement rules

**Required by** 
- all stages.

---

2️⃣ `common-design.yaml`

This defines what “good” looks like for any system you build.

**Purpose**: 
- Use-case-agnostic design expectations
- Required document sections
- Threat modeling expectations
- Architecture principles 
 
**Required by**
- All stages

---

3️⃣ `usecase-event-planning.yaml` (OPTIONAL, PLUGGABLE)
- You can swap this file out for any future use case.

---


4️⃣ `stage-01-design-doc.yaml` (DOCUMENTATION-ONLY STAGE)
- This stage forces explanation before code.

---

5️⃣ `governance.yaml`

**Purpose**: 
- Terminology lock
- Invariants and non-negotiables
- Change control rules
- Drift detection checks
- Diagram → test mapping
- README generation rules
- Executive summary requirements
 
 
**Required by**
- All stages (acts as the enforcement layer)

---

---

## Use Case Module (Optional but Recommended)
Use case files bind the otherwise generic agent runtime to a concrete example.
They are replaceable and not required for the platform demonstration itself.

1️⃣ `usecase-event-planning.yaml`

**Purpose**: 
- Defines the entrypoint event.plan_event
- Declares scope and non-goals
- Specifies required flows
 
**Required by**
- Stage-01 through Stage-04 if you want outputs tied to this use case

**Replaceable with**
- Any other use case file

---

---

## Stage Modules
Stage modules are sequential and build on each other.
Each stage assumes correctness and completeness of the previous stage.
---

---

1️⃣ `stage-01-design-doc.yaml`

**Purpose**: 
- Design and documentation first
- Overview and conceptual primer
- Architecture definition
- End-to-end execution flow
- Happy-path and failure-path sequence diagrams
- STRIDE threat model
- Deployment specification
- Operational runbook
 
**Depends on**
- Core anchors
- `common-design.yaml`
- `governance.yaml`
- Use case module (recommended)


---

2️⃣ `stage-02-control-flow-state-model.yaml`

**Purpose**: 
- Deterministic control flow definition
- Finite State Machine (FSM)
- Error taxonomy
- Test matrix derived directly from state transitions
 
**Depends on**
- Stage-01 outputs being internally consistent


---

3️⃣ `stage-03-deterministic-execution-engine.yaml`

**Purpose**: 
- Implementation-ready execution engine specification
- Loop semantics
- Step handlers
- Persistence model
- Idempotency rules
- Retry semantics
- Locking strategy
- Test harness specification
 
**Depends on**
- Stage-02 FSM and control-flow model



---

4️⃣ `stage-04-observability-audit-trail.yaml`

**Purpose**: 
- Logging, metrics, and tracing contracts
- Audit trail definition
- Retention and redaction policies
- Dashboards and alerting
- Incident runbook
- Observability test plan
 
**Depends on**
- Stage-03 execution engine semantics
- Stage-02 identifiers and events


---

## Cross-Cutting Enforcement
The following rules are enforced globally via `governance.yaml`:
- Terminology lock
- Architectural invariants
- Change impact rules
- Drift detection
- Diagram → test mapping
- README generation rules
- Executive summary requirements


## Cross-Cutting Extensions

These capabilities may exist as standalone overlays or be folded into `governance.yaml`.

### Optional Overlay Files
- `seqdiagram-to-tests-mapping.yaml`
- `readme-autogen-rules.yaml`

> If these concerns are fully covered by governance.yaml, these files may be 
> omitted.
``

---

---

## How to compose the prompt files:

- You use the prompt-pack manifest whenever you want repeatable, 
deterministic assembly of prompts instead of ad-hoc copy/paste.
- Produce the output strictly according to their combined constraints.

---

### What is the manifest for (conceptually)?

Think of the manifest as a **build system for prompts.**

**Analogy (very intentional)**

| Software Engineering       | Prompt Pack                         |
|----------------------------|-------------------------------------|
| `pom.xml` / `build.gradle` | `prompt-pack-manifest.yaml`         |
| Source modules             | Anchor / stage / usecase YAML files |
| Dependency graph           | Stage + governance dependencies     |
| Build profiles             | `profiles:` section                 |
| CI build                   | Prompt resolution + execution       |

You are **decoupling**:
- **Prompt content** (YAML files)  
from
- **Prompt assembly logic** (manifest)

That’s the architectural move.


### What does the manifest actually do?
The manifest answers four deterministic questions:

#### 1. What files exist?
   - This is your registry — nothing implicit.
        ```yaml
         pack_catalog:
           anchors:
           usecases:
           stages:
           overlays:
        ```

#### 2. What depends on what?
- This gives you:
  - Safe ordering
    - Automatic inclusion of prerequisites
    - Early failure on broken packs

    ```yaml
    depends_on:
      - stage-01
    ```

#### 3. What combinations are allowed?
- This prevents:
  - Half-built packs 
  - Inconsistent stage usage 
  - Accidental omissions

    ```yaml
    profiles:
      - id: "event-planning-full"
    ```


#### 4. What is the final resolved pack?
- This makes the system:
  - Auditable
  - Testable
  - Tool-friendly

    ```yaml
    expected_outputs:
      resolved_files:
    ```

---

### When do you use it?

- You want to compose prompts programmatically, not manually
- You want different outputs from the same building blocks
- You want consistency across stages, teams, or experiments
- You want to prove this is a platform, not a one-off prompt

### Typical trigger moments
| Situation                                            | Why the manifest matters                    |
|------------------------------------------------------|---------------------------------------------|
| Starting a new Agent Runtime POC                     | Assemble the same canonical pack every time |
| Switching use cases (event planning → finance → ops) | Swap usecase file without touching stages   |
| Running Stage-01 only for design review              | Select stage subset safely                  |
| Leadership demo                                      | Guarantee the same structure every run      |
| Adding a new stage                                   | Declare dependencies once, reuse everywhere |
| Tooling / CI automation                              | Let code resolve packs, not humans          |

>The manifest is used before prompting the model — it decides what the model will see.

---
### How do you use it (step by step)?

#### 🧩 Step 1: Write modular prompt files 

- context-anchor.yaml
- common-design.yaml
- governance.yaml
- stage-01-04.yaml
- Optional usecases

These **never change per run**.


#### 🧩 Step 2: Define intent using the manifest

Instead of saying:

    “Give me Stage-02 with event planning”

You say:
```yaml
build_requests:
  - id: "pack-ep-stage-02"
    anchors: ["context-anchor", "common-design", "governance"]
    usecase: "event-planning"
    stages: ["stage-01", "stage-02"]
```

This is **machine-readable intent.**


#### 🧩 Step 3: Resolve the pack (human or tool)

A resolver (could be you, a script, or later an agent) does:
1. Include required anchors 
2. Add selected usecase 
3. Expand dependencies 
4. Order files 
5. Deduplicate 
6. Fail fast on violations

Result:
```yaml
[
  "context-anchor.yaml",
  "common-design.yaml",
  "governance.yaml",
  "usecase-event-planning.yaml",
  "stage-01-design-doc.yaml",
  "stage-02-control-flow-state-model.yaml"
]
```

#### 🧩 Step 3: Resolve the pack (human or tool)

Now you:
- Concatenate in order
- Or stream section-by-section
- Or apply them as system/developer messages

**The model never sees the manifest.**

The manifest is for you and tooling.

---
### When you do NOT need the manifest
Be honest about scope:  

❌ One-off chat prompt  
❌ Casual exploration  
❌ Single-stage experiment  
❌ No reuse / no governance  

If none of these matter → skip the manifest.

---

### Prompt resolver

- Reads your `prompt-pack-manifest.yaml`
- Resolves `build_requests` (or a single request id)
- Expands dependencies (topological sort)
- Enforces required anchors
- Orders files by your `assembly_rules.ordering`
- Dedupes includes
- Produces a **resolved file list** and optionally a **combined prompt bundle** 
  file

It’s designed to match the manifest structure you already have.

#### How you use this (zero thinking required) (macOS Intel / any OS)

Prepare environment and install `pyyaml`
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install pyyaml
```

Put these files in your repo:
```pytho-repl
prompt-pack-manifest.yaml
resolver-config.yaml
prompt_pack_resolver.py
Makefile
context-anchor.yaml
common-design.yaml
governance.yaml
usecase-event-planning.yaml
stage-01-design-doc.yaml
...

```

Then run:


Validate the contents of manifest:

```bash
make validate
```

List the contents of manifest:

```bash
make list
```
or 
```bash
python prompt_pack_resolver.py --manifest prompt-pack-manifest.yaml --list
```

Build prompt:
```bash
make build PACK=pack-002
```
or 
```bash
python prompt_pack_resolver.py --manifest prompt-pack-manifest.yaml --build pack-002 --base-dir .
```

**Bundle pack**

With `--bundle`, it also produces one concatenated “compiled prompt pack”

- Useful for pasting into a single model run
- Also useful to archive for governance/audit (“this is exactly what we used”)

```bash
make bundle PACK=pack-002
make compiled PACK=pack-002
```
or 
```bash
python prompt_pack_resolver.py --manifest prompt-pack-manifest.yaml --build pack-002 --bundle out/prompt-pack.txt --base-dir .
```

Outputs land in `out/`:
`out/resolution-report.yaml` ✅ what got assembled + warnings/errors
`out/prompt-pack.txt` ✅ “compiled text bundle” with file headers
`out/compiled-pack.yaml` ✅ “single YAML doc” containing all YAML documents
---

#### Next:

Add `make lint` to enforce YAML formatting/ordering conventions (still without 
introducing heavy dependencies).

https://chatgpt.com/c/696e43b1-cc80-8329-ac0b-59cb59d8060a

