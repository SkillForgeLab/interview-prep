#!/usr/bin/env python3
"""
Prompt Pack Resolver (Manifest v1.0)
+ Config support
+ Bundling
+ Compiled YAML
+ Validation

What it does
- Reads prompt-pack-manifest.yaml
- Resolves one build request (or all) into an ordered include list
- Expands dependencies (topological sort)
- Enforces required anchors
- Honors assembly_rules.selection_defaults:
    - include_required_anchors
    - include_governance
    - include_overlays_by_default
    - fail_if_missing_file
    - dedupe_files
    - strict_dependency_check
- Honors assembly_rules.governance_behavior.enforce_presence_for_stages
- Warns if a stage "recommends" a usecase but none selected
- Optionally bundles all resolved YAML files into one compiled prompt pack

Adds:
--config resolver-config.yaml (optional)
--compiled-yaml out/compiled-pack.yaml (single YAML document, multi-document YAML supported)
--validate-manifest (checks: duplicate ids, unknown references, missing dependencies, cycles, ordering references)
--validate-files (checks: all catalog files exist under base_dir, and warns if profiles/builds reference unknown ids)
This is working code (not pseudo-code).


Dependencies:
  pip install pyyaml

Usage:
  python prompt_pack_resolver.py --manifest prompt-pack-manifest.yaml --list
  python prompt_pack_resolver.py --manifest prompt-pack-manifest.yaml --build pack-002
  python prompt_pack_resolver.py --manifest prompt-pack-manifest.yaml --build pack-002 --bundle out/prompt-pack.txt --base-dir .
"""


from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

import yaml


class ManifestError(Exception):
    pass


@dataclass(frozen=True)
class Node:
    node_id: str
    file: str
    kind: str  # anchors|usecases|stages|overlays
    depends_on: Tuple[str, ...] = ()
    required: bool = False
    optional: bool = False
    recommends: Tuple[str, ...] = ()  # stages only


def load_yaml(path: str) -> dict:
    if not os.path.exists(path):
        raise ManifestError(f"YAML not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_config(path: Optional[str]) -> dict:
    if not path:
        return {}
    return load_yaml(path)


def index_catalog(manifest: dict) -> Dict[str, Node]:
    catalog = manifest.get("pack_catalog") or {}
    nodes: Dict[str, Node] = {}

    def add_nodes(kind: str, items: list):
        for it in items or []:
            node_id = it.get("id")
            file_ = it.get("file")
            if not node_id or not file_:
                raise ManifestError(f"Catalog entry missing id/file in {kind}: {it}")
            if node_id in nodes:
                raise ManifestError(f"Duplicate id in catalog: {node_id}")

            depends = tuple(it.get("depends_on") or [])
            required = bool(it.get("required", False))
            optional = bool(it.get("optional", False))
            recommends = tuple(it.get("recommends") or [])

            nodes[node_id] = Node(
                node_id=node_id,
                file=file_,
                kind=kind,
                depends_on=depends,
                required=required,
                optional=optional,
                recommends=recommends,
            )

    add_nodes("anchors", catalog.get("anchors"))
    add_nodes("usecases", catalog.get("usecases"))
    add_nodes("stages", catalog.get("stages"))
    add_nodes("overlays", catalog.get("overlays"))

    return nodes


def index_profiles(manifest: dict) -> Dict[str, dict]:
    profs = {}
    for p in (manifest.get("profiles") or []):
        pid = p.get("id")
        if not pid:
            raise ManifestError("Profile missing id.")
        if pid in profs:
            raise ManifestError(f"Duplicate profile id: {pid}")
        profs[pid] = p
    return profs


def index_build_requests(manifest: dict) -> Dict[str, dict]:
    reqs = {}
    for r in (manifest.get("build_requests") or []):
        rid = r.get("id")
        if not rid:
            raise ManifestError("Build request missing id.")
        if rid in reqs:
            raise ManifestError(f"Duplicate build request id: {rid}")
        reqs[rid] = r
    return reqs


def merge_profile_into_request(profile: dict, req: dict) -> dict:
    merged = {}
    merged.update(profile or {})
    merged.update(req or {})  # request wins
    overrides = (req or {}).get("overrides") or {}
    if overrides:
        merged.setdefault("overrides", {})
        merged["overrides"] = {**merged.get("overrides", {}), **overrides}
    return merged


def get_defaults(manifest: dict) -> dict:
    return ((manifest.get("assembly_rules") or {}).get("selection_defaults") or {})


def get_governance_behavior(manifest: dict) -> dict:
    return ((manifest.get("assembly_rules") or {}).get("governance_behavior") or {})


def required_anchor_ids(nodes: Dict[str, Node]) -> List[str]:
    req = [n.node_id for n in nodes.values() if n.kind == "anchors" and n.required]
    req.sort()
    return req


def dedupe_preserve_order(items: List[str]) -> List[str]:
    out = []
    seen = set()
    for x in items:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def expand_dependencies(seed_ids: List[str], nodes: Dict[str, Node], strict: bool) -> Set[str]:
    seen: Set[str] = set()

    def dfs(nid: str):
        if nid in seen:
            return
        if nid not in nodes:
            if strict:
                raise ManifestError(f"Unknown id referenced: {nid}")
            return
        seen.add(nid)
        for dep in nodes[nid].depends_on:
            dfs(dep)

    for s in seed_ids:
        dfs(s)

    return seen


def topological_sort(subgraph_ids: Set[str], nodes: Dict[str, Node]) -> List[str]:
    indeg: Dict[str, int] = {nid: 0 for nid in subgraph_ids}
    adj: Dict[str, List[str]] = {nid: [] for nid in subgraph_ids}

    for nid in subgraph_ids:
        for dep in nodes[nid].depends_on:
            if dep not in subgraph_ids:
                raise ManifestError(f"Missing dependency: '{nid}' depends_on '{dep}' but '{dep}' not included.")
            adj[dep].append(nid)
            indeg[nid] += 1

    queue = sorted([nid for nid, d in indeg.items() if d == 0])
    out: List[str] = []

    while queue:
        cur = queue.pop(0)
        out.append(cur)
        for nxt in adj[cur]:
            indeg[nxt] -= 1
            if indeg[nxt] == 0:
                queue.append(nxt)
                queue.sort()

    if len(out) != len(subgraph_ids):
        raise ManifestError("Dependency cycle detected while sorting.")
    return out


def apply_ordering(manifest: dict, topo_ids: List[str], nodes: Dict[str, Node], selected_usecase: Optional[str]) -> List[str]:
    ordering = ((manifest.get("assembly_rules") or {}).get("ordering") or [])
    topo_set = set(topo_ids)
    stage_ids_in_topo = [nid for nid in topo_ids if nodes[nid].kind == "stages"]

    out: List[str] = []
    used: Set[str] = set()

    def add(nid: str):
        if nid and nid in topo_set and nid not in used:
            out.append(nid)
            used.add(nid)

    for group in ordering:
        gname = group.get("group")
        if gname == "anchors":
            for nid in (group.get("order") or []):
                add(nid)
        elif gname == "usecase":
            if selected_usecase:
                add(selected_usecase)
        elif gname == "overlays":
            for nid in (group.get("order") or []):
                add(nid)
        elif gname == "stages":
            for nid in stage_ids_in_topo:
                add(nid)

    for nid in sorted(list(topo_set - used)):
        add(nid)

    return out


def bundle_files(base_dir: str, files: List[str], out_path: str, fail_if_missing: bool) -> None:
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as out:
        for rel in files:
            full = os.path.join(base_dir, rel)
            if not os.path.exists(full):
                msg = f"Cannot bundle; file not found: {rel}"
                if fail_if_missing:
                    raise ManifestError(msg)
                out.write("\n" + "#" * 80 + "\n")
                out.write(f"# FILE: {rel}\n# ERROR: {msg}\n")
                out.write("#" * 80 + "\n\n")
                continue

            out.write("\n" + "#" * 80 + "\n")
            out.write(f"# FILE: {rel}\n")
            out.write("#" * 80 + "\n\n")
            with open(full, "r", encoding="utf-8") as f:
                out.write(f.read().rstrip() + "\n")


def compile_to_single_yaml(base_dir: str, files: List[str], out_path: str, fail_if_missing: bool) -> None:
    compiled = {"compiled_pack": []}

    for rel in files:
        full = os.path.join(base_dir, rel)
        if not os.path.exists(full):
            msg = f"Cannot compile; file not found: {rel}"
            if fail_if_missing:
                raise ManifestError(msg)
            compiled["compiled_pack"].append({"source": rel, "error": msg, "documents": []})
            continue

        with open(full, "r", encoding="utf-8") as f:
            docs = [d for d in yaml.safe_load_all(f) if d is not None]

        compiled["compiled_pack"].append({"source": rel, "documents": docs})

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as out:
        yaml.safe_dump(compiled, out, sort_keys=False, default_flow_style=False)


def resolve_one(manifest: dict, nodes: Dict[str, Node], profiles: Dict[str, dict], build_req: dict, base_dir: str) -> dict:
    defaults = get_defaults(manifest)
    gov_behavior = get_governance_behavior(manifest)

    errors: List[str] = []
    warnings: List[str] = []

    profile_id = build_req.get("profile")
    effective = build_req
    if profile_id:
        if profile_id not in profiles:
            return {"build_request_id": build_req.get("id") or "<unknown>", "resolved_ids": [], "resolved_files": [], "warnings": [], "errors": [f"Unknown profile: {profile_id}"]}
        effective = merge_profile_into_request(profiles[profile_id], build_req)

    overrides = effective.get("overrides") or {}

    include_required_anchors = bool(overrides.get("include_required_anchors", defaults.get("include_required_anchors", True)))
    include_governance = bool(overrides.get("include_governance", defaults.get("include_governance", True)))
    include_overlays = bool(overrides.get("include_overlays", defaults.get("include_overlays_by_default", False)))
    fail_if_missing_file = bool(overrides.get("fail_if_missing_file", defaults.get("fail_if_missing_file", True)))
    dedupe_files = bool(overrides.get("dedupe_files", defaults.get("dedupe_files", True)))
    strict_dependency_check = bool(overrides.get("strict_dependency_check", defaults.get("strict_dependency_check", True)))

    anchors = list(effective.get("anchors") or [])
    usecase = effective.get("usecase")
    overlays = list(effective.get("overlays") or [])
    stages = list(effective.get("stages") or [])

    seed_ids: List[str] = []
    if include_required_anchors:
        seed_ids.extend(required_anchor_ids(nodes))

    seed_ids.extend(anchors)

    if include_governance and "governance" in nodes:
        seed_ids.append("governance")

    if usecase:
        seed_ids.append(usecase)

    if include_overlays:
        seed_ids.extend(overlays)

    seed_ids.extend(stages)
    seed_ids = dedupe_preserve_order([s for s in seed_ids if s])

    try:
        expanded = expand_dependencies(seed_ids, nodes, strict_dependency_check)
        topo = topological_sort(expanded, nodes)
    except ManifestError as e:
        errors.append(str(e))
        return {"build_request_id": effective.get("id") or "<unknown>", "resolved_ids": [], "resolved_files": [], "warnings": warnings, "errors": errors}

    ordered_ids = apply_ordering(manifest, topo, nodes, selected_usecase=usecase)
    if dedupe_files:
        ordered_ids = dedupe_preserve_order(ordered_ids)

    resolved_files = [nodes[nid].file for nid in ordered_ids]

    if gov_behavior.get("enforce_presence_for_stages", True):
        has_stage = any(nodes[nid].kind == "stages" for nid in ordered_ids)
        if has_stage and "governance" not in ordered_ids:
            errors.append("governance enforcement: 'governance' is required when stages are included.")

    if not usecase:
        for nid in ordered_ids:
            if nodes[nid].kind == "stages" and nodes[nid].recommends:
                warnings.append(f"{nid} recommends usecase(s) {list(nodes[nid].recommends)} but no usecase selected.")

    for f in resolved_files:
        full = os.path.join(base_dir, f)
        if not os.path.exists(full):
            msg = f"Missing file: {f} (base-dir: {base_dir})"
            if fail_if_missing_file:
                errors.append(msg)
            else:
                warnings.append(msg)

    return {"build_request_id": effective.get("id") or "<unknown>", "resolved_ids": ordered_ids, "resolved_files": resolved_files, "warnings": warnings, "errors": errors}


# ---------------------------
# Validation
# ---------------------------

def validate_manifest(manifest: dict, nodes: Dict[str, Node], profiles: Dict[str, dict], build_reqs: Dict[str, dict]) -> List[str]:
    """
    Returns list of validation errors (empty => OK).
    Validates:
    - all depends_on ids exist
    - all stage recommends ids exist
    - ordering references are valid ids (except placeholders)
    - dependency graph has no cycles (overall)
    - profile/build request references are valid ids
    """
    errors: List[str] = []

    # depends_on + recommends reference validity
    for nid, n in nodes.items():
        for dep in n.depends_on:
            if dep not in nodes:
                errors.append(f"Unknown dependency id: '{nid}' depends_on '{dep}' (not in catalog)")
        for rec in n.recommends:
            if rec not in nodes:
                errors.append(f"Unknown recommended id: '{nid}' recommends '{rec}' (not in catalog)")

    # ordering references
    ordering = ((manifest.get("assembly_rules") or {}).get("ordering") or [])
    placeholders = {"{selected_usecase}", "{selected_stages_in_dependency_order}"}
    for group in ordering:
        for item in (group.get("order") or []):
            if item in placeholders:
                continue
            if item not in nodes:
                errors.append(f"ordering references unknown id: '{item}'")

    # graph cycle detection across all nodes
    try:
        _ = topological_sort(set(nodes.keys()), nodes)
    except ManifestError as e:
        errors.append(str(e))

    # profiles reference validity
    for pid, p in profiles.items():
        usecase = p.get("usecase")
        stages = p.get("stages") or []
        overlays = p.get("overlays") or []
        if usecase is not None and usecase not in nodes:
            errors.append(f"profile '{pid}' references unknown usecase id: '{usecase}'")
        for s in stages:
            if s not in nodes:
                errors.append(f"profile '{pid}' references unknown stage id: '{s}'")
        for o in overlays:
            if o not in nodes:
                errors.append(f"profile '{pid}' references unknown overlay id: '{o}'")

    # build request reference validity
    for rid, r in build_reqs.items():
        prof = r.get("profile")
        if prof and prof not in profiles:
            errors.append(f"build_request '{rid}' references unknown profile: '{prof}'")
        # if direct fields are present
        for k in ("anchors", "overlays", "stages"):
            for item in (r.get(k) or []):
                if item not in nodes:
                    errors.append(f"build_request '{rid}' references unknown id in {k}: '{item}'")
        uc = r.get("usecase")
        if uc is not None and "usecase" in r and uc not in nodes:
            errors.append(f"build_request '{rid}' references unknown usecase id: '{uc}'")

    return errors


def validate_files(nodes: Dict[str, Node], base_dir: str) -> List[str]:
    errors: List[str] = []
    for nid, n in nodes.items():
        full = os.path.join(base_dir, n.file)
        if not os.path.exists(full):
            errors.append(f"Missing file for id '{nid}': {n.file} (base-dir: {base_dir})")
    return errors


def main() -> int:
    ap = argparse.ArgumentParser(description="Resolve prompt packs from prompt-pack-manifest.yaml")
    ap.add_argument("--config", help="Path to resolver-config.yaml (optional)")
    ap.add_argument("--manifest", help="Path to prompt-pack-manifest.yaml (overrides config)")
    ap.add_argument("--base-dir", help="Base dir for prompt files (overrides config)")

    ap.add_argument("--list", action="store_true", help="List profiles and build request IDs")

    ap.add_argument("--validate-manifest", action="store_true", help="Validate manifest references/deps/cycles/ordering")
    ap.add_argument("--validate-files", action="store_true", help="Validate that all catalog files exist under base-dir")

    ap.add_argument("--build", help="Build request id to resolve (e.g., pack-002). If omitted, resolves all.")
    ap.add_argument("--out", help="Write results to YAML file (safe YAML).")
    ap.add_argument("--bundle", help="Concatenate resolved prompt files into this output path (single-build only).")
    ap.add_argument("--compiled-yaml", help="Write a single compiled YAML doc (single-build only).")

    args = ap.parse_args()
    cfg = load_config(args.config)

    manifest_path = args.manifest or cfg.get("manifest_path") or "prompt-pack-manifest.yaml"
    base_dir = args.base_dir or cfg.get("base_dir") or "."

    out_default = cfg.get("resolution_report_path")
    bundle_default = cfg.get("bundle_output_path")
    compiled_default = cfg.get("compiled_yaml_output_path")
    default_build = cfg.get("default_build_request_id")

    manifest = load_yaml(manifest_path)
    nodes = index_catalog(manifest)
    profiles = index_profiles(manifest)
    build_reqs = index_build_requests(manifest)

    if args.list:
        print("Profiles:")
        for pid in sorted(profiles.keys()):
            print(f"  - {pid}")
        print("\nBuild requests:")
        for rid in sorted(build_reqs.keys()):
            print(f"  - {rid}")
        return 0

    if args.validate_manifest:
        errs = validate_manifest(manifest, nodes, profiles, build_reqs)
        if errs:
            print("MANIFEST VALIDATION: FAIL")
            for e in errs:
                print(f"  - {e}")
            return 2
        print("MANIFEST VALIDATION: OK")
        return 0

    if args.validate_files:
        errs = validate_files(nodes, base_dir)
        if errs:
            print("FILES VALIDATION: FAIL")
            for e in errs:
                print(f"  - {e}")
            return 2
        print("FILES VALIDATION: OK")
        return 0

    build_id = args.build or default_build

    if build_id:
        if build_id not in build_reqs:
            raise ManifestError(f"Unknown build request id: {build_id}")
        targets = [build_reqs[build_id]]
    else:
        targets = [build_reqs[rid] for rid in sorted(build_reqs.keys())]

    results: List[dict] = []
    any_errors = False

    for req in targets:
        res = resolve_one(manifest, nodes, profiles, req, base_dir=base_dir)
        results.append(res)
        if res["errors"]:
            any_errors = True

    for r in results:
        print("\n" + "=" * 80)
        print(f"BUILD: {r['build_request_id']}")
        if r["errors"]:
            print("STATUS: ERROR")
            for e in r["errors"]:
                print(f"  - {e}")
        else:
            print("STATUS: OK")
            print("RESOLVED FILES:")
            for f in r["resolved_files"]:
                print(f"  - {f}")

        if r["warnings"]:
            print("\nWARNINGS:")
            for w in r["warnings"]:
                print(f"  - {w}")

    out_path = args.out or out_default
    if out_path:
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            yaml.safe_dump({"results": results}, f, sort_keys=False, default_flow_style=False)
        print(f"\nWROTE REPORT: {out_path}")

    if args.bundle or args.compiled_yaml:
        if len(results) != 1:
            raise ManifestError("--bundle/--compiled-yaml require a single build (use --build <id>).")
        r = results[0]
        if r["errors"]:
            raise ManifestError("Cannot bundle/compile because the build has errors.")

        defaults = get_defaults(manifest)
        fail_if_missing_file = bool(defaults.get("fail_if_missing_file", True))

        bundle_path = args.bundle or bundle_default
        if bundle_path and (args.bundle or bundle_default):
            bundle_files(base_dir, r["resolved_files"], bundle_path, fail_if_missing_file)
            print(f"\nBUNDLED INTO: {bundle_path}")

        compiled_path = args.compiled_yaml or compiled_default
        if compiled_path and (args.compiled_yaml or compiled_default):
            compile_to_single_yaml(base_dir, r["resolved_files"], compiled_path, fail_if_missing_file)
            print(f"\nCOMPILED YAML INTO: {compiled_path}")

    return 2 if any_errors else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ManifestError as e:
        print(f"MANIFEST ERROR: {e}", file=sys.stderr)
        raise SystemExit(2)
    except KeyboardInterrupt:
        raise SystemExit(130)