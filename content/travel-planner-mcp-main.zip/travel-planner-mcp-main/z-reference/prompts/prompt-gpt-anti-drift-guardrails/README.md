https://chatgpt.com/g/g-p-69696e1a8ad481919570eb827ae87488-prompts/c/696e89a2-6ce4-8330-a89c-dcb9d186a773

Review above link starting from
2) Updated base.yaml (defaults for all future stages)