#!/usr/bin/env python3
"""
compose.py — Compose modular prompt YAML files into a single merged prompt.

Features
- Reads a manifest YAML (default: 99-compose.manifest.yaml)
- Validates:
  - scope_profile == "pure_runtime" (if present in modules)
  - exactly one stage module enabled:true
- Deep-merges YAML docs in the specified order (last-wins for scalars/maps)
- List merging policy:
  - default: append
  - override paths: replace list entirely (configurable in manifest)
- Writes merged YAML to outputs.merged_prompt.path (default: prompt.final.yaml)

Install
  pip install pyyaml

Usage
  python compose.py
  python compose.py --manifest 99-compose.manifest.yaml
  python compose.py --manifest 99-compose.manifest.yaml --out prompt.final.yaml
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import yaml


JsonLike = Any


@dataclass
class ComposerConfig:
    merge_strategy: str
    array_default: str
    array_override_paths: List[str]
    require_exactly_one_stage: bool
    require_scope_profile: Optional[str]
    include_manifest_metadata: bool
    output_path: str


def load_yaml_file(path: str) -> JsonLike:
    if not os.path.exists(path):
        raise FileNotFoundError(f"YAML file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)  # returns dict/list/scalar or None


def dump_yaml_file(path: str, data: JsonLike) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(
            data,
            f,
            sort_keys=False,
            default_flow_style=False,
            width=120,
            allow_unicode=True,
        )


def is_override_path(path: str, override_paths: List[str]) -> bool:
    # Paths are JSONPath-like strings such as "$.context_anchor"
    # We normalize our internal path into the same style.
    return path in override_paths


def normalize_path(path_parts: List[str]) -> str:
    # Internal path: ["context_anchor", "id"] -> "$.context_anchor.id"
    if not path_parts:
        return "$"
    return "$." + ".".join(path_parts)


def deep_merge(
    base: JsonLike,
    incoming: JsonLike,
    path_parts: Optional[List[str]] = None,
    array_default: str = "append",
    array_override_paths: Optional[List[str]] = None,
) -> JsonLike:
    """
    Deep merge rules:
    - dict + dict => recurse per key (incoming overwrites base)
    - list + list => append by default, unless current path is in override paths (then replace)
    - scalar/None => incoming overwrites base
    """
    if path_parts is None:
        path_parts = []
    if array_override_paths is None:
        array_override_paths = []

    current_path = normalize_path(path_parts)

    if isinstance(base, dict) and isinstance(incoming, dict):
        merged: Dict[str, Any] = dict(base)
        for k, v in incoming.items():
            if k in merged:
                merged[k] = deep_merge(
                    merged[k],
                    v,
                    path_parts + [str(k)],
                    array_default=array_default,
                    array_override_paths=array_override_paths,
                )
            else:
                merged[k] = v
        return merged

    if isinstance(base, list) and isinstance(incoming, list):
        if is_override_path(current_path, array_override_paths):
            return list(incoming)
        if array_default == "append":
            return list(base) + list(incoming)
        if array_default == "replace":
            return list(incoming)
        raise ValueError(f"Unsupported array_policy.default: {array_default}")

    # Type mismatch or scalar overwrite: incoming wins
    return incoming


def parse_manifest(manifest: Dict[str, Any]) -> Tuple[ComposerConfig, List[str]]:
    composer = manifest.get("composer") or {}
    strategy = (composer.get("strategy") or {}).get("merge", "deep_merge_last_wins")

    array_policy = (composer.get("strategy") or {}).get("array_policy") or {}
    array_default = array_policy.get("default", "append")
    array_override_paths = array_policy.get("override_paths", []) or []

    invariants = composer.get("invariants") or {}
    require_exactly_one_stage = bool(invariants.get("require_exactly_one_stage", True))
    require_scope_profile = invariants.get("require_scope_profile")

    outputs = manifest.get("outputs") or {}
    merged_prompt = outputs.get("merged_prompt") or {}
    output_path = merged_prompt.get("path", "prompt.final.yaml")
    include_manifest_metadata = bool(merged_prompt.get("include_manifest_metadata", True))

    cfg = ComposerConfig(
        merge_strategy=strategy,
        array_default=array_default,
        array_override_paths=array_override_paths,
        require_exactly_one_stage=require_exactly_one_stage,
        require_scope_profile=require_scope_profile,
        include_manifest_metadata=include_manifest_metadata,
        output_path=output_path,
    )

    modules = manifest.get("modules") or {}
    file_list: List[str] = []

    # base modules (required)
    for item in (modules.get("base") or []):
        p = item.get("path")
        if p:
            file_list.append(p)

    # use_case (optional)
    use_case = modules.get("use_case") or {}
    if bool(use_case.get("enabled", False)):
        p = use_case.get("path")
        if p:
            file_list.append(p)

    # stages (exactly one)
    stages = modules.get("stages") or []
    enabled_stages = [s for s in stages if bool(s.get("enabled", False))]

    if require_exactly_one_stage and len(enabled_stages) != 1:
        raise ValueError(
            f"Manifest invariant violated: require_exactly_one_stage=true but found {len(enabled_stages)} enabled stages."
        )

    if enabled_stages:
        p = enabled_stages[0].get("path")
        if p:
            file_list.append(p)

    return cfg, file_list


def validate_scope_profile(cfg: ComposerConfig, merged: Dict[str, Any]) -> None:
    if not cfg.require_scope_profile:
        return
    # We check any scope_profile fields found in prompt_pack(s)
    # If a module sets scope_profile, merged prompt should remain compatible.
    pp = merged.get("prompt_pack") or {}
    sp = pp.get("scope_profile")
    if sp and sp != cfg.require_scope_profile:
        raise ValueError(
            f"Scope profile mismatch: manifest requires '{cfg.require_scope_profile}', but merged prompt_pack.scope_profile is '{sp}'."
        )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default="99-compose.manifest.yaml", help="Path to compose manifest YAML")
    ap.add_argument("--out", default=None, help="Override output path (otherwise uses manifest outputs.merged_prompt.path)")
    args = ap.parse_args()

    try:
        manifest = load_yaml_file(args.manifest)
        if not isinstance(manifest, dict):
            raise ValueError("Manifest YAML must be a mapping/object at the top level.")

        cfg, files = parse_manifest(manifest)

        if args.out:
            cfg.output_path = args.out

        if cfg.merge_strategy != "deep_merge_last_wins":
            raise ValueError(f"Unsupported merge strategy: {cfg.merge_strategy} (only deep_merge_last_wins is supported)")

        if not files:
            raise ValueError("No modules selected in manifest; nothing to compose.")

        merged: Any = {}
        loaded_modules: List[Dict[str, Any]] = []

        for path in files:
            doc = load_yaml_file(path)
            if doc is None:
                doc = {}
            if not isinstance(doc, dict):
                raise ValueError(f"Module must be a YAML mapping/object: {path}")
            loaded_modules.append({"path": path, "doc": doc})
            merged = deep_merge(
                merged,
                doc,
                path_parts=[],
                array_default=cfg.array_default,
                array_override_paths=cfg.array_override_paths,
            )

        # Optional: attach manifest metadata so the final prompt is self-describing
        if cfg.include_manifest_metadata:
            meta = {
                "composition": {
                    "manifest": os.path.basename(args.manifest),
                    "modules_in_order": [m["path"] for m in loaded_modules],
                    "merge_strategy": cfg.merge_strategy,
                    "array_policy": {
                        "default": cfg.array_default,
                        "override_paths": cfg.array_override_paths,
                    },
                }
            }
            merged = deep_merge(
                merged,
                meta,
                path_parts=[],
                array_default=cfg.array_default,
                array_override_paths=cfg.array_override_paths,
            )

        validate_scope_profile(cfg, merged)

        dump_yaml_file(cfg.output_path, merged)
        print(f"Composed prompt written to: {cfg.output_path}")
        return 0

    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
