#  Combining the prompts
## Simple “manual merge”
Create a `single prompt.yaml` by concatenating in this order:
1. `00-tech-stack-and-config.yaml`
2. `10-common-design-aspects.yaml`
3. `20-usecase-specific.yaml` (optional)
4. `30-stage-XX-....yaml` (pick exactly one stage)


yq is a lightweight and portable command-line processor for YAML, JSON, and XML data. It uses a familiar syntax similar to the popular jq tool for JSON, but is designed to work seamlessly with structured configuration files like those used in Kubernetes and other DevOps environments. 

https://mikefarah.gitbook.io/yq

### Installing yq
- **Homebrew**
  ```bash 
  brew install yq
  ```
- **bash**
  ```bash 
  curl -sS https://webi.sh/yq | sh
  ```




```bash
yq eval-all 'select(fileIndex==0) * select(fileIndex==1) * select(fileIndex==2) * select(fileIndex==3)' \
  00-tech-stack-and-config.yaml \
  10-common-design-aspects.yaml \
  20-usecase-specific.yaml \
  32-stage-02-policy-engine.yaml > prompt.final.yaml
```