```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant B as Browser
    participant S as Server

    U->>B: Opens application
    B->>S: Request homepage
    S-->>B: Response (HTML)
    B-->>U: Render page

    U->>B: Submits login form
    B->>S: POST /login
    alt Valid credentials
        S-->>B: 200 OK + token
        B-->>U: Show dashboard
    else Invalid credentials
        S-->>B: 401 Unauthorized
        B-->>U: Show error message
    end

```


```mermaid
sequenceDiagram
    autonumber

    participant U as User
    participant B as Browser
    participant S as Server
    participant DB as Database
    participant Q as Queue

    U->>B: Opens application
    B->>S: HTTP GET /home
    activate S
    S-->>B: 200 OK (HTML)
    deactivate S
    B-->>U: Render Home Page

    U->>B: Submits login form
    B->>S: POST /login
    activate S
    S->>DB: SELECT * FROM users
    activate DB
    DB-->>S: User record
    deactivate DB

    alt Credentials valid
        S-->>B: 200 OK (Auth Token)
        B-->>U: Welcome page
    else Invalid
        S-->>B: 401 Unauthorized
        B-->>U: Show error message
    end
    deactivate S

    loop Retry up to 3 times
        U->>B: Retry login
        B->>S: POST /login
        S-->>B: Response
    end

    opt Remember Me checked
        B->>S: Save session cookie
    end

    par Log request
        S->>Q: Send audit log
    and Notify monitoring
        S->>Q: Send metrics
    end

    critical Transaction
        S->>DB: BEGIN TRANSACTION
        DB-->>S: OK
    option Commit
        S->>DB: COMMIT
        DB-->>S: OK
    option Rollback
        S->>DB: ROLLBACK
        DB-->>S: OK
    end

    break User cancels
        U->>B: Clicks cancel
        B-->>U: Stop login process
    end

    Note over U,B: User interacts with the browser
    Note right of S: Server processes requests
    Note left of DB: Stores employee data

```