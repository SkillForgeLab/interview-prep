# Fix VS Code GitHub auth

---

## A) Recommended: SSH (no token prompts)

Make your repo remote SSH (critical)

#### 📁 File: [README](token-based-auth-repo.md)

---

### 1) Confirm Git uses SSH for the repo

```bash
git remote -v
```

If you see `https://...`, switch:

```bash
git remote set-url origin git@github.com:[GitHub username]/[git-repo name].git
```

---

### 2) Make sure SSH works in Terminal

```bash
ssh -T git@github.com
```

---

### 3) Push from VS Code

1. Source Control **Push**
2. It should work with no prompts.

VS Code’s “GitHub sign-in” is for GitHub features/extensions. For `git push`,
what matters is your repo remote (SSH vs HTTPS) and your local git credentials.

---

---

## B) HTTPS + PAT (common VS Code path)

---

### 1) Ensure you have Git Credential Manager (recommended)
On macOS, the typical working setup is:
```bash
git config --global credential.helper osxkeychain
```

---

### 2) Ensure remote is HTTPS

```bash
git remote set-url origin https://github.com/[GitHub username]/[git-repo name].git
```

---

### 3) Push once and use PAT as password

- In VS Code push, when prompted:
  - **Username:** [GitHub username]
  - **Password:** **paste PAT** (not your GitHub password)

It will be stored in Keychain.

