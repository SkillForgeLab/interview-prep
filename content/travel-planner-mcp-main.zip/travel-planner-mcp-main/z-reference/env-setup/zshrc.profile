
# source .zshrc

export NODE_ENV=development

################################# PROXY CONFIG ###########################################

export {{http,https,ftp}_proxy,{HTTP,HTTPS,FTP}_PROXY}=""
export {NO_PROXY,no_proxy}=""

##########################################################################################



########################## SDKMAN CONFIGURATION ##########################################

#THIS MUST BE AT THE END OF THE FILE FOR SDKMAN TO WORK!!!
export SDKMAN_DIR="$HOME/.sdkman"
[[ -s "$HOME/.sdkman/bin/sdkman-init.sh" ]] && source "$HOME/.sdkman/bin/sdkman-init.sh"

##########################################################################################



##################### JAVA CONFIGURATION WITH SDKMAN #####################################

export JAVA_HOME=/Users/suswaram/.sdkman/candidates/java/current/bin/java
export JRE_HOME=$JAVA_HOME/jre
export JRE_BIN=$JRE_HOME/bin

alias java8='unset JAVA_HOME;  sdk env clear; sdk install java 8.0.402-zulu; sdk use java 8.0.402-zulu'
alias java11='unset JAVA_HOME; sdk env clear; sdk install java 11.0.22-zulu; sdk use java 11.0.22-zulu'
alias java17='unset JAVA_HOME; sdk env clear; sdk install java 17.0.10-zulu; sdk use java 17.0.10-zulu'
alias java21='unset JAVA_HOME; sdk env clear; sdk install java 21.0.2-zulu;  sdk use java 21.0.2-zulu'

##########################################################################################



##################### JAVA CONFIGURATION WITHOUT SDKMAN ##################################

#export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_202.jdk/Contents/Hom
#export JRE_HOME=$JAVA_HOME/jre
#export JRE_BIN=$JRE_HOME/bin

#alias java8='unset JAVA_HOME; export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_202.jdk/Contents/Home'
#alias java11='unset JAVA_HOME; export JAVA_HOME=/Library/Java/JavaVirtualMachines/oracle-jdk.17.0.10.jdk/Contents/Home'
#alias java17='unset JAVA_HOME; export JAVA_HOME=/Library/Java/JavaVirtualMachines/zulu-jdk.11.0.22.jdk/Contents/Home'


##########################################################################################



########################## MAVEN CONFIGURATION ###########################################

export M2_HOME=
export M2_BIN=$M2_HOME/bin
export MAVEN_REPOSITORY=$M2_HOME
export MAVEN_OPTS="-Xms1024m -Xmx2048m -XX:MaxPermSize=1024m"

##########################################################################################



########################### PATH CONFIGURATION ###########################################

export PATH=$PATH:{JAVA_HOME}:{JRE_HOME}:{JRE_BIN}:{$M2_HOME}:{M2_BIN}

##########################################################################################

