### Shared file (works for both): `.editorconfig`

#### Create .editorconfig at repo root:

```ini
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true
indent_style = space
indent_size = 2

[*.md]
trim_trailing_whitespace = false
max_line_length = 100

[*.py]
indent_size = 4

[Makefile]
indent_style = tab

```

**Notes:**

- Markdown often uses trailing spaces for explicit line breaks, so we relax
  it in `[*.md]`.
- 100-char lines keeps diffs readable.

---

### Option A: npm (Prettier + markdownlint-cli2)

### 1️⃣ `package.json` scripts

**Add these scripts:**

```json
{
  "scripts": {
    "fmt:md": "prettier --write \"**/*.md\"",
    "lint:md": "markdownlint-cli2",
    "check:md": "npm run fmt:md && npm run lint:md"
  },
  "devDependencies": {
    "markdownlint-cli2": "^0.14.0",
    "prettier": "^3.0.0"
  }
}
```

**Install**

```bash
npm install
```

---

### 2️⃣ `prettierrc.json`

```json
{
  "printWidth": 100,
  "proseWrap": "always"
}
```

---

### 3️⃣ `markdownlint` config

`.markdownlint.json` **(baseline)**  
Use the one we already created earlier.

`.markdownlint-cli2.jsonc` **(README-only override)**  
Use the README override we created earlier (MD041 off, optional MD034 off,
etc.).


---

### Option B: uv (Python-only)

**This provides:**

- **Auto-format:** `mdformat`
- **Lint:** `pymarkdownlnt` (PyMarkdown)

### 1️⃣ Add tools to `pyproject.toml`

**Add/merge this:**

```toml
[tool.uv]
dev-dependencies = [
    "mdformat>=0.7.22",
    "pymarkdownlnt>=0.9.25"
]

[tool.mdformat]
wrap = 100
number = false

[tool.pymarkdown]
# Baseline rules (practical + enterprise docs)
plugins = [
    "md001", # heading levels increment
    "md009", # trailing spaces control
    "md010", # no hard tabs
    "md012", # no multiple blank lines
    "md022", # blanks around headings
    "md024", # no duplicate headings
    "md025", # one H1
    "md031", # blanks around fences
    "md032", # blanks around lists
    "md040", # fenced code language
    "md041", # first line heading (we'll override for README)
    "md047"   # file ends with newline
]

# Configure key behaviors
[tool.pymarkdown.extensions.md009]
br_spaces = 2

[tool.pymarkdown.extensions.md012]
maximum = 1

[tool.pymarkdown.extensions.md025]
level = 1

```

**Install dev tools:**

```bash
uv sync
```

---

### 2️⃣ README-only override for PyMarkdown

PyMarkdown supports per-file config via a separate config file pattern. The
clean approach is:

- Keep strict defaults in `pyproject.toml`
- Add a `.pymarkdown.json` that **overrides** for README

**Create** `.pymarkdown.json`

```json
{
  "overrides": [
    {
      "selector": "**/README.md",
      "disable_rules": [
        "MD041"
      ],
      "configure": {
        "MD012": {
          "maximum": 2
        }
      }
    }
  ]
}
```

**Then run lint with that config:**

```bash
uv run pymarkdown scan -c .pymarkdown.json .
```

---

### 3️⃣ uv scripts (optional helper)

If you want a single command style, add a `Makefile` or shell script. Example
`Makefile`:
```makefile
fmt-md:
	uv run mdformat .

lint-md:
	uv run pymarkdown scan -c .pymarkdown.json .

check-md: fmt-md lint-md
```
**Run:**
```bash
make check-md
```

---

### GitHub Actions CI (both npm and uv)
Create `.github/workflows/markdown.yml`:
```yaml
name: Markdown

on:
  pull_request:
  push:
    branches: [ main ]

jobs:
  markdown-npm:
    name: Markdown (npm)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: "20"
          cache: "npm"

      - name: Install
        run: npm ci

      - name: Format check (Prettier)
        run: npx prettier --check "**/*.md"

      - name: Lint (markdownlint-cli2)
        run: npx markdownlint-cli2

  markdown-uv:
    name: Markdown (uv)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install uv
        run: python -m pip install uv

      - name: Install dev deps
        run: uv sync

      - name: Format check (mdformat)
        run: uv run mdformat --check .

      - name: Lint (pymarkdown)
        run: uv run pymarkdown scan -c .pymarkdown.json .
```
#### You can delete one job if you decide to standardize later.

---
### Summary of commands

**npm**
```bash
npm run check:md
```

**uv**
```bash
uv run mdformat .
uv run pymarkdown scan -c .pymarkdown.json .
```
---


### Badge for README (optional)

**Add to top of README:**
```md 
![Markdown](https://github.com/<ORG>/<REPO>/actions/workflows/markdown.yml/badge.svg)
```
(Replace `<ORG>/<REPO>`.)