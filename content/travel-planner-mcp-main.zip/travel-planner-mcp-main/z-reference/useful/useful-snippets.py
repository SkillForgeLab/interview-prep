# Printing colored text in Python

# Option ✅ 1. Built-in ANSI Escape Codes (No Library Needed)
# | Color   | Code       |
# | ------- | ---------- |
# | Red     | `\033[31m` |
# | Green   | `\033[32m` |
# | Blue    | `\033[34m` |
# | Yellow  | `\033[33m` |
# | Magenta | `\033[35m` |
# | Cyan    | `\033[36m` |
# | White   | `\033[37m` |
# | Black   | `\033[30m` |
# | Reset   | `\033[0m`  |
print("\n#########   Using Built-in ANSI Escape Codes!   ############")
print("\033[31mThis is red text\033[0m")
print("\033[32mThis is green text\033[0m")
print("\033[34mThis is blue text\033[0m")
print(f"\033[33mWarning!\033[0m This is a yellow warning message.")

# Option ✅ 2. With colorama (recommended for Windows but works everywhere)
# pip install colorama

from colorama import Fore, Style
print("\n#########   Using colorama!   ############")
print(Fore.RED + "This is red" + Style.RESET_ALL)
print(Fore.GREEN + "This is green")
print(Fore.BLUE + "This is blue" + Style.RESET_ALL)

# Option ✅ 3. With termcolor. Includes styles like bold, underline, etc.
# pip install termcolor

# termcolor often prints no colors on macOS unless
# the terminal fully supports ANSI colors
# OR
# another library (like colorama) initializes things.

#library (like colorama) initializes things.
from colorama import init
from termcolor import colored
init()  # enables ANSI colors universally
print("\n#########   Using termcolor!   ############")
print(colored("This is red", "red"))
print(colored("This is green", "green"))
print(colored("This is blue", "blue"))
