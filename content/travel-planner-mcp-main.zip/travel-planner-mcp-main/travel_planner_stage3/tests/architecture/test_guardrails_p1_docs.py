from __future__ import annotations

import re
from pathlib import Path

import pytest


DOC_CANDIDATES = [
    # Preferred “design doc” locations
    Path("docs/technical_design.md"),
    Path("docs/technical-technical-design.md"),
    Path("docs/technical-design.md"),
    Path("docs/architecture.md"),
    Path("docs/arch.md"),
    # Fallback
    Path("README.md"),
]


REQUIRED_EXEC_FLOW_HEADER = r"^#+\s*Step-by-step Code Execution Flow\s*$"


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _pick_docs_to_scan() -> list[Path]:
    existing = [p for p in DOC_CANDIDATES if p.exists() and p.is_file()]
    if not existing:
        pytest.fail(
            "P1 docs guard: No documentation files found.\n"
            "Expected at least one of:\n"
            + "\n".join(f"  - {p.as_posix()}" for p in DOC_CANDIDATES)
        )
    return existing


def _has_step_by_step_flow(text: str) -> bool:
    # Require an explicit section header
    if not re.search(REQUIRED_EXEC_FLOW_HEADER, text, flags=re.MULTILINE):
        return False

    # Require numbered steps under that section (simple heuristic).
    # Accept "1." / "1)" / "Step 1" styles.
    after = text
    m = re.search(REQUIRED_EXEC_FLOW_HEADER, text, flags=re.MULTILINE)
    if m:
        after = text[m.end() :]

    return bool(
        re.search(r"(?m)^\s*(?:\d+[\.\)]\s+|Step\s+\d+\s*[:\-])", after)
    )


def _extract_mermaid_blocks(text: str) -> list[str]:
    # Extract fenced mermaid code blocks
    blocks: list[str] = []
    fence_re = re.compile(r"```mermaid\s*(.*?)\s*```", flags=re.DOTALL | re.IGNORECASE)
    for m in fence_re.finditer(text):
        blocks.append(m.group(1))
    return blocks


def _has_required_mermaid(blocks: list[str]) -> tuple[bool, dict[str, bool]]:
    # We require:
    # - at least one flowchart
    # - at least one sequenceDiagram happy path
    # - at least one sequenceDiagram failure path
    #
    # We detect happy/failure by keywords in titles/comments OR content tags.
    # This keeps it flexible while still enforcing intent.

    has_flowchart = False
    has_seq_happy = False
    has_seq_failure = False

    for b in blocks:
        b_norm = b.strip()

        if re.search(r"(?m)^\s*flowchart\b", b_norm):
            has_flowchart = True

        if re.search(r"(?m)^\s*sequenceDiagram\b", b_norm):
            # Heuristics for happy/failure labeling
            # Accept: "Happy", "Happy Path", "Failure", "Failure Path"
            if re.search(r"(?i)\bhappy\b", b_norm):
                has_seq_happy = True
            if re.search(r"(?i)\bfail(ure)?\b", b_norm):
                has_seq_failure = True

    # If author didn’t label inside the block, allow labeling right above the block:
    # In that case, blocks alone may not contain “happy/failure”.
    # We’ll enforce at least 2 sequenceDiagrams if not explicitly labeled.
    seq_blocks = [b for b in blocks if re.search(r"(?m)^\s*sequenceDiagram\b", b.strip())]
    if not (has_seq_happy and has_seq_failure):
        if len(seq_blocks) >= 2:
            # still require at least one flowchart; accept unlabeled sequences
            has_seq_happy = True
            has_seq_failure = True

    return (has_flowchart and has_seq_happy and has_seq_failure), {
        "flowchart": has_flowchart,
        "sequence_happy": has_seq_happy,
        "sequence_failure": has_seq_failure,
    }


@pytest.mark.p1_guard
def test_docs_include_step_by_step_code_execution_flow() -> None:
    docs = _pick_docs_to_scan()
    scanned = []
    for p in docs:
        text = _read_text(p)
        scanned.append(p.as_posix())
        if _has_step_by_step_flow(text):
            return

    pytest.fail(
        "P1 docs guard: Missing 'Step-by-step Code Execution Flow' section with numbered steps.\n"
        "Searched in:\n" + "\n".join(f"  - {s}" for s in scanned) + "\n\n"
        "Fix:\n"
        "- Add a header exactly: 'Step-by-step Code Execution Flow'\n"
        "- Add numbered steps underneath (1., 2., 3...)\n"
    )


@pytest.mark.p1_guard
def test_docs_include_required_mermaid_diagrams() -> None:
    docs = _pick_docs_to_scan()
    scanned = []
    all_blocks: list[str] = []
    for p in docs:
        text = _read_text(p)
        scanned.append(p.as_posix())
        all_blocks.extend(_extract_mermaid_blocks(text))

    if not all_blocks:
        pytest.fail(
            "P1 docs guard: No ```mermaid fenced blocks found.\n"
            "Searched in:\n" + "\n".join(f"  - {s}" for s in scanned) + "\n\n"
            "Fix:\n"
            "- Add at least one mermaid flowchart and two mermaid sequenceDiagram blocks.\n"
        )

    ok, details = _has_required_mermaid(all_blocks)
    if ok:
        return

    pytest.fail(
        "P1 docs guard: Mermaid requirements not satisfied.\n"
        f"Detected:\n"
        f"  - flowchart: {details['flowchart']}\n"
        f"  - sequence (happy): {details['sequence_happy']}\n"
        f"  - sequence (failure): {details['sequence_failure']}\n\n"
        "Requirements:\n"
        "- At least 1 mermaid flowchart\n"
        "- At least 2 mermaid sequenceDiagram blocks (happy + failure) OR explicitly labeled inside blocks\n\n"
        "Searched in:\n" + "\n".join(f"  - {s}" for s in scanned) + "\n"
    )
