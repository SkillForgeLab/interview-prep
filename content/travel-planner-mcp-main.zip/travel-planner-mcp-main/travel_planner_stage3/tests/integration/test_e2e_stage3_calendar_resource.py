import pytest
from fastapi.testclient import TestClient

from gateway.app import create_app


@pytest.mark.asyncio
async def test_gateway_resources_read_calendar_happy_path():
    app = create_app()

    payload = {
        "jsonrpc": "2.0",
        "id": "1",
        "method": "resources.read",
        "params": {
            "tenant_id": "t1",
            "use_case_id": "travel_planner",
            "stage_id": 3,
            "correlation_id": "corr",
            "uri": "calendar://upcoming_with_query/t1",
        },
    }

    with TestClient(app) as client:
        r = client.post("/mcp/jsonrpc", json=payload)
        assert r.status_code == 200
        data = r.json()

        assert data["error"] is None
        assert data["result"]["domain"] == "calendar"
        assert data["result"]["uri"] == "calendar://upcoming_with_query/t1"

        contents = data["result"]["result"]["contents"]
        assert isinstance(contents, list)
        assert len(contents) >= 1
        assert contents[0]["uri"] == "calendar://upcoming_with_query/t1"
        assert "events" in contents[0]["text"]
