import os
import asyncio

import pytest
from fastapi.testclient import TestClient

from gateway.app import create_app
from orchestrator.gateway_client import GatewayClient, GatewayContext


@pytest.mark.asyncio
async def test_gateway_policy_denies_unknown_tool():
    app = create_app()
    client = TestClient(app)

    # manual JSON-RPC request to ensure deny path is stable
    payload = {
        "jsonrpc": "2.0",
        "id": "1",
        "method": "tools.call",
        "params": {
            "tenant_id": "tenantA",
            "use_case_id": "travel_planner_agentic_mcp",
            "stage_id": 3,
            "correlation_id": "corr",
            "tool": "evil.delete_everything",
            "arguments": {},
        },
    }
    with TestClient(app) as client:
        r = client.post("/mcp/jsonrpc", json=payload)
        assert r.status_code == 200
        data = r.json()
        assert data["error"]["code"] == 403
        assert data["error"]["message"] == "tool_denied"


@pytest.mark.asyncio
async def test_gateway_tools_list_filters():
    app = create_app()
    client = TestClient(app)

    payload = {
        "jsonrpc": "2.0",
        "id": "1",
        "method": "tools.list",
        "params": {
            "tenant_id": "tenantA",
            "use_case_id": "travel_planner_agentic_mcp",
            "stage_id": 3,
            "correlation_id": "corr",
        },
    }
    with TestClient(app) as client:
        r = client.post("/mcp/jsonrpc", json=payload)
        data = r.json()
        assert "weather.get_forecast" in data["result"]["tools"]
        assert "travel.search_flights" in data["result"]["tools"]
