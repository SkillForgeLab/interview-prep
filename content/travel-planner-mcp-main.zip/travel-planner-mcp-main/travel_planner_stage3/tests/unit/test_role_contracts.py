import json
from orchestrator.schemas import NextStep, ToolArgs, CriticDecision, FinalAnswer


def test_next_step_contract():
    ns = NextStep.model_validate({"step_no": 1, "action": "finish", "rationale": "done", "uri": None, "tool": None})
    assert ns.action == "finish"


def test_tool_args_payload_is_json_string():
    ta = ToolArgs.model_validate({"step_no": 2, "tool": "weather.get_forecast", "payload_json": "{\"location\":\"PHX\",\"days\":2}"})
    assert json.loads(ta.payload_json)["days"] == 2


def test_critic_decision_contract():
    cd = CriticDecision.model_validate({"step_no": 1, "allow": True, "reason": "ok"})
    assert cd.allow is True


def test_final_answer_contract():
    fa = FinalAnswer.model_validate({"answer": "hello"})
    assert fa.answer == "hello"
