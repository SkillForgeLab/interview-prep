from shared.jsonrpc import JsonRpcRequest
from pydantic import ValidationError


def test_jsonrpc_requires_2_0():
    try:
        JsonRpcRequest.model_validate({"jsonrpc": "1.0", "id": "1", "method": "x", "params": {}})
        assert False
    except ValidationError:
        assert True
