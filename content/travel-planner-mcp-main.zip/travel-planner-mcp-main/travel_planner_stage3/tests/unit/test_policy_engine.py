from gateway.catalog import stage3_default_catalog
from gateway.policy import PolicyContext, PolicyEngine


def test_policy_filters_tools_and_resources():
    policy = PolicyEngine(catalog=stage3_default_catalog())
    ctx = PolicyContext(tenant_id="tenantA", use_case_id="travel_planner_agentic_mcp", stage_id=3)

    tools = policy.visible_tools(ctx)
    assert "weather.get_forecast" in tools
    assert "travel.search_flights" in tools

    prefixes = policy.visible_resource_prefixes(ctx)
    assert "calendar://" in prefixes


def test_policy_denies_unknown_tool():
    policy = PolicyEngine(catalog=stage3_default_catalog())
    ctx = PolicyContext(tenant_id="tenantA", use_case_id="travel_planner_agentic_mcp", stage_id=3)

    try:
        policy.authorize_tool(ctx, "evil.delete_everything")
        assert False, "expected deny"
    except PermissionError as e:
        assert str(e) == "tool_denied"
