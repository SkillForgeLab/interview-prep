# 'Step-by-step Code Execution Flow'

## 0) Entry point

1. `orchestrator/main.py`(your CLI entry) builds ReactDeps:
    - `GatewayClient`
    - `ReasoningAdapter`
    - `EvidenceStore`
    - IDs: `tenant_id`, `use_case_id`, `stage_id`, `correlation_id`

2. `main.py` calls:
    - `await run_react_loop(deps=deps, goal=..., max_steps=...)`

---

## 1) Context + Gateway catalog bootstrap

3. `run_react_loop()` creates a logging context:
    - `adapter = with_ctx(logger, LogContext(...))`
    - This makes every log line carry tenant/use_case/stage/correlation.

4. `run_react_loop()` creates `gctx = GatewayContext(...)`
    - This is what the Gateway uses for filtering/policy enforcement.

5. `tools = await deps.gateway.tools_list(ctx=gctx)`
    - Orchestrator asks Gateway: “What tools are allowed for this context?”

6. `catalog = {"tools": tools, "resources": ["calendar://"], "tenant_id": ...}`
    - This “catalog” is the input to the planner/reasoner.

---


## 2) ReAct loop per step (step_no = 1..max_steps)

For each step_no:

### 2.1 Reason (Planner)

7. Log: `react.reason`

8. `step = deps.reasoning.plan_next_step(goal, step_no, catalog, evidence=deps.memory.items)`
    - Returns a `NextStep` with:
      - `action`: `resource_read` | `tool_call` | `finish` 
      - plus `uri` or `tool` depending on action


### 2.2 Critic (Guardrail)

9. Log: `react.critic`

10. `decision = deps.reasoning.review_step(goal, step, evidence)`

11. If `decision.allow` is `False`:
    - Log: `react.veto`
    - Return: `Stopped: critic_veto. Reason: ...`
    - Loop ends.
---

## 3) Act + Observe paths

### A) If `step.action` == `"resource_read"`

12. Validate: `step.uri` must exist, else `Stopped: invalid_step_missing_uri`

13. Log: `react.act` (resources.read)

14. `res = await deps.gateway.resources_read(ctx=gctx, uri=step.uri)`

15. Memory append:
    - `deps.memory.append(step_no=..., kind="resource", payload=res)`

16. Log: `react.observe` (kind=resource)

17. `continue` to next loop step.



### b) If `step.action` == `"tool_call"`

18. Validate: `step.tool` must exist, else `Stopped: invalid_step_missing_tool`

19. Log: `react.act` (role=executor)

20. `tool_args = deps.reasoning.build_tool_args(goal, step, evidence)`
      - Returns something like: `{ payload_json: "<string>" }`

21. Decode tool arguments:
    - `arguments = json.loads(tool_args.payload_json)`
    -  #### Failure guard you added:
      - If `JSONDecodeError` → log `react.stop` + return `Stopped`: `invalid_tool_args_json`

22. Log: `react.act` tools.call, tool=step.tool)

23. `out = await deps.gateway.tools_call(ctx=gctx, tool=step.tool, arguments=arguments)`

24. Memory append:
    - `deps.memory.append(step_no=..., kind="tool", payload=out)`

25. Log: `react.observe` (kind=tool)

26. `continue` to next loop step.


### C) If `step.action` == `"finish"`

27. Log: `react.finish`

28. `final = deps.reasoning.summarize(goal, evidence=deps.memory.items)`

29. Return `final.answer`.


---

## 4) Loop termination conditions

30. If action is none of the expected values:
    - Return: `Stopped`: `unknown_action`

31. If loop completes `max_steps` without finish:
    - Return: Stopped: `max_steps_exceeded`

---
