#  Technical-design

## What each layer owns

### Orchestrator

**Owns:**

- ReAct loop state (for step_no in range(...))
- Evidence lifecycle (EvidenceStore.append)
- LLM role calls in correct order (Planner → Critic → Executor → Summarizer)
- Gateway calls (tools.list, resources.read, tools.call)
 
**Does not own:**

- Tool/resource authorization
- Domain dispatching
- JSON-RPC validation

### Gateway
**Owns:**
- JSON-RPC request validation (JsonRpcRequest.model_validate)
- Policy enforcement (PolicyEngine)
- Domain routing (domain_for_tool, domain_for_resource)
- MCP dispatch (McpRouter.call_tool, McpRouter.read_resource)
- Error mapping to JSON-RPC errors

**Does not own:**
- ReAct logic
- LLM reasoning
- Evidence state

### Domains (MCP servers behind McpRouter)
**Own:**
- Actual resource/tool implementation
- Throwing McpError on domain-side failures


## “Code execution flow” checklist (what to trace when debugging)
For a single request, the most useful trace points (you already log many of these):

### Orchestrator
- react.reason (planner)
- react.critic (critic)
- react.veto (reason)
- react.act:
  - action=resources.read OR tools.call
- react.observe (memory append)
- react.finish

### Gateway
- jsonrpc.request (method)
- For method-specific:
  - authorize_tool/resource 
  - domain_for_tool/resource 
  - mcp_router_not_ready (503)
  - mapped errors: 422/403/404/504/500