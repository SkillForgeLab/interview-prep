## In-depth architecture diagram
```mermaid
flowchart LR
  U[User CLI\npython -m orchestrator.main] --> RL[orchestrator.react_loop\nrun_react_loop]

  RL -->|Planner: NextStep| LLM1[ReasoningAdapter\nplan_next_step]
  RL -->|Critic: CriticDecision| LLM2[ReasoningAdapter\nreview_step]
  RL -->|Executor: ToolArgs| LLM3[ReasoningAdapter\nbuild_tool_args]
  RL -->|Summarizer: FinalAnswer| LLM4[ReasoningAdapter\nsummarize]

  RL -->|HTTP POST /jsonrpc\nmethod=tools.list| GW[FastAPI Gateway\nhandle_jsonrpc]
  RL -->|HTTP POST /jsonrpc\nmethod=resources.read| GW
  RL -->|HTTP POST /jsonrpc\nmethod=tools.call| GW

  GW -->|validate req| JR[JsonRpcRequest.model_validate]
  GW -->|policy| PE[PolicyEngine\nvisible_tools/authorize/domain_for_*]
  GW -->|dispatch| MR[McpRouter\ncall_tool/read_resource]

  MR --> CAL[Calendar MCP server\nread_resource]
  MR --> WEA[Weather MCP server\ncall_tool]
  MR --> TRV[Travel MCP server\ncall_tool]

  RL --> MEM[EvidenceStore\nappend/items]

```

---

## Consolidated sequence diagram (happy path)
This matches real orchestration order + gateway method names.

```mermaid
sequenceDiagram
  autonumber
  actor User
  participant RL as orchestrator.react_loop
  participant RA as ReasoningAdapter
  participant GC as GatewayClient
  participant GW as Gateway /jsonrpc
  participant PE as PolicyEngine
  participant MR as McpRouter
  participant Cal as Calendar Domain
  participant Wea as Weather Domain
  participant Trv as Travel Domain
  participant Mem as EvidenceStore

  User->>RL: run_react_loop(goal)

  %% Catalog
  RL->>GC: tools_list(gctx)
  GC->>GW: JSON-RPC tools.list
  GW->>PE: visible_tools(pctx)
  PE-->>GW: tools[]
  GW-->>GC: JsonRpcResponse(tools)
  GC-->>RL: tools[]
  RL-->>RL: catalog={tools, resources, tenant_id}

  %% Step 1: resource
  RL->>RA: plan_next_step(step_no=1, evidence=[])
  RA-->>RL: NextStep(resource_read, uri=...)
  RL->>RA: review_step(step1)
  RA-->>RL: CriticDecision(allow=true)
  RL->>GC: resources_read(gctx, uri)
  GC->>GW: JSON-RPC resources.read
  GW->>PE: authorize_resource + domain_for_resource
  GW->>MR: read_resource(domain, uri, ctx)
  MR->>Cal: read_resource(uri)
  Cal-->>MR: result
  MR-->>GW: result
  GW-->>GC: JsonRpcResponse(result)
  GC-->>RL: res
  RL->>Mem: append(kind=resource)

  %% Step 2: weather tool
  RL->>RA: plan_next_step(step_no=2, evidence=[calendar])
  RA-->>RL: NextStep(tool_call, tool=weather.get_forecast)
  RL->>RA: review_step(step2)
  RA-->>RL: CriticDecision(allow=true)
  RL->>RA: build_tool_args(step2, evidence)
  RA-->>RL: ToolArgs(payload_json)
  RL->>GC: tools_call(gctx, tool, arguments)
  GC->>GW: JSON-RPC tools.call
  GW->>PE: authorize_tool + domain_for_tool
  GW->>MR: call_tool(domain, tool, args, ctx)
  MR->>Wea: call_tool(tool,args)
  Wea-->>MR: forecast
  MR-->>GW: forecast
  GW-->>GC: JsonRpcResponse(result)
  GC-->>RL: out
  RL->>Mem: append(kind=tool)

  %% Step 3: travel tool
  RL->>RA: plan_next_step(step_no=3, evidence=[calendar, weather])
  RA-->>RL: NextStep(tool_call, tool=travel.search_flights)
  RL->>RA: review_step(step3)
  RA-->>RL: CriticDecision(allow=true)
  RL->>RA: build_tool_args(step3, evidence)
  RA-->>RL: ToolArgs(payload_json)
  RL->>GC: tools_call(gctx, tool, arguments)
  GC->>GW: JSON-RPC tools.call
  GW->>PE: authorize_tool + domain_for_tool
  GW->>MR: call_tool(domain, tool, args, ctx)
  MR->>Trv: call_tool(tool,args)
  Trv-->>MR: flights
  MR-->>GW: flights
  GW-->>GC: JsonRpcResponse(result)
  GC-->>RL: out
  RL->>Mem: append(kind=tool)

  %% Step 4: finish
  RL->>RA: plan_next_step(step_no=4, evidence=[...])
  RA-->>RL: NextStep(finish)
  RL->>RA: review_step(step4)
  RA-->>RL: CriticDecision(allow=true)
  RL->>RA: summarize(goal, evidence)
  RA-->>RL: FinalAnswer(answer)
  RL-->>User: answer

```

---

## Failure path sequence diagrams (consolidated)

### A) Critic veto (your exact stop behavior)

```mermaid
sequenceDiagram
  autonumber
  participant RL as orchestrator.react_loop
  participant RA as ReasoningAdapter

  RL->>RA: plan_next_step(...)
  RA-->>RL: NextStep(...)
  RL->>RA: review_step(step)
  RA-->>RL: CriticDecision(allow=false, reason)
  RL-->>RL: log react.veto
  RL-->>RL: return "Stopped: critic_veto. Reason: <reason>"

```

---


### B) ToolArgs invalid JSON (your exact json.loads boundary)

```mermaid
sequenceDiagram
  autonumber
  participant RL as orchestrator.react_loop
  participant RA as ReasoningAdapter

  RL->>RA: build_tool_args(step, evidence)
  RA-->>RL: ToolArgs(payload_json="...")
  RL-->>RL: json.loads(payload_json) raises JSONDecodeError
  RL-->>RL: (unhandled here) -> propagates unless caught upstream

```
#### Why this matters: 
In your current run_react_loop, json.loads(...) is not wrapped, so this becomes an orchestrator-side crash, not a JSON-RPC error.

---


### C) 

```mermaid
sequenceDiagram
  autonumber
  participant GC as GatewayClient
  participant GW as Gateway /jsonrpc

  GC->>GW: JSON-RPC tools.call/resources.read (bad params)
  GW-->>GW: ToolsCallParams/ResourceReadParams validation fails
  GW-->>GC: JsonRpcResponse(error code=422, message="invalid_params")

```

---



### D) 

```mermaid
sequenceDiagram
  autonumber
  participant GW as Gateway /jsonrpc
  participant PE as PolicyEngine

  GW->>PE: authorize_tool / authorize_resource
  PE--xGW: raises PermissionError
  GW-->>GW: map to code=403

```

---


### E) 

```mermaid
sequenceDiagram
  autonumber
  participant GW as Gateway /jsonrpc

  GW-->>GW: mcp_router missing or wrong type
  GW-->>GW: return code=503 "mcp_router_not_ready"

```

---



### F) 

```mermaid
sequenceDiagram
  autonumber
  participant GW as Gateway /jsonrpc
  participant MR as McpRouter
  participant Dom as Domain

  GW->>MR: call_tool/read_resource
  MR->>Dom: execute
  Dom--xMR: raises McpError
  MR--xGW: McpError bubbles
  GW-->>GW: except McpError -> code=404 message="mcp_error"

```

---



### G) 

```mermaid
sequenceDiagram
  autonumber
  participant GW as Gateway /jsonrpc
  participant MR as McpRouter

  GW->>MR: call_tool/read_resource
  MR--xGW: raises TimeoutError
  GW-->>GW: map to code=504 message="timeout"

```

---