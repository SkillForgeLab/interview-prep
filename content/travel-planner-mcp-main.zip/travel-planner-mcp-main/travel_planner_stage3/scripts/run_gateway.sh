#!/usr/bin/env bash
set -euo pipefail
uv run python -c "from gateway.app import create_app; import uvicorn; uvicorn.run(create_app(), host='127.0.0.1', port=8080, log_level='info')"
