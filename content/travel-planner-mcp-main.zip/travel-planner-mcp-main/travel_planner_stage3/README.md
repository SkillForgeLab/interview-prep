# Travel Planner (Stage 2) — Multi-server planning (read-only)

---

## Goal of This Stage (Read First)
- Add four LLM roles: Planner, Executor, Critic, Summarizer.
- Enforce separation of duties via strict role contracts.
- Preserve Orchestrator → Gateway → Domain boundaries.
- Keep ReAct explicit: Reason → Act → Observe.
- Enable stage-3 controls: tool filtering, validation, structured logs, timeouts.

## Purpose and scope
This stage prevents “one model does everything”.
Roles reduce coupling and make debugging easier.
MCP does not define roles, ReAct, or memory.
Not covered by MCP; implemented as application logic.

---

## Architecture, responsibilities, boundaries
- Orchestrator calls only Gateway (HTTP JSON-RPC).
- Gateway is the only HTTP entry point.
- Domains are never exposed to Orchestrator.
- No domain-to-domain calls.


## Evidence Map (resource URI → decision impact)
### Calendar resources
- calendar://events/week
  - Impact: Determines feasible travel windows (free time blocks).
  - If missing: Planner must ask the user for availability or finish with uncertainty.

### Weather tools
- weather.get_forecast(city, start_date, end_date)
  - Impact: Filters candidate windows by weather constraints (e.g., avoid storms).
  - If missing: Planner continues with flights but marks forecast as unknown.

### Travel tools
- travel.search_flights(origin, destination, depart_date, return_date)
  - Impact: Produces flight options for feasible date windows.
  - If missing: Planner cannot propose flight options.

---

## What you get
- 3 **MCP servers** started by the gateway via `stdio`
    - Travel server (tools): `travel.search_flights`
    - Weather server (tools): `weather.get_forecast`
    - Calendar server (resources): `calendar://events?...`


- **Gateway** that exposes `MCP-style JSON-RPC` over `HTTP`:
    - `tools/list`
    - `tools/call`
    - `resources/list`
    - `resources/read`
  

- **Orchestrator** that runs an explicit `ReAct` loop:
    - **Planner** decides next step and explains why (routing decisions)
    - `Act` uses Gateway only
    - Observe stores normalized structured evidence 
    - Uses `FakeReasoningAdapter`
    - Deterministic and testable


- **Persistence**
  - sqlite
  - Tenant-isolated queries


- **Tests**
  - Unit test: tenant isolation
  - Integration test: HTTP → Gateway → MCP → DB
---

## macOS (Intel) — Run Instructions

### Prerequisites
- macOS (Intel)
- uv installed
- Python 3.11+

### Required env vars:
- OPENAI_API_KEY (required for orchestrator planning)
- OPENAI_MODEL (default: gpt-5.2)
- GATEWAY_URL (default: http://127.0.0.1:8080/mcp)
- APP_DB_PATH (default: ./data/app.db)
- TENANT_ID (default: tenant_dem

## Environment Configuration
### File: `.env.example`
```env
ENV=development

# OpenAI (optional for live model; tests do not require this)
OPENAI_API_KEY=changeme
OPENAI_MODEL=gpt-4.1-mini

# Orchestrator -> Gateway
GATEWAY_URL=http://127.0.0.1:8080/mcp
HTTP_TIMEOUT_SECONDS=10

# sqlite
APP_DB_PATH=./data/app.db
TENANT_ID=tenant_demo


# Domain servers (started by Gateway over stdio)
TRAVEL_SERVER_COMMAND=uv
TRAVEL_SERVER_ARGS=run,python,-m,domains.travel.server

WEATHER_SERVER_COMMAND=uv
WEATHER_SERVER_ARGS=run,python,-m,domains.weather.server

CALENDAR_SERVER_COMMAND=uv
CALENDAR_SERVER_ARGS=run,python,-m,domains.calendar.server

#------------------------------------------------------------------------------
# BEGIN: DEV ONLY CONFIG
#------------------------------------------------------------------------------

# json  (default, production-safe),
# true  (adds blank line between logs (dev only))
# prety (pretty + blank line (local development))
LOG_MODE=pretty
LOG_PRETTY=true

```

## Setup (Follow in Order)

### 1. Verify CPU architecture
```bash
uname -m
```
#### Expected 
- x86_64


### 2. Verify `uv`
```bash
which uv
uv --version
```

#### If missing, run 
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
#### Restart terminal after install.


### 3. Create virtual environment

#### a. Clone / enter project directory
```bash
cd travel_planner_stage3
```
#### Directory must contain:
- pyproject.toml
- src/
- scripts/
- tests/

### b. Copy environment variables
```bash
cp .env.example .env
```

### c. Enable environment variables
```bash
set -a
source .env
set +a
```

#### b. Install `.venv`
```bash
rm -rf .venv
uv venv
```

#### c. Activate `.venv`
```bash
source .venv/bin/activate
```

#### d. Verify Python
```bash
which python
uv run python --version
```
#### Expected
- .../travel_planner_stage1/.venv/bin/python
- Python 3.11.14


### 4. Install dependencies
```bash
uv pip install -e ".[dev]"
```
#### Expected
- No errors
- mcp, fastapi, uvicorn, httpx installed

### Terminal 1 — Start Calendar domain server
```bash
set -a
source .env
source .venv/bin/activate
chmod +x scripts/run_domain_calendar.sh
set +a
./scripts/run_domain_calendar.sh
```

**Expected:**  
Server keeps running (no output)

### Terminal 2 — Start Weather domain server
```bash
set -a
source .env
source .venv/bin/activate
chmod +x scripts/run_domain_weather.sh
set +a
./scripts/run_domain_weather.sh
```

**Expected:**  
Server keeps running (no output)


### Terminal 3 — Start Travel domain server
```bash
set -a
source .env
source .venv/bin/activate
chmod +x scripts/run_domain_travel.sh
set +a
./scripts/run_domain_travel.sh
```

**Expected:**  
Server keeps running (no output)


### Terminal 4 — Start Gateway
```bash
set -a
source .env
source .venv/bin/activate
chmod +x scripts/run_gateway.sh
set +a
./scripts/run_gateway.sh
```

**Expected:**  
- INFO:     Started server process [54359]
- INFO:     Waiting for application startup. 
- INFO:     Application startup complete. 
- INFO:     Uvicorn running on http://127.0.0.1:8080 (Press CTRL+C to quit)

- Logs include `jsonrpc.request`


### Terminal 5 — Verify Gateway endpoints (quick smoke tests)

#### a1. List tools:
```bash
curl -s http://127.0.0.1:8080/mcp/jsonrpc \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"1",
    "method":"tools.list",
    "params":{
      "tenant_id":"t1",
      "use_case_id":"travel_planner",
      "stage_id":3,
      "correlation_id":"c1"
    }
  }' | jq
```
#### Expected output:
- HTTP 200
- JSON with at least one tool:
- -  search_flights


#### a2. List tools with headers (curl -i instead of -h and no |jq at the end):
```bash
curl -i http://127.0.0.1:8080/mcp/jsonrpc \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"1",
    "method":"tools.list",
    "params":{
      "tenant_id":"t1",
      "use_case_id":"travel_planner",
      "stage_id":3,
      "correlation_id":"c1"
    }
  }' 
```


#### b. Read calendar availability resource:
```bash
curl -i http://127.0.0.1:8080/mcp/jsonrpc \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"2",
    "method":"resources.read",
    "params":{
      "tenant_id":"t1",
      "use_case_id":"travel_planner",
      "stage_id":3,
      "correlation_id":"c1",
      "uri":"calendar://upcoming_with_query?tenant_id=t1"
    }
  }'

```


#### c. Call resource:
```bash
curl -s http://127.0.0.1:8080/mcp/jsonrpc \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"6",
    "method":"tools/call",
    "params":{
      "name":"weather.get_forecast",
      "arguments":{
        "payload":{
          "tenant_id":"tenant_demo",
          "location":"San Francisco",
          "date":"2026-01-21",
          "days":3
        }
      }
    }
  }' | jq
```

### Terminal 6 — Run the Orchestrator
```bash
set -a; 
source .env
source .venv/bin/activate
chmod +x scripts/run_orchestrator.sh
set +a
./scripts/run_orchestrator.sh
```
**Expected:**  
- A final answer printed.
- Logs show `react.reason`, `react.act`, `react.observe`, `react.finish`.



### Terminal 4 — Tests (Required for Definition of Done)
```bash
set -a
source .env
source .venv/bin/activate
set +a
uv run pytest -q
```
#### Expected:
- All tests pass.
#### Tests include:
- Unit test: tenant isolation
- Integration test: real HTTP → Gateway → MCP → sqlite


## Clean shutdown
 In all terminals:
```bash
Ctrl+C
```
#### Order does not matter.


## 📌 Troubleshooting: FAQ

###  1) Prove the server is FastAPI and see what routes exist
```bash
curl -s http://127.0.0.1:8080/openapi.json | jq '.paths | keys'
```
###  2) If /mcp is missing, find what *is* present (common: /jsonrpc, /rpc, /, /api/mcp)
Try one of these quickly
```bash
curl -s http://127.0.0.1:8080/jsonrpc -H 'content-type: application/json' -d '{"jsonrpc":"2.0","id":"1","method":"tools/list","params":{}}' | jq
```
```bash
curl -s http://127.0.0.1:8080/rpc     -H 'content-type: application/json' -d '{"jsonrpc":"2.0","id":"1","method":"tools/list","params":{}}' | jq
```

### 3) After any code change reload Gateway
```bash
uv run uvicorn gateway.app:create_app --host 127.0.0.1 --port 8080 --reload
```

### 4) run uvicorn with debug + watch console
```bash
uv run uvicorn gateway.app:create_app --factory --host 127.0.0.1 --port 8080 --reload --log-level debug
```


### 5) To confirm your installed SDK supports responses.parse:
```bash
uv run python -c "from openai import OpenAI; c=OpenAI(); print(hasattr(c.responses,'parse'))"
```
#### Expected: `True`


---

## Troubleshooting: Common failure symptoms & fixes

uv run python -c "import domains.travel.server as s; print('OK', s)"
uv run python -c "import src.domains.travel.server as s; print('OK', s)"
 
### ❌ Gateway returns JSON-RPC error
- `jsonrpc_error: {'code': 403, 'message': 'tool_denied'}`
  - **Meaning:** policy filtering blocked tool usage for this context.
- `invalid_jsonrpc`
  - **Meaning:** OpenAI schema error (400 invalid_json_schema)
- OpenAI schema error (400 invalid_json_schema)
  - **Meaning:** strict JSON schema rejected by model/SDK. 
  - Use fallback plan: set response_format to plain JSON and validate with Pydantic after.

### ❌ Orchestrator observation is text-only JSON
- Stage 2 includes observation normalization logic.
- The orchestrator will parse JSON text into structured dict when possible.

## Stage 2 exit checklist

 - I can explain why the planner called Calendar before Weather.
 - I can point to one log line that explains each next step. 
 - I can show one “resource URI → decision impact” mapping. 
 - I can run everything using ONLY this README on macOS Intel.