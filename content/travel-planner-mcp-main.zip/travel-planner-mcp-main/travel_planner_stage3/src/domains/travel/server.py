from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from domains.travel.schemas import SearchFlightsArgs

mcp = FastMCP("travel", json_response=True)


@mcp.tool(name="travel.search_flights", description="Search flights (deterministic stub).")
def travel_search_flights(origin: str, destination: str, depart_date: str, passengers: int) -> dict:
    args = SearchFlightsArgs.model_validate(
        {"origin": origin, "destination": destination, "depart_date": depart_date, "passengers": passengers}
    )
    return {
        "query": args.model_dump(),
        "options": [
            {"carrier": "ExampleAir", "flight": "EA123", "price_usd": 320, "duration_min": 185},
            {"carrier": "SampleJet", "flight": "SJ456", "price_usd": 355, "duration_min": 170},
        ],
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
