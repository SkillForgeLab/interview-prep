from __future__ import annotations

from pydantic import BaseModel, Field


class SearchFlightsArgs(BaseModel):
    origin: str = Field(min_length=3, max_length=3)
    destination: str = Field(min_length=3, max_length=3)
    depart_date: str = Field(min_length=8)  # keep simple for stage 3
    passengers: int = Field(ge=1, le=9)
