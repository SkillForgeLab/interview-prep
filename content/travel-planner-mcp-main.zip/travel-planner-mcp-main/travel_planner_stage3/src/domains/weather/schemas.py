from __future__ import annotations

from pydantic import BaseModel, Field


class GetForecastArgs(BaseModel):
    location: str = Field(min_length=2)
    days: int = Field(ge=1, le=10)
