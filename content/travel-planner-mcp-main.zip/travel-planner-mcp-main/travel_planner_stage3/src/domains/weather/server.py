from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP
from domains.weather.schemas import GetForecastArgs

logger = logging.getLogger("domains.weather")

mcp = FastMCP("weather", json_response=True)


@mcp.tool(name="weather.get_forecast",
          description="Get a deterministic weather forecast (stub).")
def weather_get_forecast(location: str, days: int, correlation_id: str | None = None) -> dict:
    # correlation_id is optional and safe (read-only); helps end-to-end tracing.
    if correlation_id:
        logger.info("tool.call", extra={"correlation_id": correlation_id, "tool": "weather.get_forecast"})

    args = GetForecastArgs.model_validate({"location": location, "days": days})
    return {
        "location": args.location,
        "days": args.days,
        "forecast": [
            {"day": i + 1, "summary": "Clear", "high_c": 24 + i, "low_c": 12 + i}
            for i in range(args.days)
        ],
    }


if __name__ == "__main__":
    # stdio transport is appropriate for internal SDK-supported transport
    mcp.run(transport="stdio")
