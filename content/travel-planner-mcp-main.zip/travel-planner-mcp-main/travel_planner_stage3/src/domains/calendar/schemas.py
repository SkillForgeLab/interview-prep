from __future__ import annotations

from pydantic import BaseModel, Field


class UpcomingQuery(BaseModel):
    tenant_id: str = Field(min_length=1)
    query: str | None = None
