from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from domains.calendar.schemas import UpcomingQuery

mcp = FastMCP("calendar", json_response=True)


# Matches: calendar://upcoming_with_query/t1
@mcp.resource("calendar://upcoming_with_query/{tenant_id}")
def upcoming_with_query(tenant_id: str) -> dict:
    UpcomingQuery.model_validate({"tenant_id": tenant_id, "query": None})
    return {
        "tenant_id": tenant_id,
        "query": None,
        "events": [
            {"title": "Work meeting", "start": "2026-02-02T10:00:00", "end": "2026-02-02T11:00:00"},
            {"title": "Dentist", "start": "2026-02-03T15:00:00", "end": "2026-02-03T16:00:00"},
        ],
    }


# Matches: calendar://upcoming_with_query/t1/project
@mcp.resource("calendar://upcoming_with_query/{tenant_id}/{query}")
def upcoming_with_query_with_text(tenant_id: str, query: str) -> dict:
    UpcomingQuery.model_validate({"tenant_id": tenant_id, "query": query})
    return {
        "tenant_id": tenant_id,
        "query": query,
        "events": [
            {"title": "Work meeting", "start": "2026-02-02T10:00:00", "end": "2026-02-02T11:00:00"},
            {"title": "Dentist", "start": "2026-02-03T15:00:00", "end": "2026-02-03T16:00:00"},
        ],
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
