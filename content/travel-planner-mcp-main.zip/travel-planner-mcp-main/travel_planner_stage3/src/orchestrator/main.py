from __future__ import annotations

import os
import sys

from dotenv import load_dotenv

from shared.ids import new_correlation_id
from shared.logging import configure_logging
from orchestrator.gateway_client import GatewayClient
from orchestrator.memory import EvidenceStore
from orchestrator.reasoning_adapter import ReasoningAdapter
from orchestrator.react_loop import ReactDeps, run_react_loop


async def main() -> None:
    load_dotenv()
    configure_logging()

    api_key = os.environ["OPENAI_API_KEY"]
    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")  # explicit model for this stage
    gateway_url = os.getenv("GATEWAY_URL", "http://127.0.0.1:8080/mcp")

    tenant_id = os.getenv("TENANT_ID", "tenantA")
    use_case_id = os.getenv("USE_CASE_ID", "travel_planner_agentic_mcp")
    stage_id = int(os.getenv("STAGE_ID", "3"))

    deps = ReactDeps(
        tenant_id=tenant_id,
        use_case_id=use_case_id,
        stage_id=stage_id,
        correlation_id=new_correlation_id(),
        gateway=GatewayClient(base_url=gateway_url, timeout_s=5.0),
        reasoning=ReasoningAdapter(api_key=api_key, model=model),
        memory=EvidenceStore(),
    )

    # Goal precedence:
    # 1) CLI args (if provided)
    # 2) GOAL env var
    # 3) default string
    cli_goal = " ".join(sys.argv[1:]).strip()
    goal = cli_goal or os.getenv("GOAL") or "Plan a short trip avoiding my calendar conflicts and considering weather."

    answer = await run_react_loop(deps=deps, goal=goal, max_steps=8)
    print(answer)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
