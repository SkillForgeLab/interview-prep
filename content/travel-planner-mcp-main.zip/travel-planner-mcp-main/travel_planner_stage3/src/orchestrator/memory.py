from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvidenceStore:
    items: list[dict[str, Any]] = field(default_factory=list)

    def append(self, *, step_no: int, kind: str, payload: dict[str, Any]) -> None:
        self.items.append({"step_no": step_no, "kind": kind, "payload": payload})
