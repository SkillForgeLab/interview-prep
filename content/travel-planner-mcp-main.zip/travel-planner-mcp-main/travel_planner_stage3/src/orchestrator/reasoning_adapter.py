from __future__ import annotations

import json
import logging
from typing import Any, Type, TypeVar

from openai import OpenAI
from pydantic import BaseModel

from orchestrator.prompts import (
    CRITIC_SYSTEM,
    EXECUTOR_SYSTEM,
    PLANNER_SYSTEM,
    SUMMARIZER_SYSTEM,
)
from orchestrator.schemas import CriticDecision, FinalAnswer, NextStep, ToolArgs

logger = logging.getLogger("orchestrator.reasoning_adapter")
T = TypeVar("T", bound=BaseModel)


def _strict_schema_for(model: str) -> dict[str, Any]:
    # Kept for backward compatibility / docs; not used by the fixed implementation.
    # Stage 3 uses Responses.parse(..., text_format=<PydanticModel>) instead.
    if model == "NextStep":
        return {
            "name": "next_step",
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "step_no": {"type": "integer", "minimum": 1},
                    "action": {"type": "string", "enum": ["resource_read", "tool_call", "finish"]},
                    "rationale": {"type": "string", "minLength": 1},
                    "uri": {"type": ["string", "null"]},
                    "tool": {"type": ["string", "null"]},
                },
                "required": ["step_no", "action", "rationale", "uri", "tool"],
            },
        }
    if model == "CriticDecision":
        return {
            "name": "critic_decision",
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "step_no": {"type": "integer", "minimum": 1},
                    "allow": {"type": "boolean"},
                    "reason": {"type": "string", "minLength": 1},
                },
                "required": ["step_no", "allow", "reason"],
            },
        }
    if model == "ToolArgs":
        return {
            "name": "tool_args",
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "step_no": {"type": "integer", "minimum": 1},
                    "tool": {"type": "string", "minLength": 1},
                    "payload_json": {"type": "string", "minLength": 2},
                },
                "required": ["step_no", "tool", "payload_json"],
            },
        }
    if model == "FinalAnswer":
        return {
            "name": "final_answer",
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {"answer": {"type": "string", "minLength": 1}},
                "required": ["answer"],
            },
        }
    raise ValueError("unknown_schema_model")


class ReasoningAdapter:
    """
    Stage 3 fix:
    - You are using the Responses API.
    - Responses API does NOT accept 'response_format=' (that is Chat Completions).
    - Use client.responses.parse(..., text_format=<PydanticModel>) for structured outputs.
    """

    def __init__(self, *, api_key: str, model: str):
        self._client = OpenAI(api_key=api_key)
        self._model = model

    def _responses_parse(self, *, system: str, user: str, text_format: Type[T]) -> T:
        """
        Structured Outputs for Responses API.
        Returns a Pydantic model instance.
        """
        resp = self._client.responses.parse(
            model=self._model,
            input=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            text_format=text_format,
        )

        parsed = resp.output_parsed
        if parsed is None:
            # Fallback: try to decode output_text if present (rare).
            try:
                raw = resp.output_text
            except Exception:  # pragma: no cover
                raw = None
            raise RuntimeError(f"responses.parse returned no output_parsed. output_text={raw!r}")

        return parsed

    def plan_next_step(
        self,
        *,
        goal: str,
        step_no: int,
        catalog: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> NextStep:
        # IMPORTANT: Give the model a concrete calendar URI (no templates like {tenant_id}).
        tenant_id = str(catalog.get("tenant_id") or "tenantA")

        msg = {
            "goal": goal,
            "step_no": step_no,
            "catalog": catalog,
            "evidence": evidence,
            "rules": [
                "Choose only the next step.",
                f"Step order is mandatory: (1) resource_read calendar://upcoming_with_query/{tenant_id}, "
                f"(2) tool_call weather.get_forecast, (3) tool_call travel.search_flights, (4) finish.",
                "When action=resource_read you must set uri to the exact calendar URI above.",
                "When action=tool_call you must set tool to one of the allowed tools from catalog.tools.",
            ],
        }

        # Parsed, validated NextStep (no manual json.loads needed)
        return self._responses_parse(system=PLANNER_SYSTEM, user=json.dumps(msg), text_format=NextStep)

    def review_step(self, *, goal: str, step: NextStep, evidence: list[dict[str, Any]]) -> CriticDecision:
        msg = {
            "goal": goal,
            "step": step.model_dump(),
            "evidence": evidence,
            "rules": ["Veto if step needs missing required inputs."],
        }
        return self._responses_parse(system=CRITIC_SYSTEM, user=json.dumps(msg), text_format=CriticDecision)

    def build_tool_args(self, *, goal: str, step: NextStep, evidence: list[dict[str, Any]]) -> ToolArgs:
        msg = {
            "goal": goal,
            "step": step.model_dump(),
            "evidence": evidence,
            "rules": [
                "You must only emit payload_json for the provided tool.",
                "payload_json must be valid JSON for the tool arguments.",
                "Do not add extra keys outside ToolArgs schema.",
            ],
            "tool_schemas": {
                "weather.get_forecast": {"location": "string", "days": "int(1..10)"},
                "travel.search_flights": {
                    "origin": "AAA",
                    "destination": "BBB",
                    "depart_date": "YYYY-MM-DD",
                    "passengers": "int",
                },
            },
        }

        args = self._responses_parse(system=EXECUTOR_SYSTEM, user=json.dumps(msg), text_format=ToolArgs)

        # Validate that payload_json is JSON (keeps your current safety check)
        json.loads(args.payload_json)
        return args

    def summarize(self, *, goal: str, evidence: list[dict[str, Any]]) -> FinalAnswer:
        msg = {"goal": goal, "evidence": evidence, "rules": ["No tools. Use evidence only."]}
        return self._responses_parse(system=SUMMARIZER_SYSTEM, user=json.dumps(msg), text_format=FinalAnswer)

    # Kept for compatibility if other code imports/calls it.
    # It now routes to parse(), because Responses.create() + response_format is not valid here.
    def _responses_json(self, *, system: str, user: str, schema: dict[str, Any]) -> dict[str, Any]:
        """
        Backward-compat shim.

        Your old code called this with a json_schema, but Responses.create() doesn't accept response_format.
        We map schema["name"] to the appropriate Pydantic type and return dict (model_dump()).
        """
        name = (schema or {}).get("name")
        model_map: dict[str, Type[BaseModel]] = {
            "next_step": NextStep,
            "critic_decision": CriticDecision,
            "tool_args": ToolArgs,
            "final_answer": FinalAnswer,
        }
        if name not in model_map:
            raise ValueError(f"Unknown schema name for _responses_json shim: {name!r}")

        parsed = self._responses_parse(system=system, user=user, text_format=model_map[name])
        return parsed.model_dump()
