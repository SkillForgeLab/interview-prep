from __future__ import annotations

from pydantic import BaseModel, Field
from typing import Literal


Action = Literal["resource_read", "tool_call", "finish"]


class NextStep(BaseModel):
    step_no: int = Field(ge=1)
    action: Action
    rationale: str = Field(min_length=1)
    uri: str | None = None
    tool: str | None = None


class ToolArgs(BaseModel):
    step_no: int = Field(ge=1)
    tool: str
    payload_json: str = Field(min_length=2)


class CriticDecision(BaseModel):
    step_no: int = Field(ge=1)
    allow: bool
    reason: str = Field(min_length=1)


class FinalAnswer(BaseModel):
    answer: str = Field(min_length=1)
