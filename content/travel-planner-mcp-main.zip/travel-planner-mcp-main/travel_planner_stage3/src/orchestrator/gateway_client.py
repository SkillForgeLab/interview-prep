from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True)
class GatewayContext:
    tenant_id: str
    use_case_id: str
    stage_id: int
    correlation_id: str


class GatewayClient:
    def __init__(self, *, base_url: str, timeout_s: float = 5.0):
        self._base_url = base_url.rstrip("/")
        self._timeout = httpx.Timeout(timeout_s)

    async def tools_list(self, *, ctx: GatewayContext) -> list[str]:
        result = await self._call(
            method="tools.list",
            params={
                "tenant_id": ctx.tenant_id,
                "use_case_id": ctx.use_case_id,
                "stage_id": ctx.stage_id,
                "correlation_id": ctx.correlation_id,
            },
        )
        return list(result["tools"])

    async def tools_call(self, *, ctx: GatewayContext, tool: str, arguments: dict[str, Any]) -> dict[str, Any]:
        return await self._call(
            method="tools.call",
            params={
                "tenant_id": ctx.tenant_id,
                "use_case_id": ctx.use_case_id,
                "stage_id": ctx.stage_id,
                "correlation_id": ctx.correlation_id,
                "tool": tool,
                "arguments": arguments,
            },
        )

    async def resources_read(self, *, ctx: GatewayContext, uri: str) -> dict[str, Any]:
        return await self._call(
            method="resources.read",
            params={
                "tenant_id": ctx.tenant_id,
                "use_case_id": ctx.use_case_id,
                "stage_id": ctx.stage_id,
                "correlation_id": ctx.correlation_id,
                "uri": uri,
            },
        )

    async def _call(self, *, method: str, params: dict[str, Any]) -> dict[str, Any]:
        req_id = str(uuid.uuid4())
        payload = {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            r = await client.post(f"{self._base_url}/jsonrpc", json=payload)
            r.raise_for_status()
            data = r.json()

        if data.get("error"):
            raise RuntimeError(f"jsonrpc_error: {data['error']}")
        return data["result"]
