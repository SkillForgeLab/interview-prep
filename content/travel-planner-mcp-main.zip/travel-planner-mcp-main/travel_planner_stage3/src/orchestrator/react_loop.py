from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

from shared.logging import LogContext, with_ctx, log_event
from orchestrator.memory import EvidenceStore
from orchestrator.schemas import NextStep
from orchestrator.gateway_client import GatewayClient, GatewayContext
from orchestrator.reasoning_adapter import ReasoningAdapter

logger = logging.getLogger("orchestrator.react_loop")


@dataclass(frozen=True)
class ReactDeps:
    tenant_id: str
    use_case_id: str
    stage_id: int
    correlation_id: str
    gateway: GatewayClient
    reasoning: ReasoningAdapter
    memory: EvidenceStore


async def run_react_loop(*, deps: ReactDeps, goal: str, max_steps: int = 8) -> str:
    adapter = with_ctx(
        logger,
        LogContext(
            tenant_id=deps.tenant_id,
            use_case_id=deps.use_case_id,
            stage_id=deps.stage_id,
            correlation_id=deps.correlation_id,
        ),
    )

    # Catalog comes from gateway (filtered)
    gctx = GatewayContext(
        tenant_id=deps.tenant_id,
        use_case_id=deps.use_case_id,
        stage_id=deps.stage_id,
        correlation_id=deps.correlation_id,
    )
    tools = await deps.gateway.tools_list(ctx=gctx)
    catalog = {"tools": tools, "resources": ["calendar://"], "tenant_id": deps.tenant_id}

    for step_no in range(1, max_steps + 1):
        log_event(adapter, "react.reason", step_no=step_no, role="planner")
        step = deps.reasoning.plan_next_step(goal=goal, step_no=step_no, catalog=catalog, evidence=deps.memory.items)

        log_event(adapter, "react.critic", step_no=step_no, role="critic")
        decision = deps.reasoning.review_step(goal=goal, step=step, evidence=deps.memory.items)
        if not decision.allow:
            log_event(adapter, "react.veto", step_no=step_no, role="critic", reason=decision.reason)
            return f"Stopped: critic_veto. Reason: {decision.reason}"

        if step.action == "resource_read":
            if not step.uri:
                return "Stopped: invalid_step_missing_uri"
            log_event(adapter, "react.act", step_no=step_no, role="gateway", action="resources.read")
            res = await deps.gateway.resources_read(ctx=gctx, uri=step.uri)
            deps.memory.append(step_no=step_no, kind="resource", payload=res)
            log_event(adapter, "react.observe", step_no=step_no, role="memory", kind="resource")
            continue

        if step.action == "tool_call":
            if not step.tool:
                return "Stopped: invalid_step_missing_tool"
            log_event(adapter, "react.act", step_no=step_no, role="executor")
            tool_args = deps.reasoning.build_tool_args(goal=goal, step=step, evidence=deps.memory.items)

            try:
                arguments = json.loads(tool_args.payload_json)
            except json.JSONDecodeError as e:
                log_event(
                    adapter,
                    "react.stop",
                    step_no=step_no,
                    role="executor",
                    reason="invalid_tool_args_json",
                    error=str(e),
                    payload_json=tool_args.payload_json,
                )
                return "Stopped: invalid_tool_args_json"

            log_event(adapter, "react.act", step_no=step_no, role="gateway", action="tools.call", tool=step.tool)
            out = await deps.gateway.tools_call(ctx=gctx, tool=step.tool, arguments=arguments)
            deps.memory.append(step_no=step_no, kind="tool", payload=out)
            log_event(adapter, "react.observe", step_no=step_no, role="memory", kind="tool")
            continue

        if step.action == "finish":
            log_event(adapter, "react.finish", step_no=step_no, role="summarizer")
            final = deps.reasoning.summarize(goal=goal, evidence=deps.memory.items)
            return final.answer

        return "Stopped: unknown_action"

    return "Stopped: max_steps_exceeded"
