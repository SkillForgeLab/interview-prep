from __future__ import annotations

from pydantic import BaseModel, Field


class JsonRpcRequest(BaseModel):
    jsonrpc: str = Field(pattern="^2\\.0$")
    id: str
    method: str
    params: dict


class JsonRpcError(BaseModel):
    code: int
    message: str
    data: dict | None = None


class JsonRpcResponse(BaseModel):
    jsonrpc: str = "2.0"
    id: str
    result: dict | None = None
    error: JsonRpcError | None = None
