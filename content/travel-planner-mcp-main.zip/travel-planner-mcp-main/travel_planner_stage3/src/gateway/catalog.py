from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ToolOrResource = Literal["tool", "resource"]


@dataclass(frozen=True)
class CatalogItem:
    kind: ToolOrResource
    name: str  # tool name or resource prefix/uri
    domain: str  # "calendar" | "weather" | "travel"


def stage3_default_catalog() -> list[CatalogItem]:
    # Stage 3 still read-only, but uses multiple domains.
    return [
        CatalogItem(kind="resource", name="calendar://", domain="calendar"),
        CatalogItem(kind="tool", name="weather.get_forecast", domain="weather"),
        CatalogItem(kind="tool", name="travel.search_flights", domain="travel"),
    ]
