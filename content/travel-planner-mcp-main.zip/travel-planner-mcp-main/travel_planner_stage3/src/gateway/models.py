from __future__ import annotations

from pydantic import BaseModel, Field


class ToolCallParams(BaseModel):
    tenant_id: str
    use_case_id: str
    stage_id: int
    tool: str
    arguments: dict = Field(default_factory=dict)
    correlation_id: str


class ResourceReadParams(BaseModel):
    tenant_id: str
    use_case_id: str
    stage_id: int
    uri: str
    correlation_id: str


class ToolsListParams(BaseModel):
    tenant_id: str
    use_case_id: str
    stage_id: int
    correlation_id: str
