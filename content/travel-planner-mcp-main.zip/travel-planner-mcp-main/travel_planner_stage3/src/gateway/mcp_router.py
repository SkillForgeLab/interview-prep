from __future__ import annotations

import asyncio
import logging
from contextlib import AsyncExitStack
from dataclasses import dataclass
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from shared.logging import LogContext, log_event, with_ctx

logger = logging.getLogger("gateway.mcp_router")


@dataclass(frozen=True)
class DomainSpec:
    name: str
    command: str
    args: list[str]
    env: dict[str, str] | None = None


class McpRouter:
    """
    NOTE: This stage uses stdio transport to MCP servers.
    Gateway's HTTP layer is application logic.


    CORE-compliant router:
    - Gateway talks to domains ONLY via MCP protocol (ClientSession).
    - Domains run out-of-process over stdio transport.

    Added:
    - Explicit timeouts (prevents hangs).
    - call_tool signature fallback for SDK compatibility.
    """

    def __init__(self, *, domain_specs: dict[str, DomainSpec],
                 call_timeout_s: float = 5.0):
        self._domain_specs = domain_specs
        self._call_timeout_s = call_timeout_s
        self._exit_stack: AsyncExitStack | None = None
        self._sessions: dict[str, ClientSession] = {}

    async def start(self) -> None:
        if self._exit_stack is not None:
            return  # idempotent start
        self._exit_stack = AsyncExitStack()

        try:
            for domain, spec in self._domain_specs.items():
                server_params = StdioServerParameters(
                    command=spec.command,
                    args=spec.args,
                    env=spec.env,
                )
                read, write = await self._exit_stack.enter_async_context(
                    stdio_client(server_params))
                session = await self._exit_stack.enter_async_context(
                    ClientSession(read, write))
                await session.initialize()
                self._sessions[domain] = session
        except Exception:
            # ensure partial startup is cleaned up
            await self.stop()
            raise

    async def stop(self) -> None:
        if self._exit_stack:
            await self._exit_stack.aclose()
        self._sessions.clear()
        self._exit_stack = None

    def _session(self, domain: str) -> ClientSession:
        if domain not in self._sessions:
            raise RuntimeError(f"domain_not_connected: {domain}")
        return self._sessions[domain]

    async def call_tool(self, *, domain: str, tool: str,
                        arguments: dict[str, Any], ctx: LogContext) -> dict[
        str, Any]:
        adapter = with_ctx(logger, ctx)
        log_event(adapter, "mcp.call_tool", domain=domain, tool=tool)

        session = self._session(domain)

        try:
            result = await asyncio.wait_for(
                session.call_tool(tool, arguments=arguments),
                timeout=self._call_timeout_s,
            )
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"mcp_call_tool_timeout: domain={domain} tool={tool}")
        return {
            "content": [c.model_dump() if hasattr(c, "model_dump") else str(c)
                        for c in result.content]}

    async def read_resource(self, *, domain: str, uri: str, ctx: LogContext) -> \
            dict[str, Any]:
        adapter = with_ctx(logger, ctx)
        log_event(adapter, "mcp.read_resource", domain=domain, uri=uri)

        session = self._session(domain)

        try:
            result = await asyncio.wait_for(
                session.read_resource(uri),
                timeout=self._call_timeout_s,
            )
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"mcp_read_resource_timeout: domain={domain} uri={uri}")
        return {
            "contents": [c.model_dump() if hasattr(c, "model_dump") else str(c)
                         for c in result.contents]}
