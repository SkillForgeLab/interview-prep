from __future__ import annotations

from contextlib import asynccontextmanager
from fastapi import FastAPI

from shared.logging import configure_logging
from gateway.routes import router
from gateway.catalog import stage3_default_catalog
from gateway.policy import PolicyEngine
from gateway.mcp_router import McpRouter, DomainSpec


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start up
    app.state.mcp_router = McpRouter(
        domain_specs={
            "calendar": DomainSpec(
                name="calendar",
                command="python",
                args=["-m", "domains.calendar.server"],
            ),
            "weather": DomainSpec(
                name="weather",
                command="python",
                args=["-m", "domains.weather.server"],
            ),
            "travel": DomainSpec(
                name="travel",
                command="python",
                args=["-m", "domains.travel.server"],
            ),
        }
    )
    await app.state.mcp_router.start()
    try:
        yield
    finally:
        await app.state.mcp_router.stop()


def create_app() -> FastAPI:
    configure_logging()
    app = FastAPI(title="Stage3 Gateway (JSON-RPC over HTTP)", lifespan=lifespan)

    # Ensure attribute always exists even if lifespan isn't entered (e.g., some tests).
    app.state.mcp_router = None

    catalog = stage3_default_catalog()
    app.state.policy = PolicyEngine(catalog=catalog)

    app.include_router(router, prefix="/mcp")
    return app
