from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from gateway.catalog import CatalogItem


@dataclass(frozen=True)
class PolicyContext:
    tenant_id: str
    use_case_id: str
    stage_id: int


class PolicyEngine:
    """
    tool_filtering toggle: ON for stage 3.
    Policy keys off (tenant_id, use_case_id, stage_id).
    """

    def __init__(self, *, catalog: list[CatalogItem]):
        self._catalog = catalog

    def visible_tools(self, ctx: PolicyContext) -> list[str]:
        # Example: could be tenant-specific allowlists in later stages.
        return [c.name for c in self._catalog if c.kind == "tool"]

    def visible_resource_prefixes(self, ctx: PolicyContext) -> list[str]:
        return [c.name for c in self._catalog if c.kind == "resource"]

    def authorize_tool(self, ctx: PolicyContext, tool_name: str) -> None:
        allowed = set(self.visible_tools(ctx))
        if tool_name not in allowed:
            raise PermissionError("tool_denied")

    def authorize_resource(self, ctx: PolicyContext, uri: str) -> None:
        prefixes = self.visible_resource_prefixes(ctx)
        if not any(uri.startswith(p) for p in prefixes):
            raise PermissionError("resource_denied")

    def domain_for_tool(self, tool_name: str) -> str:
        for c in self._catalog:
            if c.kind == "tool" and c.name == tool_name:
                return c.domain
        raise KeyError("unknown_tool")

    def domain_for_resource(self, uri: str) -> str:
        for c in self._catalog:
            if c.kind == "resource" and uri.startswith(c.name):
                return c.domain
        raise KeyError("unknown_resource")
