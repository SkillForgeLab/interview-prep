from __future__ import annotations

import logging
from fastapi import APIRouter, Request
from pydantic import ValidationError
from mcp.shared.exceptions import McpError

from shared.jsonrpc import JsonRpcRequest, JsonRpcResponse, JsonRpcError
from shared.logging import LogContext, with_ctx, log_event
from gateway.models import ToolCallParams, ResourceReadParams, ToolsListParams
from gateway.policy import PolicyContext, PolicyEngine
from gateway.mcp_router import McpRouter

logger = logging.getLogger("gateway.routes")

router = APIRouter()


def _err(req_id: str, code: int, message: str, data: dict | None = None) -> JsonRpcResponse:
    return JsonRpcResponse(id=req_id, error=JsonRpcError(code=code, message=message, data=data))


@router.post("/jsonrpc")
async def handle_jsonrpc(request: Request) -> JsonRpcResponse:
    body = await request.json()
    try:
        req = JsonRpcRequest.model_validate(body)
    except ValidationError as e:
        # stable error
        return _err(req_id=body.get("id", "unknown"), code=400, message="invalid_jsonrpc", data={"detail": str(e)})

    app_state = request.app.state
    policy: PolicyEngine = app_state.policy

    # mcp: McpRouter = app_state.mcp_router

    # Required context for logs + policy
    params = req.params or {}
    correlation_id = params.get("correlation_id", "missing")
    tenant_id = params.get("tenant_id", "missing")
    use_case_id = params.get("use_case_id", "missing")
    stage_id = int(params.get("stage_id", -1))

    ctx = LogContext(
        tenant_id=str(tenant_id),
        use_case_id=str(use_case_id),
        stage_id=stage_id,
        correlation_id=str(correlation_id),
    )
    adapter = with_ctx(logger, ctx)
    log_event(adapter, "jsonrpc.request", method=req.method)

    try:
        if req.method == "tools.list":
            p = ToolsListParams.model_validate(req.params)
            pctx = PolicyContext(tenant_id=p.tenant_id, use_case_id=p.use_case_id, stage_id=p.stage_id)
            tools = policy.visible_tools(pctx)
            return JsonRpcResponse(id=req.id, result={"tools": tools})

        if req.method == "tools.call":
            p = ToolCallParams.model_validate(req.params)
            pctx = PolicyContext(tenant_id=p.tenant_id, use_case_id=p.use_case_id, stage_id=p.stage_id)
            policy.authorize_tool(pctx, p.tool)
            domain = policy.domain_for_tool(p.tool)

            mcp = getattr(app_state, "mcp_router", None)
            if not isinstance(mcp, McpRouter):
                return _err(req_id=req.id, code=503,
                            message="mcp_router_not_ready")

            result = await mcp.call_tool(domain=domain, tool=p.tool, arguments=p.arguments, ctx=ctx)
            return JsonRpcResponse(id=req.id, result={"tool": p.tool, "domain": domain, "result": result})

        if req.method == "resources.read":
            p = ResourceReadParams.model_validate(req.params)
            pctx = PolicyContext(tenant_id=p.tenant_id, use_case_id=p.use_case_id, stage_id=p.stage_id)
            policy.authorize_resource(pctx, p.uri)
            domain = policy.domain_for_resource(p.uri)

            mcp = getattr(app_state, "mcp_router", None)
            if not isinstance(mcp, McpRouter):
                return _err(req_id=req.id, code=503,
                            message="mcp_router_not_ready")

            result = await mcp.read_resource(domain=domain, uri=p.uri, ctx=ctx)
            return JsonRpcResponse(id=req.id, result={"uri": p.uri, "domain": domain, "result": result})

        return _err(req_id=req.id, code=404, message="method_not_found")
    except PermissionError as e:
        return _err(req_id=req.id, code=403, message=str(e))
    except ValidationError as e:
        return _err(req_id=req.id, code=422, message="invalid_params", data={"detail": str(e)})
    except TimeoutError as e:
        return _err(req_id=req.id, code=504, message="timeout", data={"detail": str(e)})
    except McpError as e:
        # MCP domain returned an error (e.g., unknown resource/tool)
        # Treat as 404 unless you want a richer mapping later.
        return _err(req_id=req.id, code=404, message="mcp_error", data={"detail": str(e)})
    except Exception as e:
        adapter.exception("jsonrpc.unhandled_error")  # prints traceback
        log_event(adapter, "jsonrpc.unhandled_error", error=str(e))
        return _err(req_id=req.id, code=500, message="internal_error",
                    data={"detail": str(e)})

