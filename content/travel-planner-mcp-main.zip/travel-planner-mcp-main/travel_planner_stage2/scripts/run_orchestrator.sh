#!/usr/bin/env bash
set -euo pipefail

set -a
source .env
set +a

uv run python -m src.orchestrator.main \
  --goal "Plan a short trip from PHX to SFO. Avoid conflicts. Prefer good weather. Show 3 flight options." \
  --max-steps 8