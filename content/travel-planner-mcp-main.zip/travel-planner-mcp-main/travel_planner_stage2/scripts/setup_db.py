from __future__ import annotations

import logging
import os

from shared.persistence.db import DbConnFactory
from shared.persistence.schema import SCHEMA_SQL
from shared.bootstrap import init_app

logger = logging.getLogger(__name__)


def main() -> None:
    init_app()

    db_path = os.environ.get("APP_DB_PATH", "./data/app.db").strip()
    db = DbConnFactory(db_path=db_path)

    with db.connect() as conn:
        conn.executescript(SCHEMA_SQL)

    logger.info("db.seeded", extra={"app_db_path": db_path})


if __name__ == "__main__":
    main()
