from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from orchestrator.schemas import NextStep


@dataclass(frozen=True)
class DeterministicPlanner:
    tenant_id: str

    def plan_next_step(
        self,
        *,
        goal: str,
        step_no: int,
        catalog: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> NextStep:
        # Stage 2 required order:
        # 1) calendar resource
        # 2) weather tool
        # 3) travel tool
        # 4) finish
        if step_no == 1:
            return NextStep(
                step_no=1,
                action="resource_read",
                rationale="Need the user's upcoming events to avoid scheduling conflicts.",
                # FastMCP requires URI template params to match function params.
                # Calendar resource contract: calendar://upcoming/{tenant_id}
                uri=f"calendar://upcoming/{self.tenant_id}",
            )
        if step_no == 2:
            return NextStep(
                step_no=2,
                action="tool_call",
                rationale="Need weather for a candidate travel date to avoid bad conditions.",
                tool="weather.get_forecast",
                arguments={
                    "tenant_id": self.tenant_id,
                    "location": "San Francisco, CA",
                    "date": "2026-01-23",
                },
            )
        if step_no == 3:
            return NextStep(
                step_no=3,
                action="tool_call",
                rationale="Now that dates are feasible and weather is known, search flights.",
                tool="travel.search_flights",
                arguments={
                    "tenant_id": self.tenant_id,
                    "origin": "PHX",
                    "destination": "SFO",
                    "depart_date": "2026-01-23",
                    "return_date": "2026-01-25",
                },
            )
        return NextStep(
            step_no=step_no,
            action="finish",
            rationale="All required evidence collected. Provide final recommendation.",
            final_answer="OK (test): produced calendar, weather, and flight evidence.",
        )
