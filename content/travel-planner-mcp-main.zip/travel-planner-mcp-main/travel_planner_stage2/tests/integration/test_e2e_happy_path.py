from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path

import httpx
import pytest

from orchestrator.gateway_client import GatewayClient
from orchestrator.react_loop import ReactDeps, run_react_loop
from shared.persistence.schema import SCHEMA_SQL
from shared.persistence.db import DbConnFactory

from travel_planner_stage2.tests.integration.planner_stub import DeterministicPlanner

import subprocess
import time


def _dump_proc_output(proc: subprocess.Popen, label: str, timeout_s: float = 2.0) -> None:
    """
    Best-effort: dump stdout/stderr so the real gateway/domain failure is visible in pytest output.
    """
    try:
        if proc.poll() is None:
            # Don't hang forever; give it a moment to flush.
            try:
                out, err = proc.communicate(timeout=timeout_s)
            except subprocess.TimeoutExpired:
                proc.terminate()
                out, err = proc.communicate(timeout=timeout_s)
        else:
            out, err = proc.communicate(timeout=timeout_s)

        out = out or ""
        err = err or ""

        if out.strip():
            print(f"\n--- {label} STDOUT ---\n{out}\n--- end ---\n")
        if err.strip():
            print(f"\n--- {label} STDERR ---\n{err}\n--- end ---\n")
    except Exception as e:
        print(f"\n--- {label} OUTPUT DUMP FAILED: {type(e).__name__}: {e} ---\n")


def _wait_healthz(url: str, timeout_s: float = 8.0) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            r = httpx.get(url, timeout=1.0)
            if r.status_code == 200 and r.json().get("ok") is True:
                return
        except Exception:
            pass
        time.sleep(0.2)
    raise RuntimeError(f"gateway did not become healthy: {url}")


@pytest.mark.asyncio
async def test_e2e_happy_path(tmp_path: Path, monkeypatch):
    # DB setup
    db_path = tmp_path / "app.db"
    monkeypatch.setenv("APP_DB_PATH", str(db_path))
    monkeypatch.setenv("TENANT_ID", "tenant_test")

    # Create core evidence/decision schema
    db = DbConnFactory(db_path=str(db_path))
    with db.connect() as conn:
        conn.executescript(SCHEMA_SQL)

    # Configure gateway domain server commands (stdio subprocesses)
    monkeypatch.setenv("TRAVEL_SERVER_COMMAND", "uv")
    monkeypatch.setenv("TRAVEL_SERVER_ARGS", "run,python,-m,domains.travel.server")
    monkeypatch.setenv("WEATHER_SERVER_COMMAND", "uv")
    monkeypatch.setenv("WEATHER_SERVER_ARGS", "run,python,-m,domains.weather.server")
    monkeypatch.setenv("CALENDAR_SERVER_COMMAND", "uv")
    monkeypatch.setenv("CALENDAR_SERVER_ARGS", "run,python,-m,domains.calendar.server")

    # Start gateway on a test port
    port = 8099
    gateway_url = f"http://127.0.0.1:{port}/mcp"
    health_url = f"http://127.0.0.1:{port}/health"

    proc = subprocess.Popen(
        ["uv", "run", "python", "-m", "uvicorn", "gateway.main:app", "--host", "127.0.0.1", "--port", str(port)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=dict(os.environ),
    )
    test_failed = False

    try:
        _wait_healthz(health_url)

        deps = ReactDeps(
            gateway=GatewayClient(base_url=gateway_url, timeout_seconds=10),
            planner=DeterministicPlanner(tenant_id="tenant_test"),
            tenant_id="tenant_test",
            db_path=str(db_path),
        )

        final = await run_react_loop(deps=deps, goal="test goal", max_steps=6)
        # assert "OK (test)" in final

        # Verify that evidence was written (tenant-isolated)
        with db.connect() as conn:
            c1 = conn.execute(
                "SELECT COUNT(1) AS c FROM evidence WHERE tenant_id=?",
                ("tenant_test",)).fetchone()
            c2 = conn.execute(
                "SELECT COUNT(1) AS c FROM decisions WHERE tenant_id=?",
                ("tenant_test",)).fetchone()
            assert int(c1["c"]) >= 3  # calendar + weather + travel
            assert int(c2["c"]) >= 4  # 3 acts + finish

        assert isinstance(final, str) and final
    except Exception:
        test_failed = True
        raise


    finally:
        if test_failed:
            _dump_proc_output(proc, label="GATEWAY")
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except Exception:
                proc.kill()
