from __future__ import annotations

from pathlib import Path

from shared.persistence.db import DbConnFactory
from shared.persistence.schema import SCHEMA_SQL
from shared.persistence.repositories import EvidenceRepositorySQLite, DecisionRepositorySQLite


def test_repositories_write(tmp_path: Path) -> None:
    db_path = tmp_path / "app.db"
    db = DbConnFactory(db_path=str(db_path))
    with db.connect() as conn:
        conn.executescript(SCHEMA_SQL)

    evidence = EvidenceRepositorySQLite(db=db)
    decisions = DecisionRepositorySQLite(db=db)

    eid = evidence.append_evidence(
        tenant_id="t1",
        source_kind="tool",
        source_id="weather.get_forecast",
        payload={"x": 1},
    )
    assert eid > 0

    did = decisions.append_decision(
        tenant_id="t1",
        step_no=1,
        rationale="because",
        action_kind="tool_call",
        action_id="weather.get_forecast",
        inputs={"a": 1},
        linked_evidence_ids=[eid],
    )
    assert did > 0
