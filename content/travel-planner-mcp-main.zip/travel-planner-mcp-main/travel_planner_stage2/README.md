# Travel Planner (Stage 2) — Multi-server planning (read-only)

---

## Goal of This Stage (Read First)
- The LLM (Planner) decides which MCP server to call next and why.
- The system remains read-only.
- Travel + Weather are MCP tools.
- Calendar is MCP resources (read-only).

### Core rule:
- “LLM reasons. MCP executes.”
- The orchestrator never calls domain servers directly.
- The orchestrator calls only the Gateway (HTTP JSON-RPC).

---
## Evidence Map (resource URI → decision impact)
### Calendar resources
- calendar://events/week
  - Impact: Determines feasible travel windows (free time blocks).
  - If missing: Planner must ask the user for availability or finish with uncertainty.

### Weather tools
- weather.get_forecast(city, start_date, end_date)
  - Impact: Filters candidate windows by weather constraints (e.g., avoid storms).
  - If missing: Planner continues with flights but marks forecast as unknown.

### Travel tools
- travel.search_flights(origin, destination, depart_date, return_date)
  - Impact: Produces flight options for feasible date windows.
  - If missing: Planner cannot propose flight options.

---

## What you get
- 3 **MCP servers** started by the gateway via `stdio`
    - Travel server (tools): `travel.search_flights`
    - Weather server (tools): `weather.get_forecast`
    - Calendar server (resources): `calendar://events?...`


- **Gateway** that exposes `MCP-style JSON-RPC` over `HTTP`:
    - `tools/list`
    - `tools/call`
    - `resources/list`
    - `resources/read`
  

- **Orchestrator** that runs an explicit `ReAct` loop:
    - **Planner** decides next step and explains why (routing decisions)
    - `Act` uses Gateway only
    - Observe stores normalized structured evidence 
    - Uses `FakeReasoningAdapter`
    - Deterministic and testable


- **Persistence**
  - sqlite
  - Tenant-isolated queries


- **Tests**
  - Unit test: tenant isolation
  - Integration test: HTTP → Gateway → MCP → DB
---

## macOS (Intel) — Run Instructions

### Prerequisites
- macOS (Intel)
- uv installed
- Python 3.11+

### Required env vars:
- OPENAI_API_KEY (required for orchestrator planning)
- OPENAI_MODEL (default: gpt-5.2)
- GATEWAY_URL (default: http://127.0.0.1:8080/mcp)
- APP_DB_PATH (default: ./data/app.db)
- TENANT_ID (default: tenant_dem

## Environment Configuration
### File: `.env.example`
```env
ENV=development

# OpenAI (optional for live model; tests do not require this)
OPENAI_API_KEY=changeme
OPENAI_MODEL=gpt-4.1-mini

# Orchestrator -> Gateway
GATEWAY_URL=http://127.0.0.1:8080/mcp
HTTP_TIMEOUT_SECONDS=10

# sqlite
APP_DB_PATH=./data/app.db
TENANT_ID=tenant_demo


# Domain servers (started by Gateway over stdio)
TRAVEL_SERVER_COMMAND=uv
TRAVEL_SERVER_ARGS=run,python,-m,domains.travel.server

WEATHER_SERVER_COMMAND=uv
WEATHER_SERVER_ARGS=run,python,-m,domains.weather.server

CALENDAR_SERVER_COMMAND=uv
CALENDAR_SERVER_ARGS=run,python,-m,domains.calendar.server

#------------------------------------------------------------------------------
# BEGIN: DEV ONLY CONFIG
#------------------------------------------------------------------------------

# json  (default, production-safe),
# true  (adds blank line between logs (dev only))
# prety (pretty + blank line (local development))
LOG_MODE=pretty
LOG_PRETTY=true

```

## Setup (Follow in Order)

### 1. Verify CPU architecture
```bash
uname -m
```
#### Expected 
- x86_64


### 2. Verify `uv`
```bash
which uv
uv --version
```

#### If missing, run 
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
#### Restart terminal after install.


### 3. Create virtual environment

#### a. Clone / enter project directory
```bash
cd travel_planner_stage2
```
#### Directory must contain:
- pyproject.toml
- src/
- scripts/
- tests/

### b. Copy environment variables
```bash
cp .env.example .env
```

### c. Enable environment variables
```bash
set -a
source .env
set +a
```

#### b. Install `.venv`
```bash
rm -rf .venv
uv venv
```

#### c. Activate `.venv`
```bash
source .venv/bin/activate
```

#### d. Verify Python
```bash
which python
uv run python --version
```
#### Expected
- .../travel_planner_stage1/.venv/bin/python
- Python 3.11.14


### 4. Install dependencies
```bash
uv pip install -e ".[dev]"
```
#### Expected
- No errors
- mcp, fastapi, uvicorn, httpx installed



### 5. Create and seed the sqlite DB
```bash
source .env
uv run python scripts/setup_db.py
```
#### Expected
- Creates sqlite DB at: `APP_DB_PATH` (data/app.db)
- Prints: `db.seeded`

### Verify database exists
```bash
ls data/app.db
```
#### Expected
- data/app.db



#### You do not need to edit .env for Stage 1.
#### Important defaults:
- Uses FakeReasoningAdapter (no OpenAI key needed)
- Uses local sqlite
- Uses stdio MCP transport


## Start domain servers (stdio)
### Terminal 1 — Start Gateway
```bash
set -a
uv run python -m uvicorn gateway.main:app \
  --host 127.0.0.1 \
  --port 8080
set +a
```
**Expected:**  
- Uvicorn shows: `Uvicorn running on http://127.0.0.1:8080`

#### Verify Gateway endpoints (quick smoke tests)

#### a. List tools:
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"1",
    "method":"tools/list",
    "params":{}
  }' | jq
```
#### Expected output:
- HTTP 200
- JSON with at least one tool:
- -  search_flights


#### b. Read calendar availability resource:
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"2",
    "method":"resources/list",
    "params":{}
  }' | python -m json.tool
```


#### c. Call resource:
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":"6",
    "method":"tools/call",
    "params":{
      "name":"weather.get_forecast",
      "arguments":{
        "payload":{
          "tenant_id":"tenant_demo",
          "location":"San Francisco",
          "date":"2026-01-21",
          "days":3
        }
      }
    }
  }' | jq
```

### Terminal 2 — Run the Orchestrator
```bash
set -a; source .env; set +a
uv run python -m src.orchestrator.main \
  --goal "Plan a short trip from PHX to SFO. Avoid conflicts. Prefer good weather. Show 3 flight options." \
  --max-steps 8
```
**Expected:**  
- You see a step-by-step ReAct trace.
- You see decisions referencing:
  - calendar resource output 
  - weather forecast output
  - flight search output

FINAL ANSWER

Here are 3 flight options from PHX to SFO for your trip from 2026-01-20 to 2026-01-22, avoiding conflicts and considering good weather:
1. American Airlines, flight ID flt-3164, nonstop, price $485.
2. American Airlines, flight ID flt-3472, nonstop, price $237.
3. Southwest Airlines, flight ID flt-3723, nonstop, price $476.


Your trip is planned without conflicts, and weather forecasts for PHX and SFO have been considered.
    
#### This confirms
```
- Reason → Act → Observe loop executed
- Tool was called via Gateway
- Domain server executed
- Final decision was made
```


## Tests (Required for Definition of Done)
```bash
set -a
source .env
set +a
uv run pytest -q
```
#### Expected:
- ... passed
#### Tests include:
- Unit test: tenant isolation
- Integration test: real HTTP → Gateway → MCP → sqlite


## Verification steps
- Confirm tools/resources are visible:
  - Orchestrator prints a catalog from tools/list and resources/list.
- Confirm evidence is persisted:
  - Evidence rows exist for calendar, weather, travel results.
- Confirm tenant isolation:
  - If you change TENANT_ID, evidence is written under the new tenant only.

## Clean shutdown
 In all terminals:
```bash
Ctrl+C
```
#### Order does not matter.



## Troubleshooting: Common failure symptoms & fixes

uv run python -c "import domains.travel.server as s; print('OK', s)"
uv run python -c "import src.domains.travel.server as s; print('OK', s)"

 
### ❌ Gateway returns JSON-RPC error
- Ensure all 3 domain servers are running (3 terminals).
- Confirm .env has correct server command/args.


### ❌ Orchestrator observation is text-only JSON
- Stage 2 includes observation normalization logic.
- The orchestrator will parse JSON text into structured dict when possible.

## Stage 2 exit checklist

 - I can explain why the planner called Calendar before Weather.
 - I can point to one log line that explains each next step. 
 - I can show one “resource URI → decision impact” mapping. 
 - I can run everything using ONLY this README on macOS Intel.