from __future__ import annotations

import traceback
from typing import Any


def _exc_tb_str(exc: BaseException) -> str:
    return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))


def flatten_exception(exc: BaseException) -> dict[str, Any]:
    """
    Convert exceptions (including ExceptionGroup) into a JSON-safe structure.
    Python 3.11+: ExceptionGroup/BaseExceptionGroup wraps multiple root causes.
    """
    # BaseExceptionGroup exists in 3.11+. It is the common base for ExceptionGroup.
    if isinstance(exc, BaseExceptionGroup):  # type: ignore[name-defined]
        return {
            "type": type(exc).__name__,
            "message": str(exc),
            "causes": [flatten_exception(e) for e in exc.exceptions],  # type: ignore[attr-defined]
        }

    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": _exc_tb_str(exc),
    }
