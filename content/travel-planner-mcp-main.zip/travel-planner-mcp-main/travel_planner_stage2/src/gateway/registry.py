from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from mcp import StdioServerParameters


@dataclass(frozen=True)
class DomainServerConfig:
    domain: str
    stdio_params: StdioServerParameters


@dataclass(frozen=True)
class DomainRegistry:
    domains: Mapping[str, DomainServerConfig]

    def get(self, domain: str) -> DomainServerConfig:
        if domain not in self.domains:
            raise KeyError(f"Unknown domain: {domain}")
        return self.domains[domain]
