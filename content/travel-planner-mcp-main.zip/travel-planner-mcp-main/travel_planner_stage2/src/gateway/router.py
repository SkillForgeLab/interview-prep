from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

from gateway.contracts import split_qualified_tool_name
from gateway.mcp_stdio_client import McpStdioClient
from gateway.registry import DomainRegistry


@dataclass(frozen=True)
class GatewayRouter:
    registry: DomainRegistry

    def _client_for_domain(self, domain: str) -> McpStdioClient:
        cfg = self.registry.get(domain)
        return McpStdioClient(params=cfg.stdio_params)

    async def list_tools_all(self) -> dict[str, Any]:
        """
        Returns a merged list of tools from all configured domains.
        Tools are renamed to domain-qualified names for deterministic routing.
        """
        out: list[dict[str, Any]] = []
        for domain, cfg in self.registry.domains.items():
            client = McpStdioClient(params=cfg.stdio_params)
            resp = await client.list_tools()
            tools = getattr(resp, "tools", None) or getattr(resp, "tools", [])
            for t in tools:
                # t likely has .name and .description and .inputSchema; keep as dict safely.
                out.append(
                    {
                        "name": f"{domain}.{t.name}",
                        "description": getattr(t, "description", ""),
                        "inputSchema": getattr(t, "inputSchema", None),
                    }
                )
        return {"tools": out}

    async def call_tool(self, qualified_tool_name: str,
                        arguments: dict[str, Any]) -> dict[str, Any]:
        domain, tool = split_qualified_tool_name(qualified_tool_name)
        client = self._client_for_domain(domain)
        resp = await client.call_tool(name=tool, arguments=arguments)
        # resp likely has .content and optional meta; return a dict envelope.
        return {
            "content": getattr(resp, "content", None),
            "_meta": getattr(resp, "_meta", None),
        }

    async def list_resources(self) -> dict[str, Any]:
        """
        Stage 2 exposes calendar resources only (read-only).

        We return what the calendar MCP server advertises:
        - resources: concrete instances (may be empty)
        - resourceTemplates: templates (should include calendar://upcoming/{tenant_id})
        """
        client = self._client_for_domain("calendar")

        # concrete resources (may be empty)
        resp_r = await client.list_resources()
        resources = getattr(resp_r, "resources", None) or []

        # templates (this is what you need)
        resp_t = await client.list_resource_templates()
        templates = (
                getattr(resp_t, "resourceTemplates", None)
                or getattr(resp_t, "resource_templates", None)
                or []
        )

        def to_dict(x: Any) -> Any:
            return getattr(x, "model_dump", lambda: x)()

        return {
            "resources": [to_dict(r) for r in resources],
            "resourceTemplates": [to_dict(t) for t in templates],
        }

    async def read_resource(self, uri: str) -> dict[str, Any]:
        """
        Route by URI scheme:
          calendar://... -> calendar MCP server
        """
        parsed = urlparse(uri)
        if parsed.scheme != "calendar":
            raise ValueError(f"Unsupported resource scheme: {parsed.scheme}")

        client = self._client_for_domain("calendar")
        resp = await client.read_resource(uri=uri)
        return {
            "contents": getattr(resp, "contents", None),
        }
