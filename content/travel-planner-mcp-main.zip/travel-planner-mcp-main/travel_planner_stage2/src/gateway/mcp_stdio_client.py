from __future__ import annotations

import anyio
from dataclasses import dataclass
from typing import Any

from pydantic import AnyUrl

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.shared.exceptions import McpError


@dataclass(frozen=True)
class McpStdioClient:
    """
    Minimal MCP client wrapper for stdio transport.
    Uses the official MCP Python SDK pattern:
      async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
          await session.initialize()
    :contentReference[oaicite:7]{index=7}
    """
    params: StdioServerParameters

    async def list_tools(self) -> Any:
        async with stdio_client(self.params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                return await session.list_tools()

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        async with stdio_client(self.params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                return await session.call_tool(name=name, arguments=arguments)

    async def list_resources(self) -> dict[str, Any]:
        """
        Stage 2 exposes calendar resources only (read-only).

        NOTE:
        Calendar resources are parameterized (calendar://upcoming/{tenant_id}),
        so resources/list intentionally returns an empty list.
        """
        return {"resources": []}

    async def list_resource_templates(self) -> Any:
        async with stdio_client(self.params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                return await session.list_resource_templates()

    async def read_resource(self, uri: str) -> Any:
        any_uri = AnyUrl(uri)
        async with stdio_client(self.params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                return await session.read_resource(uri=any_uri)