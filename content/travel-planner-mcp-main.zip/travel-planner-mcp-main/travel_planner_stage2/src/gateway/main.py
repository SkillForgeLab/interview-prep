import logging
import os

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from typing import AsyncIterator

from mcp import StdioServerParameters

from gateway.jsonrpc_models import (
    JsonRpcRequest,
    JsonRpcResponse,
    JsonRpcError,
    error_response,
    wrap_rpc_call,
)

from shared.bootstrap import init_app
from gateway.registry import DomainRegistry, DomainServerConfig
from gateway.router import GatewayRouter
from shared.logging import setup_json_logging

logger = logging.getLogger("gateway")


def _build_registry() -> DomainRegistry:
    """
    Domain servers are launched by the gateway as subprocesses using stdio transport.
    Command/args are passed via env vars so macOS run instructions can configure them.
    """
    # Travel is assumed present from Stage 1/Part 1:
    travel_cmd = os.environ["TRAVEL_SERVER_COMMAND"]
    travel_args = os.environ["TRAVEL_SERVER_ARGS"].split(",")

    weather_cmd = os.environ.get("WEATHER_SERVER_COMMAND", "uv")
    weather_args = os.environ.get("WEATHER_SERVER_ARGS",
                                  "run,python,-m,src.domains.weather.server").split(
        ",")

    calendar_cmd = os.environ.get("CALENDAR_SERVER_COMMAND", "uv")
    calendar_args = os.environ.get("CALENDAR_SERVER_ARGS",
                                   "run,python,-m,src.domains.calendar.server").split(
        ",")

    # Forward only what we need. APP_DB_PATH is mandatory for persistence.
    env = {"APP_DB_PATH": os.environ["APP_DB_PATH"]}

    return DomainRegistry(
        domains={
            "travel": DomainServerConfig(
                domain="travel",
                stdio_params=StdioServerParameters(command=travel_cmd,
                                                   args=travel_args, env=env),
            ),
            "weather": DomainServerConfig(
                domain="weather",
                stdio_params=StdioServerParameters(command=weather_cmd,
                                                   args=weather_args, env=env),
            ),
            "calendar": DomainServerConfig(
                domain="calendar",
                stdio_params=StdioServerParameters(command=calendar_cmd,
                                                   args=calendar_args,
                                                   env=env),
            ),
        }
    )


def _router() -> GatewayRouter:
    return GatewayRouter(registry=_build_registry())


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    init_app()
    logger.info("gateway.started")
    yield


app = FastAPI(
    title="Stage2 Gateway",
    version="2.0",
    lifespan=lifespan,
)


@app.get("/health")
async def healthz():
    return {"ok": True}


async def _dispatch(req: JsonRpcRequest) -> dict:
    """
    Dispatch JSON-RPC methods to the GatewayRouter.
    NOTE: This function intentionally returns ONLY the `result` dict.
    JsonRpcResponse wrapping is handled by wrap_rpc_call() in jsonrpc_models.py.
    """
    router = _router()

    if req.method == "tools/list":
        return await router.list_tools_all()

    if req.method == "tools/call":
        tool_name = req.params.get("name")
        arguments = req.params.get("arguments", {})
        if not isinstance(tool_name, str) or not isinstance(arguments, dict):
            raise HTTPException(status_code=400,
                                detail="Invalid tools/call params")
        return await router.call_tool(tool_name, arguments)

    if req.method == "resources/list":
        return await router.list_resources()

    if req.method == "resources/read":
        uri = req.params.get("uri")
        if not isinstance(uri, str):
            raise HTTPException(status_code=400,
                                detail="Invalid resources/read params")
        return await router.read_resource(uri)

    # Method not found -> JSON-RPC error (not an HTTP error)
    # We raise a plain RuntimeError here and handle it explicitly in mcp_entry
    # to keep the code path obvious and avoid redesign.
    raise RuntimeError(f"JSONRPC_METHOD_NOT_FOUND::{req.method}")


@app.post("/mcp")
async def mcp_entry(req: JsonRpcRequest):
    """
    JSON-RPC over HTTP façade.
    Supported methods:
      - tools/list
      - tools/call
      - resources/list
      - resources/read
    """
    try:
        # Use the common wrapper so ExceptionGroup gets flattened into error.data
        resp: JsonRpcResponse = await wrap_rpc_call(
            req=req,
            handler=_dispatch,
        )

        # Special-case "method not found" to keep your current JSON-RPC code path.
        if resp.error and resp.error.code == -32000:
            # If dispatch raised the sentinel, convert it into -32601
            # This preserves JSON-RPC semantics without redesigning the router.
            # The wrapper already logged the exception; we just translate the response.
            if resp.error.data and isinstance(resp.error.data, dict):
                # unwrap type/message from flattened exception payload
                msg = resp.error.data.get("message", "")
                if isinstance(msg, str) and msg.startswith(
                        "JSONRPC_METHOD_NOT_FOUND::"):
                    method = msg.split("::", 1)[1]
                    resp = error_response(
                        req=req,
                        code=-32601,
                        message=f"Method not found: {method}",
                        data=None,
                    )

        return resp.model_dump()

    except HTTPException as e:
        # Keep your existing behavior: invalid params -> -32602 and HTTP status
        return JSONResponse(
            status_code=e.status_code,
            content=JsonRpcResponse(
                id=req.id,
                error=JsonRpcError(code=-32602, message=str(e.detail)),
            ).model_dump(),
        )
