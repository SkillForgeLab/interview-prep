from __future__ import annotations


def qualify_tool_name(domain: str, tool_name: str) -> str:
    return f"{domain}.{tool_name}"


def split_qualified_tool_name(qualified: str) -> tuple[str, str]:
    if "." not in qualified:
        raise ValueError("Tool name must be domain-qualified like 'weather.get_forecast'")
    domain, tool = qualified.split(".", 1)
    if not domain or not tool:
        raise ValueError("Invalid qualified tool name")
    return domain, tool
