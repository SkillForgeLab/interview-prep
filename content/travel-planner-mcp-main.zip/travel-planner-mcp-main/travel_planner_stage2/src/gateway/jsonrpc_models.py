from __future__ import annotations

import logging
import traceback
from typing import Any, Awaitable, Callable, Literal, TypeVar

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

T = TypeVar("T")


class JsonRpcRequest(BaseModel):
    jsonrpc: Literal["2.0"] = "2.0"
    id: str | int
    method: str
    params: dict[str, Any] = Field(default_factory=dict)


class JsonRpcError(BaseModel):
    code: int
    message: str
    data: dict[str, Any] | None = None


class JsonRpcResponse(BaseModel):
    jsonrpc: Literal["2.0"] = "2.0"
    id: str | int
    result: dict[str, Any] | None = None
    error: JsonRpcError | None = None


# ----------------------------
# Helpers (drop-in, minimal)
# ----------------------------

def ok_response(*, req: JsonRpcRequest, result: dict[str, Any]) -> JsonRpcResponse:
    return JsonRpcResponse(id=req.id, result=result, error=None)


def error_response(
    *,
    req: JsonRpcRequest,
    code: int,
    message: str,
    data: dict[str, Any] | None = None,
) -> JsonRpcResponse:
    return JsonRpcResponse(id=req.id, result=None, error=JsonRpcError(code=code, message=message, data=data))


def _traceback_str(exc: BaseException) -> str:
    return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))


def flatten_exception(exc: BaseException) -> dict[str, Any]:
    """
    JSON-safe exception structure.
    - Python 3.11+: ExceptionGroup/BaseExceptionGroup can contain multiple causes.
    - We flatten recursively so the client sees the real root cause(s).
    """
    # BaseExceptionGroup exists in Python 3.11+. mypy may not know it.
    if isinstance(exc, BaseExceptionGroup):  # type: ignore[name-defined]
        # ExceptionGroup has `.exceptions`
        return {
            "type": type(exc).__name__,
            "message": str(exc),
            "causes": [flatten_exception(e) for e in exc.exceptions],  # type: ignore[attr-defined]
        }

    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": _traceback_str(exc),
    }


async def wrap_rpc_call(
    *,
    req: JsonRpcRequest,
    handler: Callable[[JsonRpcRequest], Awaitable[dict[str, Any]]],
) -> JsonRpcResponse:
    """
    Use this from your FastAPI /mcp endpoint.

    It catches:
    - normal Exception
    - ExceptionGroup/BaseExceptionGroup

    And returns a JsonRpcResponse with error.data containing the flattened root cause(s).
    """
    try:
        result = await handler(req)
        return ok_response(req=req, result=result)
    except Exception as exc:
        details = flatten_exception(exc)

        # Always log full details server-side.
        logger.exception(
            "gateway.rpc_failed",
            extra={
                "rpc_method": req.method,
                "rpc_id": req.id,
                "error": details,
            },
        )

        return error_response(
            req=req,
            code=-32000,
            message="Gateway error",
            data=details,
        )
