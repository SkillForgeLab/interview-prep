from __future__ import annotations

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL,
  ts_utc TEXT NOT NULL,
  source_kind TEXT NOT NULL,         -- "tool" | "resource"
  source_id TEXT NOT NULL,           -- e.g. "weather.get_forecast" or "calendar://events/week"
  payload_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_evidence_tenant_ts ON evidence(tenant_id, ts_utc);

CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL,
  ts_utc TEXT NOT NULL,
  step_no INTEGER NOT NULL,
  rationale TEXT NOT NULL,
  action_kind TEXT NOT NULL,         -- "tool_call" | "resource_read" | "finish"
  action_id TEXT NOT NULL,           -- tool name or resource uri or "finish"
  inputs_json TEXT NOT NULL,         -- what was sent (args/uri)
  linked_evidence_ids_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_decisions_tenant_step ON decisions(tenant_id, step_no);
"""
