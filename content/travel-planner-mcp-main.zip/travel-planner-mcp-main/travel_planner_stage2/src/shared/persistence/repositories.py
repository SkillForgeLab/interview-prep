from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol

from .db import DbConnFactory


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class EvidenceRepository(Protocol):
    def append_evidence(
        self,
        *,
        tenant_id: str,
        source_kind: str,
        source_id: str,
        payload: dict[str, Any],
    ) -> int: ...


class DecisionRepository(Protocol):
    def append_decision(
        self,
        *,
        tenant_id: str,
        step_no: int,
        rationale: str,
        action_kind: str,
        action_id: str,
        inputs: dict[str, Any],
        linked_evidence_ids: list[int],
    ) -> int: ...


@dataclass
class EvidenceRepositorySQLite(EvidenceRepository):
    db: DbConnFactory

    def append_evidence(
        self,
        *,
        tenant_id: str,
        source_kind: str,
        source_id: str,
        payload: dict[str, Any],
    ) -> int:
        with self.db.connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO evidence(tenant_id, ts_utc, source_kind, source_id, payload_json)
                VALUES(?, ?, ?, ?, ?)
                """,
                (tenant_id, _now_utc_iso(), source_kind, source_id, json.dumps(payload)),
            )
            return int(cur.lastrowid)


@dataclass
class DecisionRepositorySQLite(DecisionRepository):
    db: DbConnFactory

    def append_decision(
        self,
        *,
        tenant_id: str,
        step_no: int,
        rationale: str,
        action_kind: str,
        action_id: str,
        inputs: dict[str, Any],
        linked_evidence_ids: list[int],
    ) -> int:
        with self.db.connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO decisions(
                  tenant_id, ts_utc, step_no, rationale, action_kind, action_id, inputs_json, linked_evidence_ids_json
                )
                VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    tenant_id,
                    _now_utc_iso(),
                    step_no,
                    rationale,
                    action_kind,
                    action_id,
                    json.dumps(inputs),
                    json.dumps(linked_evidence_ids),
                ),
            )
            return int(cur.lastrowid)
