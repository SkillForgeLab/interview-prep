from __future__ import annotations

import random
from dataclasses import dataclass

from domains.weather.models import Forecast
from domains.weather.weather_repo import WeatherRepository


@dataclass(frozen=True)
class WeatherService:
    repo: WeatherRepository

    def get_or_seed_forecast(self, tenant_id: str, location: str, date: str) -> Forecast:
        existing = self.repo.get_forecast(tenant_id, location, date)
        if existing:
            return existing

        # Deterministic-ish stub (no external calls in Stage 2).
        rng = random.Random(f"{tenant_id}|{location}|{date}")
        high = rng.randint(18, 34)
        low = max(5, high - rng.randint(6, 14))
        precip = rng.randint(0, 60)
        summary = rng.choice(["Sunny", "Partly cloudy", "Cloudy", "Light rain"])

        f = Forecast(
            tenant_id=tenant_id,
            location=location,
            date=date,
            summary=summary,
            high_c=high,
            low_c=low,
            precipitation_chance_pct=precip,
        )
        self.repo.upsert_forecast(f)
        return f
