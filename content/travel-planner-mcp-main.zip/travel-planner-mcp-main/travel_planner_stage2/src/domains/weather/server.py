import logging
import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from domains.weather.models import GetForecastInput, Forecast
from domains.weather.weather_repo import WeatherRepository
from domains.weather.weather_service import WeatherService
from shared.logging import setup_json_logging
from shared.sqlite import SqliteConfig, connect

logger = logging.getLogger("domains.weather")

mcp = FastMCP(name="weather", json_response=True)


def _build_service() -> WeatherService:
    db_path = Path(os.environ["APP_DB_PATH"])
    conn = connect(SqliteConfig(db_path=db_path))
    repo = WeatherRepository(conn=conn)
    repo.init_schema()
    return WeatherService(repo=repo)


@mcp.tool()
def get_forecast(payload: dict) -> dict:
    """
    Read-only tool.
    Returns a deterministic stub forecast persisted in sqlite for repeatability.
    """
    svc = _build_service()
    req = GetForecastInput.model_validate(payload)
    f: Forecast = svc.get_or_seed_forecast(req.tenant_id, req.location, req.date)
    logger.info("forecast.returned", extra={"tenant_id": req.tenant_id, "location": req.location, "date": req.date})
    return f.model_dump()


if __name__ == "__main__":
    # IMPORTANT for stdio servers: never print/log to stdout. Use stderr logging. :contentReference[oaicite:4]{index=4}
    setup_json_logging()
    mcp.run()  # stdio transport (local subprocess) :contentReference[oaicite:5]{index=5}
