from pydantic import BaseModel, Field


class GetForecastInput(BaseModel):
    tenant_id: str = Field(min_length=1)
    location: str = Field(min_length=1)
    date: str = Field(description="YYYY-MM-DD")


class Forecast(BaseModel):
    tenant_id: str
    location: str
    date: str
    summary: str
    high_c: int
    low_c: int
    precipitation_chance_pct: int
