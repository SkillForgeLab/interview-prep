from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Optional

from domains.weather.models import Forecast


@dataclass(frozen=True)
class WeatherRepository:
    conn: sqlite3.Connection

    def init_schema(self) -> None:
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS weather_forecasts (
              tenant_id TEXT NOT NULL,
              location  TEXT NOT NULL,
              date      TEXT NOT NULL,
              summary   TEXT NOT NULL,
              high_c    INTEGER NOT NULL,
              low_c     INTEGER NOT NULL,
              precip_pct INTEGER NOT NULL,
              PRIMARY KEY (tenant_id, location, date)
            );
            """
        )
        self.conn.commit()

    def upsert_forecast(self, f: Forecast) -> None:
        self.conn.execute(
            """
            INSERT INTO weather_forecasts
              (tenant_id, location, date, summary, high_c, low_c, precip_pct)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(tenant_id, location, date) DO UPDATE SET
              summary=excluded.summary,
              high_c=excluded.high_c,
              low_c=excluded.low_c,
              precip_pct=excluded.precip_pct;
            """,
            (f.tenant_id, f.location, f.date, f.summary, f.high_c, f.low_c, f.precipitation_chance_pct),
        )
        self.conn.commit()

    def get_forecast(self, tenant_id: str, location: str, date: str) -> Optional[Forecast]:
        row = self.conn.execute(
            """
            SELECT tenant_id, location, date, summary, high_c, low_c, precip_pct
            FROM weather_forecasts
            WHERE tenant_id=? AND location=? AND date=?;
            """,
            (tenant_id, location, date),
        ).fetchone()
        if not row:
            return None
        return Forecast(
            tenant_id=row["tenant_id"],
            location=row["location"],
            date=row["date"],
            summary=row["summary"],
            high_c=int(row["high_c"]),
            low_c=int(row["low_c"]),
            precipitation_chance_pct=int(row["precip_pct"]),
        )
