import logging
import os
import json
from pathlib import Path

from fastmcp import FastMCP

from domains.calendar.calendar_repo import CalendarRepository
from domains.calendar.calendar_service import CalendarService
from shared.logging import setup_json_logging
from shared.sqlite import SqliteConfig, connect

logger = logging.getLogger("domains.calendar")

mcp = FastMCP(name="calendar", json_response=True)


def _build_service() -> CalendarService:
    db_path = Path(os.environ["APP_DB_PATH"])
    conn = connect(SqliteConfig(db_path=db_path))
    repo = CalendarRepository(conn=conn)
    repo.init_schema()
    return CalendarService(repo=repo)


# Resource URI contract (read-only):
# - calendar://upcoming/{tenant_id}  -> returns seeded upcoming events for tenant
#
# NOTE:
# FastMCP validates that URI template parameters (e.g., {tenant_id})
# match the decorated function parameters exactly.
@mcp.resource("calendar://upcoming/{tenant_id}")
def upcoming(tenant_id: str) -> str:
    """
    Read-only resource.
    Returns upcoming events as a JSON string.
    """
    svc = _build_service()
    events = svc.list_upcoming_events(tenant_id=tenant_id)

    logger.info(
        "calendar.upcoming.read",
        extra={"tenant_id": tenant_id, "count": len(events)},
    )

    # Build valid JSON deterministically.
    # events are pydantic models; model_dump() returns JSON-safe dicts.
    payload = [e.model_dump() for e in events]
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False)


if __name__ == "__main__":
    setup_json_logging()
    mcp.run()  # stdio transport; no stdout logging. :contentReference[oaicite:6]{index=6}
