from pydantic import BaseModel, Field


class CalendarEvent(BaseModel):
    tenant_id: str = Field(min_length=1)
    event_id: str = Field(min_length=1)
    title: str
    start_iso: str
    end_iso: str
    location: str | None = None


class UpcomingQuery(BaseModel):
    tenant_id: str = Field(min_length=1)
    start_date: str = Field(description="YYYY-MM-DD")
    days: int = Field(ge=1, le=30)
