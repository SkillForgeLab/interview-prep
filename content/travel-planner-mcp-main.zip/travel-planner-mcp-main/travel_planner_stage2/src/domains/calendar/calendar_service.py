from __future__ import annotations

from dataclasses import dataclass

from domains.calendar.calendar_repo import CalendarRepository
from domains.calendar.models import CalendarEvent


@dataclass(frozen=True)
class CalendarService:
    repo: CalendarRepository

    def list_upcoming_events(self, tenant_id: str) -> list[CalendarEvent]:
        self.repo.seed_if_empty(tenant_id)
        return self.repo.list_upcoming(tenant_id)
