from __future__ import annotations

import sqlite3
from dataclasses import dataclass

from domains.calendar.models import CalendarEvent


@dataclass(frozen=True)
class CalendarRepository:
    conn: sqlite3.Connection

    def init_schema(self) -> None:
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS calendar_events (
              tenant_id TEXT NOT NULL,
              event_id  TEXT NOT NULL,
              title     TEXT NOT NULL,
              start_iso TEXT NOT NULL,
              end_iso   TEXT NOT NULL,
              location  TEXT,
              PRIMARY KEY (tenant_id, event_id)
            );
            """
        )
        self.conn.commit()

    def seed_if_empty(self, tenant_id: str) -> None:
        row = self.conn.execute(
            "SELECT COUNT(1) AS c FROM calendar_events WHERE tenant_id=?;",
            (tenant_id,),
        ).fetchone()
        if row and int(row["c"]) > 0:
            return

        # Small deterministic seed for Stage 2 (no external calendar APIs).
        samples = [
            CalendarEvent(
                tenant_id=tenant_id,
                event_id="evt-100",
                title="Team sync",
                start_iso="2026-01-20T16:00:00-07:00",
                end_iso="2026-01-20T16:30:00-07:00",
                location="Zoom",
            ),
            CalendarEvent(
                tenant_id=tenant_id,
                event_id="evt-200",
                title="Doctor appointment",
                start_iso="2026-01-22T10:00:00-07:00",
                end_iso="2026-01-22T11:00:00-07:00",
                location="Clinic",
            ),
        ]

        for e in samples:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO calendar_events
                  (tenant_id, event_id, title, start_iso, end_iso, location)
                VALUES (?, ?, ?, ?, ?, ?);
                """,
                (e.tenant_id, e.event_id, e.title, e.start_iso, e.end_iso, e.location),
            )
        self.conn.commit()

    def list_upcoming(self, tenant_id: str) -> list[CalendarEvent]:
        rows = self.conn.execute(
            """
            SELECT tenant_id, event_id, title, start_iso, end_iso, location
            FROM calendar_events
            WHERE tenant_id=?
            ORDER BY start_iso ASC;
            """,
            (tenant_id,),
        ).fetchall()

        return [
            CalendarEvent(
                tenant_id=r["tenant_id"],
                event_id=r["event_id"],
                title=r["title"],
                start_iso=r["start_iso"],
                end_iso=r["end_iso"],
                location=r["location"],
            )
            for r in rows
        ]
