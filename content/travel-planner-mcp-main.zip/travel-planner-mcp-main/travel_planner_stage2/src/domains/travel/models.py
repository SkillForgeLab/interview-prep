from pydantic import BaseModel, Field


class SearchFlightsInput(BaseModel):
    tenant_id: str = Field(min_length=1)
    origin: str = Field(min_length=3)
    destination: str = Field(min_length=3)
    depart_date: str = Field(description="YYYY-MM-DD")
    return_date: str = Field(description="YYYY-MM-DD")


class FlightOption(BaseModel):
    flight_id: str
    airline: str
    depart_date: str
    return_date: str
    price_usd: int
    stops: int
