from __future__ import annotations

import logging
import random

from mcp.server.fastmcp import FastMCP

from domains.travel.models import SearchFlightsInput, FlightOption
from shared.logging import setup_json_logging

logger = logging.getLogger("domains.travel")

mcp = FastMCP(name="travel", json_response=True)


@mcp.tool()
def search_flights(payload: dict) -> dict:
    """
    Read-only deterministic stub.
    No external calls.
    """
    req = SearchFlightsInput.model_validate(payload)

    rng = random.Random(f"{req.tenant_id}|{req.origin}|{req.destination}|{req.depart_date}|{req.return_date}")
    airlines = ["Delta", "United", "American", "Southwest"]
    out: list[FlightOption] = []

    for i in range(3):
        price = rng.randint(220, 680)
        stops = rng.choice([0, 1])
        opt = FlightOption(
            flight_id=f"flt-{rng.randint(1000, 9999)}",
            airline=rng.choice(airlines),
            depart_date=req.depart_date,
            return_date=req.return_date,
            price_usd=price,
            stops=stops,
        )
        out.append(opt)

    logger.info(
        "travel.search_flights.returned",
        extra={"tenant_id": req.tenant_id, "origin": req.origin, "destination": req.destination},
    )
    return {"options": [o.model_dump() for o in out]}


if __name__ == "__main__":
    setup_json_logging()
    mcp.run()
