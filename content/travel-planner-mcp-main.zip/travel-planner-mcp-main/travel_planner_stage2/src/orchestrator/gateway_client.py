from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger("orchestrator.gateway_client")


@dataclass(frozen=True)
class GatewayClient:
    base_url: str
    timeout_seconds: float = 10.0

    async def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            resp = await client.post(self.base_url, json=payload)
            resp.raise_for_status()
            return resp.json()

    async def tools_list(self) -> dict[str, Any]:
        return await self._post({"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}})

    async def tools_call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        return await self._post(
            {"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": name, "arguments": arguments}}
        )

    async def resources_list(self) -> dict[str, Any]:
        return await self._post({"jsonrpc": "2.0", "id": 3, "method": "resources/list", "params": {}})

    async def resources_read(self, uri: str) -> dict[str, Any]:
        return await self._post({"jsonrpc": "2.0", "id": 4, "method": "resources/read", "params": {"uri": uri}})
