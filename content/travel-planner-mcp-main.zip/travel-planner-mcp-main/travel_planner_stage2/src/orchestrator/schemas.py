from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


ActionKind = Literal["resource_read", "tool_call", "finish"]


class NextStep(BaseModel):
    step_no: int = Field(ge=1)
    action: ActionKind
    rationale: str = Field(min_length=1)

    # For resource_read
    uri: str | None = None

    # For tool_call
    tool: str | None = None
    arguments: dict[str, Any] | None = None

    # For finish
    final_answer: str | None = None
