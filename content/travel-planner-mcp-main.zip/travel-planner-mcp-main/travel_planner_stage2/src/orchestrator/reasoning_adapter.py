from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Tuple

from openai import OpenAI

from orchestrator.schemas import NextStep

logger = logging.getLogger("orchestrator.reasoning_adapter")


def next_step_json_schema() -> dict[str, Any]:
    props: dict[str, Any] = {
        "step_no": {"type": "integer", "minimum": 1},
        "action": {"type": "string", "enum": ["resource_read", "tool_call", "finish"]},
        "rationale": {"type": "string", "minLength": 1},
        "uri": {"type": ["string", "null"]},
        "tool": {"type": ["string", "null"]},
        "arguments": {
            "type": ["object", "null"],
            "additionalProperties": False,
            "properties": {"payload_json": {"type": "string", "minLength": 2}},
            "required": ["payload_json"],
        },
        "final_answer": {"type": ["string", "null"]},
    }

    return {
        "name": "next_step",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": props,
            "required": list(props.keys()),
        },
        "strict": True,
    }


def _strip_code_fences(text: str) -> str:
    t = text.strip()
    if t.startswith("```"):
        lines = t.splitlines()
        if len(lines) >= 2 and lines[0].startswith("```") and lines[-1].strip() == "```":
            return "\n".join(lines[1:-1]).strip()
    return t


def _extract_single_json(text: str) -> Tuple[Any, str]:
    cleaned = _strip_code_fences(text)

    decoder = json.JSONDecoder()
    obj, end = decoder.raw_decode(cleaned.lstrip())

    trailing = cleaned.lstrip()[end:]
    trailing_non_ws = trailing.strip()
    return obj, trailing_non_ws


def _decode_payload_json(arguments: dict[str, Any] | None) -> dict[str, Any] | None:
    if not arguments or not isinstance(arguments, dict):
        return arguments

    payload_json = arguments.get("payload_json")
    if not isinstance(payload_json, str) or not payload_json.strip():
        return arguments

    try:
        decoded = json.loads(payload_json)
    except Exception as e:
        logger.warning(
            "planner.arguments.payload_json_decode_failed",
            extra={"error": str(e), "payload_json_prefix": payload_json[:200]},
        )
        return arguments

    if not isinstance(decoded, dict):
        logger.warning("planner.arguments.payload_json_not_object", extra={"decoded_type": type(decoded).__name__})
        return arguments

    return decoded


def _derived_state_from_evidence(evidence: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Compute minimal progress markers so the model can converge.
    """
    has_calendar = False
    weather_locations: set[str] = set()
    has_flights = False

    for e in evidence:
        if isinstance(e, dict):
            src = e.get("source")
            if isinstance(src, str) and src.startswith("calendar://upcoming/"):
                has_calendar = True

            tool = e.get("tool")
            if tool == "weather.get_forecast":
                args = e.get("arguments") or {}
                payload = args.get("payload") if isinstance(args, dict) else None
                if isinstance(payload, dict):
                    loc = payload.get("location")
                    if isinstance(loc, str) and loc.strip():
                        weather_locations.add(loc.strip())
                # Fallback if someone uses city/location at top-level
                if isinstance(args, dict):
                    loc2 = args.get("location") or args.get("city")
                    if isinstance(loc2, str) and loc2.strip():
                        weather_locations.add(loc2.strip())

            if tool == "travel.search_flights":
                has_flights = True

    # Normalize common names so planner logic is stable.
    normalized_weather = {w.lower() for w in weather_locations}
    weather_checked_phx = any("phoenix" in w or w == "phx" for w in normalized_weather)
    weather_checked_sfo = any("san francisco" in w or w == "sfo" for w in normalized_weather)

    return {
        "has_calendar": has_calendar,
        "weather_checked_phx": weather_checked_phx,
        "weather_checked_sfo": weather_checked_sfo,
        "has_flights": has_flights,
    }


@dataclass(frozen=True)
class ReasoningAdapter:
    api_key: str
    model: str

    def plan_next_step(
        self,
        *,
        goal: str,
        step_no: int,
        catalog: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> NextStep:
        client = OpenAI(api_key=self.api_key)

        derived = _derived_state_from_evidence(evidence)

        system = (
            "You are the Planner for a travel assistant.\n"
            "You must decide the next step in a ReAct loop.\n"
            "\n"
            "Hard rules:\n"
            "- You MUST echo the provided step_no exactly in the output step_no.\n"
            "- Choose exactly one next action.\n"
            "- Only use action=resource_read for calendar:// URIs.\n"
            "- NEVER use resource_read for weather or travel.\n"
            "- Weather must be action=tool_call with tool=weather.get_forecast.\n"
            "- Travel must be action=tool_call with tool=travel.search_flights.\n"
            "\n"
            "Progress rules (strict):\n"
            "- If derived_state.has_calendar is false: next action MUST be calendar resource_read.\n"
            "- If derived_state.has_calendar is true and weather for PHX is not checked: next action MUST be weather.get_forecast for PHX.\n"
            "- If weather for PHX is checked and weather for SFO is not checked: next action MUST be weather.get_forecast for SFO.\n"
            "- If weather for PHX and SFO are checked and derived_state.has_flights is false: next action MUST be travel.search_flights.\n"
            "- If derived_state.has_flights is true: next action MUST be finish.\n"
            "- Do not do extra weather checks once PHX and SFO have been checked.\n"
            "\n"
            "Output shape rules:\n"
            "- If action=resource_read: uri MUST be non-null calendar://...; tool, arguments, final_answer MUST be null.\n"
            "- If action=tool_call: tool MUST be non-null; arguments MUST be non-null.\n"
            "  IMPORTANT: strict schema requires arguments={\"payload_json\":\"<JSON string>\"}.\n"
            "  The decoded JSON string MUST be an object.\n"
            "  If tool schema requires payload, decoded object MUST be {\"payload\":{...}}.\n"
            "- If action=finish: final_answer MUST be non-null; uri, tool, arguments MUST be null.\n"
            "- Return ONLY valid JSON.\n"
        )

        user = {
            "goal": goal,
            "step_no": step_no,
            "derived_state": derived,
            "catalog": catalog,
            "evidence": evidence,
            "notes": {
                "calendar_resource_uri": "calendar://upcoming/{tenant_id}",
                "weather_tool": "weather.get_forecast",
                "travel_tool": "travel.search_flights",
                "locations": {"origin": "PHX", "destination": "SFO"},
            },
        }

        schema = next_step_json_schema()["schema"]
        resp = client.responses.create(
            model=self.model,
            input=[
                {"role": "system", "content": system},
                {"role": "user", "content": json.dumps(user)},
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "next_step",
                    "schema": schema,
                    "strict": True,
                }
            },
        )

        # logger.info(
        #     "planner.schema.keys",
        #     extra={"properties": list(schema["properties"].keys()), "required": schema["required"]},
        # )

        payload_text: str | None = getattr(resp, "output_text", None)
        if not payload_text:
            raise RuntimeError("Planner produced no output_text")

        data, trailing = _extract_single_json(payload_text)
        if trailing:
            logger.warning("planner.trailing_output_after_json", extra={"trailing": trailing[:500]})

        step = NextStep.model_validate(data)

        # Decode arguments payload_json -> dict.
        if step.action == "tool_call" and step.arguments:
            decoded = _decode_payload_json(step.arguments)
            step = NextStep.model_validate({**step.model_dump(), "arguments": decoded})

        # Enforce step_no authority (prevents drift).
        if step.step_no != step_no:
            step = NextStep.model_validate({**step.model_dump(), "step_no": step_no})

        logger.info(
            "planner.next_step",
            extra={"step_no": step.step_no, "action": step.action, "rationale": step.rationale},
        )
        return step
