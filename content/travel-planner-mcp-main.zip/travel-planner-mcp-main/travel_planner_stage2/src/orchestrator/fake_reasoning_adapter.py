from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from orchestrator.schemas import NextStep


@dataclass(frozen=True)
class FakeReasoningAdapter:
    """
    Deterministic stand-in for the real ReasoningAdapter.

    Use cases:
    - Local debugging
    - Offline runs
    - Reproducing failures
    - Validating ReAct loop behavior without LLMs

    This adapter encodes the EXPECTED Stage 2 planning order.
    """

    tenant_id: str

    def plan_next_step(
        self,
        *,
        goal: str,
        step_no: int,
        catalog: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> NextStep:

        # Stage 2 required order:
        # 1) Calendar resource
        # 2) Weather tool
        # 3) Travel tool
        # 4) Finish

        if step_no == 1:
            return NextStep(
                step_no=1,
                action="resource_read",
                rationale="Need calendar context to identify feasible travel dates.",
                uri=f"calendar://upcoming?tenant_id={self.tenant_id}",
            )

        if step_no == 2:
            return NextStep(
                step_no=2,
                action="tool_call",
                rationale="Need weather data to validate candidate travel dates.",
                tool="weather.get_forecast",
                arguments={
                    "tenant_id": self.tenant_id,
                    "location": "San Francisco, CA",
                    "date": "2026-01-23",
                },
            )

        if step_no == 3:
            return NextStep(
                step_no=3,
                action="tool_call",
                rationale="Dates and weather are known; search flights.",
                tool="travel.search_flights",
                arguments={
                    "tenant_id": self.tenant_id,
                    "origin": "PHX",
                    "destination": "SFO",
                    "depart_date": "2026-01-23",
                    "return_date": "2026-01-25",
                },
            )

        return NextStep(
            step_no=step_no,
            action="finish",
            rationale="All required evidence collected.",
            final_answer="Fake adapter: calendar, weather, and flight data collected successfully.",
        )
