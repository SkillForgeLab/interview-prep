from __future__ import annotations

import argparse
import asyncio
import logging

from shared.bootstrap import init_app
from shared.config import load_config
from orchestrator.gateway_client import GatewayClient
from orchestrator.reasoning_adapter import ReasoningAdapter
from orchestrator.react_loop import ReactDeps, run_react_loop
from orchestrator.fake_reasoning_adapter import FakeReasoningAdapter

logger = logging.getLogger("orchestrator")


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Stage 2 Orchestrator (ReAct loop)")
    p.add_argument(
        "--goal",
        required=True,
        help="Natural language goal for the planner (LLM decides next steps).",
    )
    p.add_argument(
        "--max-steps",
        type=int,
        default=8,
        help="Maximum ReAct steps before forcing finish.",
    )
    return p.parse_args()


async def _run(goal: str, max_steps: int) -> None:
    cfg = load_config()

    # Planner selection:
    # - If OPENAI_API_KEY is missing => deterministic fake planner
    # - If OPENAI_API_KEY is present => real LLM planner
    if cfg.openai_api_key in {"changeme"}:
        planner = FakeReasoningAdapter(tenant_id=cfg.tenant_id)
    else:
        planner = ReasoningAdapter(api_key=cfg.openai_api_key, model=cfg.openai_model)

    deps = ReactDeps(
        gateway=GatewayClient(base_url=cfg.gateway_url),
        planner=planner,
        tenant_id=cfg.tenant_id,
        db_path=cfg.app_db_path,
    )

    answer = await run_react_loop(deps=deps, goal=goal, max_steps=max_steps)

    print("\nFINAL ANSWER\n")
    print(answer)


def main() -> None:
    init_app()
    args = _parse_args()

    logger.info("orchestrator.started")
    asyncio.run(_run(goal=args.goal, max_steps=args.max_steps))


if __name__ == "__main__":
    main()
