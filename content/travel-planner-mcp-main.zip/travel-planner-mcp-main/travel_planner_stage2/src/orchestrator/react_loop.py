from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

from orchestrator.gateway_client import GatewayClient
from orchestrator.schemas import NextStep
from shared.persistence.db import DbConnFactory
from shared.persistence.repositories import EvidenceRepositorySQLite, DecisionRepositorySQLite

logger = logging.getLogger("orchestrator.react_loop")


@dataclass(frozen=True)
class ReactDeps:
    gateway: GatewayClient
    planner: Any  # ReasoningAdapter or test stub with same method
    tenant_id: str
    db_path: str


def _decode_payload_json_if_present(arguments: dict[str, Any] | None) -> dict[str, Any] | None:
    if not arguments or not isinstance(arguments, dict):
        return arguments

    payload_json = arguments.get("payload_json")
    if not isinstance(payload_json, str) or not payload_json.strip():
        return arguments

    try:
        decoded = json.loads(payload_json)
    except Exception as e:
        logger.warning(
            "react.arguments.payload_json_decode_failed",
            extra={"error": str(e), "payload_json_prefix": payload_json[:200]},
        )
        return arguments

    if not isinstance(decoded, dict):
        logger.warning("react.arguments.payload_json_not_object", extra={"decoded_type": type(decoded).__name__})
        return arguments

    return decoded


def _normalize_calendar_uri_for_tenant(uri: str, tenant_id: str) -> str:
    if uri == "calendar://upcoming/{tenant_id}":
        return f"calendar://upcoming/{tenant_id}"
    if uri == "calendar://upcoming/" or uri == "calendar://upcoming":
        return f"calendar://upcoming/{tenant_id}"
    if uri.startswith("calendar://upcoming/"):
        suffix = uri.split("calendar://upcoming/", 1)[1]
        if suffix.strip() == "":
            return f"calendar://upcoming/{tenant_id}"
    return uri


def _action_key(step: NextStep, normalized_args: dict[str, Any] | None) -> str:
    if step.action == "resource_read":
        return f"resource_read::{step.uri}"
    if step.action == "tool_call":
        args_str = json.dumps(normalized_args or {}, sort_keys=True)
        return f"tool_call::{step.tool}::{args_str}"
    if step.action == "finish":
        return "finish"
    return f"unknown::{step.action}"


def _weather_progress(evidence: list[dict[str, Any]]) -> tuple[bool, bool]:
    """
    Returns (phx_checked, sfo_checked) based on prior tool evidence.
    """
    phx = False
    sfo = False

    for e in evidence:
        if not isinstance(e, dict):
            continue
        if e.get("tool") != "weather.get_forecast":
            continue

        args = e.get("arguments") or {}
        payload = args.get("payload") if isinstance(args, dict) else None

        loc = None
        if isinstance(payload, dict):
            loc = payload.get("location") or payload.get("city")
        if not loc and isinstance(args, dict):
            loc = args.get("location") or args.get("city")

        if isinstance(loc, str):
            l = loc.strip().lower()
            if "phoenix" in l or l == "phx":
                phx = True
            if "san francisco" in l or l == "sfo":
                sfo = True

    return phx, sfo


async def run_react_loop(*, deps: ReactDeps, goal: str, max_steps: int = 8) -> str:
    db = DbConnFactory(db_path=deps.db_path)
    evidence_repo = EvidenceRepositorySQLite(db=db)
    decision_repo = DecisionRepositorySQLite(db=db)

    catalog_tools = await deps.gateway.tools_list()
    catalog_resources = await deps.gateway.resources_list()
    catalog = {"tools": catalog_tools.get("result"), "resources": catalog_resources.get("result")}

    evidence: list[dict[str, Any]] = []
    executed_action_keys: set[str] = set()

    logger.info("react.start", extra={"tenant_id": deps.tenant_id, "goal": goal})

    for step_no in range(1, max_steps + 1):
        step: NextStep = deps.planner.plan_next_step(
            goal=goal,
            step_no=step_no,
            catalog=catalog,
            evidence=evidence,
        )

        # Guardrail: planner step_no drift.
        if step.step_no != step_no:
            evidence.append(
                {
                    "source": "planner_guardrail",
                    "result": {
                        "warning": "planner_step_no_drift",
                        "expected_step_no": step_no,
                        "planner_step_no": step.step_no,
                        "rule": "Orchestrator step_no is authoritative.",
                    },
                }
            )

        if step.action == "resource_read":
            if not step.uri:
                raise RuntimeError("resource_read requires uri")

            step_uri = _normalize_calendar_uri_for_tenant(step.uri, deps.tenant_id)

            if step_uri.startswith("weather://") or step_uri.startswith("travel://"):
                evidence.append(
                    {
                        "source": "planner_guardrail",
                        "result": {
                            "error": "Invalid resource_read URI scheme",
                            "uri": step_uri,
                            "rule": "Only calendar:// is valid for resource_read; weather/travel must be tool_call.",
                        },
                    }
                )
                continue

            action_key = f"resource_read::{step_uri}"
            if action_key in executed_action_keys:
                evidence.append(
                    {
                        "source": "planner_guardrail",
                        "result": {
                            "warning": "duplicate_action_suppressed",
                            "action": "resource_read",
                            "uri": step_uri,
                            "rule": "Do not repeat the same resource_read; move to tools or finish.",
                        },
                    }
                )
                logger.warning("react.guardrail.duplicate_resource_read", extra={"step_no": step_no, "uri": step_uri})
                continue

            executed_action_keys.add(action_key)

            logger.info("react.act.resource_read", extra={"step_no": step_no, "uri": step_uri})
            resp = await deps.gateway.resources_read(step_uri)

            if resp.get("error"):
                err = resp["error"]
                evidence_id = evidence_repo.append_evidence(
                    tenant_id=deps.tenant_id,
                    source_kind="resource_error",
                    source_id=step_uri,
                    payload={"error": err},
                )
                decision_repo.append_decision(
                    tenant_id=deps.tenant_id,
                    step_no=step_no,
                    rationale=step.rationale,
                    action_kind="resource_read",
                    action_id=step_uri,
                    inputs={"uri": step_uri},
                    linked_evidence_ids=[evidence_id],
                )
                raise RuntimeError(f"Resource read failed: {err}")

            result = resp.get("result") or {}
            evidence_id = evidence_repo.append_evidence(
                tenant_id=deps.tenant_id,
                source_kind="resource",
                source_id=step_uri,
                payload={"result": result},
            )
            decision_repo.append_decision(
                tenant_id=deps.tenant_id,
                step_no=step_no,
                rationale=step.rationale,
                action_kind="resource_read",
                action_id=step_uri,
                inputs={"uri": step_uri},
                linked_evidence_ids=[evidence_id],
            )
            evidence.append({"source": step_uri, "result": result})

            logger.info("react.observe.resource", extra={"step_no": step_no, "evidence_id": evidence_id})
            continue

        if step.action == "tool_call":
            if not step.tool or not step.arguments:
                evidence.append(
                    {
                        "source": "planner_guardrail",
                        "result": {
                            "error": "Invalid tool_call step: tool_call requires non-null tool and arguments",
                            "step": step.model_dump(),
                            "rule": "If action=tool_call, tool must be set and arguments must be an object.",
                        },
                    }
                )
                logger.warning("react.guardrail.invalid_tool_call", extra={"step_no": step_no})
                continue

            normalized_args = _decode_payload_json_if_present(step.arguments)

            # Progress guardrail: once PHX + SFO weather are checked, block any more weather calls.
            phx_checked, sfo_checked = _weather_progress(evidence)
            if step.tool == "weather.get_forecast" and phx_checked and sfo_checked:
                evidence.append(
                    {
                        "source": "planner_guardrail",
                        "result": {
                            "warning": "weather_complete_stop",
                            "rule": "Weather for PHX and SFO is already checked. Next step MUST be travel.search_flights.",
                            "expected_next_tool": "travel.search_flights",
                        },
                    }
                )
                logger.warning("react.guardrail.weather_complete_stop", extra={"step_no": step_no})
                continue

            action_key = _action_key(step, normalized_args)
            if action_key in executed_action_keys:
                evidence.append(
                    {
                        "source": "planner_guardrail",
                        "result": {
                            "warning": "duplicate_action_suppressed",
                            "action": "tool_call",
                            "tool": step.tool,
                            "arguments": normalized_args,
                            "rule": "Do not repeat the same tool_call with the same arguments; move forward or finish.",
                        },
                    }
                )
                logger.warning("react.guardrail.duplicate_tool_call", extra={"step_no": step_no, "tool": step.tool})
                continue

            executed_action_keys.add(action_key)

            logger.info("react.act.tool_call", extra={"step_no": step_no, "tool": step.tool})
            resp = await deps.gateway.tools_call(step.tool, normalized_args or {})

            if resp.get("error"):
                err = resp["error"]
                evidence_id = evidence_repo.append_evidence(
                    tenant_id=deps.tenant_id,
                    source_kind="tool_error",
                    source_id=step.tool,
                    payload={"error": err, "arguments": normalized_args},
                )
                decision_repo.append_decision(
                    tenant_id=deps.tenant_id,
                    step_no=step_no,
                    rationale=step.rationale,
                    action_kind="tool_call",
                    action_id=step.tool,
                    inputs={"tool": step.tool, "arguments": normalized_args},
                    linked_evidence_ids=[evidence_id],
                )
                raise RuntimeError(f"Tool call failed: {err}")

            result = resp.get("result") or {}
            evidence_id = evidence_repo.append_evidence(
                tenant_id=deps.tenant_id,
                source_kind="tool",
                source_id=step.tool,
                payload={"arguments": normalized_args, "result": result},
            )
            decision_repo.append_decision(
                tenant_id=deps.tenant_id,
                step_no=step_no,
                rationale=step.rationale,
                action_kind="tool_call",
                action_id=step.tool,
                inputs={"tool": step.tool, "arguments": normalized_args},
                linked_evidence_ids=[evidence_id],
            )
            evidence.append({"tool": step.tool, "arguments": normalized_args, "result": result})

            logger.info("react.observe.tool", extra={"step_no": step_no, "evidence_id": evidence_id})
            continue

        if step.action == "finish":
            if not step.final_answer:
                raise RuntimeError("finish requires final_answer")

            decision_repo.append_decision(
                tenant_id=deps.tenant_id,
                step_no=step_no,
                rationale=step.rationale,
                action_kind="finish",
                action_id="finish",
                inputs={},
                linked_evidence_ids=[],
            )
            logger.info("react.finish", extra={"step_no": step_no})
            return step.final_answer

        raise RuntimeError(f"Unknown action: {step.action}")

    raise RuntimeError("max_steps exceeded")
