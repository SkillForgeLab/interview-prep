# Stage 2 — Evidence Map (resource URI → decision impact)

### Calendar resources
- calendar://events/week
  - Impact: Determines feasible travel windows (free time blocks).
  - If missing: Planner must ask the user for availability or finish with uncertainty.

### Weather tools
- weather.get_forecast(city, start_date, end_date)
  - Impact: Filters candidate windows by weather constraints (e.g., avoid storms).
  - If missing: Planner continues with flights but marks forecast as unknown.

### Travel tools
- travel.search_flights(origin, destination, depart_date, return_date)
  - Impact: Produces flight options for feasible date windows.
  - If missing: Planner cannot propose flight options.
