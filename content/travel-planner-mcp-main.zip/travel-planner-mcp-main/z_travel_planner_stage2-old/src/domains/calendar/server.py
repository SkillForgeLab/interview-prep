from __future__ import annotations

from typing import Optional

from fastmcp import FastMCP

from domains.calendar.store import CalendarStore
from shared.env import get_db_path

mcp = FastMCP("calendar")


# IMPORTANT:
# FastMCP requires at least one URI template parameter, so we include the query parameters.
@mcp.resource("calendar://availability{?tenant_id,start,end,min_nights}")
def availability(
        tenant_id: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
        min_nights: Optional[int] = 1,
) -> dict:
    """
    Calendar availability via MCP Resource.

    Gateway calls:
      resources/read { "uri": "calendar://availability?tenant_id=t1&start=2026-02-10&end=2026-02-20&min_nights=3" }

    FastMCP parses the query string and passes them as args.
    """
    store = CalendarStore(get_db_path())
    return store.get_trip_windows(
        tenant_id=tenant_id,
        start=start,
        end=end,
        min_nights=int(min_nights),
    )
