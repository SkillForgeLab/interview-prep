from __future__ import annotations

from domains.calendar.repo import CalendarRepository
from domains.calendar.schemas import CalendarEvent
from shared.sqlite import sqlite_conn


class SqliteCalendarRepository(CalendarRepository):
    def list_events(self, *, tenant_id: str, start_date: str, end_date: str) -> list[CalendarEvent]:
        # We store timestamps. For Stage 2 we do a simple range filter by date prefix.
        start_ts = f"{start_date}T00:00:00"
        end_ts = f"{end_date}T23:59:59"

        with sqlite_conn() as con:
            cur = con.cursor()
            cur.execute(
                """
                SELECT start_ts, end_ts, title
                FROM calendar_events
                WHERE tenant_id = ?
                  AND NOT (end_ts < ? OR start_ts > ?)
                ORDER BY start_ts ASC;
                """,
                (tenant_id, start_ts, end_ts),
            )
            rows = cur.fetchall()

        return [CalendarEvent(start_ts=r[0], end_ts=r[1], title=r[2]) for r in rows]
