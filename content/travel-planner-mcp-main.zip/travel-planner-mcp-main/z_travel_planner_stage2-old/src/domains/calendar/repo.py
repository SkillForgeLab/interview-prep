from __future__ import annotations

from abc import ABC, abstractmethod

from domains.calendar.schemas import CalendarEvent


class CalendarRepository(ABC):
    @abstractmethod
    def list_events(self, *, tenant_id: str, start_date: str, end_date: str) -> list[CalendarEvent]:
        raise NotImplementedError
