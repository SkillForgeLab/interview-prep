from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, date, time, timedelta
from pathlib import Path
from typing import Iterable


def _parse_iso(ts: str) -> datetime:
    # Your seed uses "YYYY-MM-DDTHH:MM:SS" (no timezone).
    return datetime.fromisoformat(ts)


def _as_date(d: str) -> date:
    return date.fromisoformat(d)


def _merge_intervals(intervals: list[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    if not intervals:
        return []
    intervals.sort(key=lambda x: x[0])
    merged: list[tuple[datetime, datetime]] = [intervals[0]]
    for start, end in intervals[1:]:
        last_s, last_e = merged[-1]
        if start <= last_e:
            merged[-1] = (last_s, max(last_e, end))
        else:
            merged.append((start, end))
    return merged


@dataclass(frozen=True)
class CalendarStore:
    db_path: Path

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _load_events(self, tenant_id: str, start_dt: datetime, end_dt: datetime) -> list[tuple[datetime, datetime]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT start_ts, end_ts
                FROM calendar_events
                WHERE tenant_id = ?
                  AND end_ts > ?
                  AND start_ts < ?
                ORDER BY start_ts ASC;
                """,
                (tenant_id, start_dt.isoformat(), end_dt.isoformat()),
            ).fetchall()

        intervals: list[tuple[datetime, datetime]] = []
        for s, e in rows:
            intervals.append((_parse_iso(s), _parse_iso(e)))
        return intervals

    def get_trip_windows(self, tenant_id: str, start: str, end: str, min_nights: int) -> dict:
        """
        Compute free windows between calendar events.

        Interpretation:
        - start/end are DATEs (YYYY-MM-DD)
        - end is treated as INCLUSIVE for user-friendliness
          => search range is [start 00:00, (end+1) 00:00)

        Output windows:
        - start_date: gap start DATE (YYYY-MM-DD)
        - end_date: gap end DATE (YYYY-MM-DD) as a checkout date (end boundary date)
        - nights: number of nights = (end_date - start_date).days
        """
        start_d = _as_date(start)
        end_d = _as_date(end)

        range_start = datetime.combine(start_d, time.min)
        range_end_excl = datetime.combine(end_d + timedelta(days=1), time.min)

        busy = _merge_intervals(self._load_events(tenant_id, range_start, range_end_excl))

        # Build free gaps in [range_start, range_end_excl)
        gaps: list[tuple[datetime, datetime]] = []
        cursor = range_start

        for b_start, b_end in busy:
            if b_start > cursor:
                gaps.append((cursor, b_start))
            cursor = max(cursor, b_end)

        if cursor < range_end_excl:
            gaps.append((cursor, range_end_excl))

        windows = []
        for g_start, g_end in gaps:
            # Convert to "trip days" as dates.
            # Use the date of the gap start, and the date of the gap end as the checkout date.
            s_date = g_start.date()
            e_date = g_end.date()
            nights = (e_date - s_date).days

            if nights >= int(min_nights):
                windows.append(
                    {
                        "start_date": s_date.isoformat(),
                        "end_date": e_date.isoformat(),
                        "nights": nights,
                    }
                )

        return {
            "start": start,
            "end": end,
            "min_nights": int(min_nights),
            "windows": windows,
        }
