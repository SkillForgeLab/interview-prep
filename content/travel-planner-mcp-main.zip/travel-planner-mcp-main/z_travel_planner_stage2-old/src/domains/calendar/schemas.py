from __future__ import annotations

from pydantic import BaseModel, Field


class CalendarEvent(BaseModel):
    start_ts: str
    end_ts: str
    title: str


class EventsQuery(BaseModel):
    tenant_id: str = Field(min_length=1)
    start: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD
    end: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD


class AvailabilityQuery(BaseModel):
    tenant_id: str = Field(min_length=1)
    start: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD
    end: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD
    min_nights: int = Field(ge=1, le=30)


class AvailabilityWindow(BaseModel):
    start_date: str
    end_date: str
    nights: int


class AvailabilityResult(BaseModel):
    start: str
    end: str
    min_nights: int
    windows: list[AvailabilityWindow]
