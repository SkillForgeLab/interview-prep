from __future__ import annotations

import json
from fastmcp import FastMCP

from domains.weather.schemas import ForecastQuery, ForecastResult
from domains.weather.sqlite_repo import SqliteWeatherRepository
from shared.logging import log

mcp = FastMCP("weather")
repo = SqliteWeatherRepository()


@mcp.tool()
def get_forecast(tenant_id: str, location: str, start_date: str, end_date: str) -> str:
    """
    Read-only weather forecast.
    Returns JSON text (gateway will parse into structured evidence).
    """
    q = ForecastQuery(
        tenant_id=tenant_id,
        location=location.upper(),
        start_date=start_date,
        end_date=end_date,
    )

    days = repo.get_forecast(
        tenant_id=q.tenant_id,
        location=q.location,
        start_date=q.start_date,
        end_date=q.end_date,
    )

    out = ForecastResult(
        location=q.location,
        start_date=q.start_date,
        end_date=q.end_date,
        days=days,
    )

    log(
        "weather.get_forecast",
        tenant_id=q.tenant_id,
        location=q.location,
        start_date=q.start_date,
        end_date=q.end_date,
        days_count=len(days),
    )

    return out.model_dump_json(indent=2)


if __name__ == "__main__":
    mcp.run()
