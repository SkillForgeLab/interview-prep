from __future__ import annotations

from pydantic import BaseModel, Field


class ForecastQuery(BaseModel):
    tenant_id: str = Field(min_length=1)
    location: str = Field(min_length=3, max_length=3)  # airport code for simplicity
    start_date: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD
    end_date: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD


class DailyForecast(BaseModel):
    date: str
    summary: str
    high_f: int
    low_f: int
    precip_pct: int


class ForecastResult(BaseModel):
    location: str
    start_date: str
    end_date: str
    days: list[DailyForecast]
