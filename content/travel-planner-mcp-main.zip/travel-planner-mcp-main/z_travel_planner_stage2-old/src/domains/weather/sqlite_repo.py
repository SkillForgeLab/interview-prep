from __future__ import annotations

from domains.weather.repo import WeatherRepository
from domains.weather.schemas import DailyForecast
from shared.sqlite import sqlite_conn


class SqliteWeatherRepository(WeatherRepository):
    def get_forecast(
        self, *, tenant_id: str, location: str, start_date: str, end_date: str
    ) -> list[DailyForecast]:
        with sqlite_conn() as con:
            cur = con.cursor()
            cur.execute(
                """
                SELECT date, summary, high_f, low_f, precip_pct
                FROM weather_forecasts
                WHERE tenant_id = ?
                  AND location = ?
                  AND date >= ?
                  AND date <= ?
                ORDER BY date ASC;
                """,
                (tenant_id, location, start_date, end_date),
            )
            rows = cur.fetchall()

        return [
            DailyForecast(
                date=r[0],
                summary=r[1],
                high_f=int(r[2]),
                low_f=int(r[3]),
                precip_pct=int(r[4]),
            )
            for r in rows
        ]
