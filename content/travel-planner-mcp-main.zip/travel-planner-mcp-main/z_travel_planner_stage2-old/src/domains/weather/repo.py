from __future__ import annotations

from abc import ABC, abstractmethod

from domains.weather.schemas import DailyForecast


class WeatherRepository(ABC):
    @abstractmethod
    def get_forecast(
        self, *, tenant_id: str, location: str, start_date: str, end_date: str
    ) -> list[DailyForecast]:
        raise NotImplementedError
