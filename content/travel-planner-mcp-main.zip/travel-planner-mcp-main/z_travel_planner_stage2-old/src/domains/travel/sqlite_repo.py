from __future__ import annotations

from domains.travel.repo import FlightSearchRepository
from domains.travel.schemas import FlightOption
from shared.sqlite import sqlite_conn


class SqliteFlightSearchRepository(FlightSearchRepository):
    def search_flights(
        self, *, tenant_id: str, origin: str, destination: str, date: str
    ) -> list[FlightOption]:
        with sqlite_conn() as con:
            cur = con.cursor()
            cur.execute(
                """
                SELECT flight_number, depart_time, arrive_time, price_usd
                FROM flights
                WHERE tenant_id = ?
                  AND origin = ?
                  AND destination = ?
                  AND date = ?
                ORDER BY price_usd ASC;
                """,
                (tenant_id, origin, destination, date),
            )
            rows = cur.fetchall()

        return [
            FlightOption(
                flight_number=r[0],
                depart_time=r[1],
                arrive_time=r[2],
                price_usd=int(r[3]),
            )
            for r in rows
        ]
