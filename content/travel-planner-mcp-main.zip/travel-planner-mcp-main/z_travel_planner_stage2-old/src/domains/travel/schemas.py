from __future__ import annotations

from pydantic import BaseModel, Field


class SearchFlightsInput(BaseModel):
    tenant_id: str = Field(min_length=1)
    origin: str = Field(min_length=3, max_length=3)
    destination: str = Field(min_length=3, max_length=3)
    date: str = Field(min_length=10, max_length=10)  # YYYY-MM-DD


class FlightOption(BaseModel):
    flight_number: str
    depart_time: str
    arrive_time: str
    price_usd: int


class SearchFlightsOutput(BaseModel):
    origin: str
    destination: str
    date: str
    options: list[FlightOption]
