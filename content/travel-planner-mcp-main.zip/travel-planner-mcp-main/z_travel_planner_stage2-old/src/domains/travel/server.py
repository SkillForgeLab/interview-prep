from __future__ import annotations

import json
from fastmcp import FastMCP

from domains.travel.schemas import SearchFlightsInput, SearchFlightsOutput
from domains.travel.sqlite_repo import SqliteFlightSearchRepository
from shared.logging import log

mcp = FastMCP("travel")
repo = SqliteFlightSearchRepository()


@mcp.tool()
def search_flights(tenant_id: str, origin: str, destination: str, date: str) -> str:
    """
    Read-only flight search.
    Returns JSON text (gateway will parse into structured evidence).
    """
    inp = SearchFlightsInput(
        tenant_id=tenant_id,
        origin=origin.upper(),
        destination=destination.upper(),
        date=date,
    )

    options = repo.search_flights(
        tenant_id=inp.tenant_id,
        origin=inp.origin,
        destination=inp.destination,
        date=inp.date,
    )

    out = SearchFlightsOutput(
        origin=inp.origin,
        destination=inp.destination,
        date=inp.date,
        options=options,
    )

    log(
        "travel.search_flights",
        tenant_id=inp.tenant_id,
        origin=inp.origin,
        destination=inp.destination,
        date=inp.date,
        options_count=len(options),
    )

    return out.model_dump_json(indent=2)


if __name__ == "__main__":
    mcp.run()
