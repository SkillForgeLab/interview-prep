from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Optional, TypedDict


Phase = Literal["REASON", "ACT", "OBSERVE"]


class PlannerDecision(TypedDict, total=False):
    action: Literal["read_resource", "call_tool", "finish"]
    name: str | None          # tool name for call_tool (namespaced), e.g. "weather.get_forecast"
    uri: str | None           # resource uri for read_resource
    arguments: dict[str, Any] | None
    final_message: str | None
    reason: str               # short explanation for explainability


@dataclass(frozen=True)
class RunResult:
    final_message: str
    last_observation: Any | None
    steps: int
