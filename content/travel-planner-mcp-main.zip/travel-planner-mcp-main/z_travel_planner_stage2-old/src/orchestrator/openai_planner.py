from __future__ import annotations

import json
from typing import Any, Dict

from openai import OpenAI

from orchestrator.planning_adapter import PlanningAdapter
from orchestrator.types import PlannerDecision
from shared.logging import log


class OpenAIResponsesPlannerAdapter(PlanningAdapter):
    """
    Planner using OpenAI Responses API (not Chat Completions).
    Stage 2: Planner chooses next step (resource read vs tool call vs finish).

    Note:
    - This planner does NOT call tools directly.
    - Orchestrator executes actions by calling the Gateway.
    """

    def __init__(self, *, client: OpenAI, model: str) -> None:
        self._client = client
        self._model = model

    async def decide_next_action(self, *, user_request: str, observation: Any | None) -> PlannerDecision:
        # For simplicity in Stage 2, use a synchronous OpenAI client call inside async method.
        # This is acceptable for local learning; later stages can make it fully async.
        schema = {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["read_resource", "call_tool", "finish"]},
                "name": {"type": ["string", "null"]},
                "uri": {"type": ["string", "null"]},
                "arguments": {"type": ["object", "null"]},
                "final_message": {"type": ["string", "null"]},
                "reason": {"type": "string"},
            },
            "required": ["action", "reason"],
            "additionalProperties": False,
        }

        prompt = {
            "role": "system",
            "content": [
                {
                    "type": "input_text",
                    "text": (
                        "You are the Planner for Stage 2.\n"
                        "You must choose exactly one next action.\n"
                        "You do not execute tools. The orchestrator will.\n\n"
                        "Available actions:\n"
                        "- read_resource: use a calendar:// URI\n"
                        "- call_tool: use a namespaced tool name like weather.get_forecast or travel.search_flights\n"
                        "- finish: return final_message\n\n"
                        "Preferred order:\n"
                        "1) calendar availability (resource)\n"
                        "2) weather forecast (tool)\n"
                        "3) travel flight search (tool)\n"
                        "4) finish\n\n"
                        "Always include a short reason.\n"
                    ),
                }
            ],
        }

        user = {
            "role": "user",
            "content": [
                {"type": "input_text", "text": f"USER_REQUEST:\n{user_request}"},
                {"type": "input_text", "text": f"OBSERVATION:\n{json.dumps(observation, indent=2) if observation is not None else 'null'}"},
            ],
        }

        log("planner.openai.request", model=self._model)

        resp = self._client.responses.create(
            model=self._model,
            input=[prompt, user],
            text={"format": {"type": "json_schema", "name": "planner_decision", "schema": schema}},
        )

        # Responses API returns output items; easiest is to use output_text for structured JSON text.
        raw = resp.output_text
        decision = json.loads(raw)

        log("planner.openai.decision", decision=decision)

        # Minimal validation
        if decision["action"] == "call_tool":
            if not decision.get("name"):
                raise ValueError("Planner decided call_tool but name is missing.")
            if not isinstance(decision.get("arguments") or {}, dict):
                raise ValueError("Planner arguments must be an object.")
        if decision["action"] == "read_resource":
            if not decision.get("uri"):
                raise ValueError("Planner decided read_resource but uri is missing.")
        if decision["action"] == "finish":
            if not decision.get("final_message"):
                decision["final_message"] = "Done."

        return decision  # type: ignore[return-value]
