from __future__ import annotations

import json
from typing import Any, Dict

import httpx

from orchestrator.planning_adapter import PlanningAdapter
from orchestrator.types import PlannerDecision, RunResult
from shared.config import gateway_url, http_timeout_seconds
from shared.logging import log


def _normalize_gateway_result(result: Dict[str, Any]) -> Any:
    """
    Normalize gateway result into structured evidence.

    Supports:
    - {"structured": {...}}
    - {"content":[{"type":"text","text":"{...json...}"}]}
    - {"result":"{...json...}"}  (string-wrapped JSON)
    """
    # 1) Preferred
    structured = result.get("structured")
    if structured is not None:
        return structured

    # 2) Some stacks return {"result": "<json-string>"}
    wrapped = result.get("result")
    if isinstance(wrapped, str):
        s = wrapped.lstrip()
        if s.startswith("{") or s.startswith("["):
            try:
                return json.loads(wrapped)
            except json.JSONDecodeError:
                return result

    # 3) Text content fallback
    content = result.get("content") or []
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict) and first.get("type") == "text":
            txt = first.get("text", "")
            if isinstance(txt, str):
                s = txt.lstrip()
                if s.startswith("{") or s.startswith("["):
                    try:
                        return json.loads(txt)
                    except json.JSONDecodeError:
                        return result

    return result



class ReactOrchestrator:
    def __init__(self, *, planner: PlanningAdapter) -> None:
        self._planner = planner

    async def run(self, *, user_request: str, max_steps: int = 6) -> RunResult:
        observation: Any | None = None
        final_message = ""
        step = 0

        timeout = http_timeout_seconds()
        url = gateway_url()

        async with httpx.AsyncClient(timeout=timeout) as client:
            while step < max_steps:
                step += 1
                log("orchestrator.react.reason", step=step, phase="REASON", user_request=user_request, observation=observation)

                decision: PlannerDecision = await self._planner.decide_next_action(
                    user_request=user_request,
                    observation=observation,
                )

                log("orchestrator.react.reason.decision", step=step, phase="REASON", decision=decision)

                action = decision["action"]

                # -------- FINISH --------
                if action == "finish":
                    final_message = decision.get("final_message") or "Done."
                    log("orchestrator.react.finish", step=step, phase="REASON", final_message=final_message)
                    return RunResult(final_message=final_message, last_observation=observation, steps=step)

                # -------- READ RESOURCE --------
                if action == "read_resource":
                    uri = decision.get("uri")
                    if not uri:
                        raise ValueError("Planner read_resource missing uri")

                    rpc_req = {"jsonrpc": "2.0", "id": step, "method": "resources/read", "params": {"uri": uri}}
                    log("orchestrator.react.act", step=step, phase="ACT", method="resources/read", uri=uri)

                    resp = await client.post(url, json=rpc_req)
                    payload = resp.json()

                    if "error" in payload:
                        log("orchestrator.react.observe.error", step=step, phase="OBSERVE", error=payload["error"])
                        return RunResult(
                            final_message="Resource read failed. See error in observation.",
                            last_observation=payload["error"],
                            steps=step,
                        )

                    # resources/read returns {"contents":[{...,"structured":...}]}
                    result = payload.get("result") or {}
                    contents = (result.get("contents") or [])
                    first = contents[0] if contents else {}
                    observation = first.get("structured") or first

                    log("orchestrator.react.observe", step=step, phase="OBSERVE", observation=observation)
                    continue

                # -------- CALL TOOL --------
                if action == "call_tool":
                    name = decision.get("name")
                    arguments = decision.get("arguments") or {}
                    if not name:
                        raise ValueError("Planner call_tool missing name")
                    if not isinstance(arguments, dict):
                        raise ValueError("Planner call_tool arguments must be object")

                    rpc_req = {
                        "jsonrpc": "2.0",
                        "id": step,
                        "method": "tools/call",
                        "params": {"name": name, "arguments": arguments},
                    }
                    log("orchestrator.react.act", step=step, phase="ACT", method="tools/call", tool_name=name, tool_args=arguments)

                    resp = await client.post(url, json=rpc_req)
                    payload = resp.json()

                    if "error" in payload:
                        log("orchestrator.react.observe.error", step=step, phase="OBSERVE", error=payload["error"])
                        return RunResult(
                            final_message="Tool call failed. See error in observation.",
                            last_observation=payload["error"],
                            steps=step,
                        )

                    rpc_result = payload.get("result")
                    print("DEBUG payload.result type:",
                          type(payload.get("result")), payload.get("result"))

                    if isinstance(rpc_result, dict):
                        observation = _normalize_gateway_result(rpc_result)
                    elif isinstance(rpc_result, str):
                        observation = _normalize_gateway_result({"result": rpc_result})
                    else:
                        observation = {"value": rpc_result}

                    log("orchestrator.react.observe", step=step, phase="OBSERVE", observation=observation)
                    continue

                raise ValueError(f"Unknown action: {action}")

        return RunResult(final_message="Max steps reached.", last_observation=observation, steps=step)
