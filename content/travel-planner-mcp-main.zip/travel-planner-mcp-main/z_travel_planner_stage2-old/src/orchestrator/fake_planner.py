import json
from typing import Any


def _extract_windows(observation: Any) -> list[dict]:
    if not isinstance(observation, dict):
        return []

    # direct
    if isinstance(observation.get("windows"), list):
        return observation["windows"]

    # gateway may wrap JSON in "result"
    raw = observation.get("result")
    if isinstance(raw, str):
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict) and isinstance(obj.get("windows"), list):
                return obj["windows"]
        except Exception:
            pass

    # gateway may wrap in structured.result as JSON string
    structured = observation.get("structured")
    if isinstance(structured, dict):
        raw2 = structured.get("result")
        if isinstance(raw2, str):
            try:
                obj2 = json.loads(raw2)
                if isinstance(obj2, dict) and isinstance(obj2.get("windows"), list):
                    return obj2["windows"]
            except Exception:
                pass

    return []

class FakePlannerAdapter:
    async def decide_next_action(self, user_request: str, observation: dict | None) -> dict:
        if observation is None:
            return {
                "action": "read_resource",
                "uri": "calendar://availability?tenant_id=t1&start=2026-02-10&end=2026-02-20&min_nights=3",
            }

        # After calendar availability, call weather next
        if "windows" in observation:
            return {
                "action": "call_tool",
                "name": "weather.get_forecast",
                "arguments": {"tenant_id": "t1", "location": "JFK"},
            }

        # After weather, search flights
        if "forecast" in observation or "days" in observation or "location" in observation:
            return {
                "action": "call_tool",
                "name": "travel.search_flights",
                "arguments": {"tenant_id": "t1", "origin": "PHX", "destination": "JFK", "date": "2026-02-10"},
            }

        return {"action": "finish", "final_message": "Unable to plan further with available evidence."}
