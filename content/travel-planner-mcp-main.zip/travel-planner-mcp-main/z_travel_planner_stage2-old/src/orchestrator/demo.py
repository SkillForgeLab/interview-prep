from __future__ import annotations

import os

from openai import OpenAI

from orchestrator.fake_planner import FakePlannerAdapter
from orchestrator.openai_planner import OpenAIResponsesPlannerAdapter
from orchestrator.react_loop import ReactOrchestrator
from shared.logging import log


async def main() -> None:
    user_request = "Plan a 3-day trip from PHX to JFK that fits my calendar and avoids bad weather."

    model = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()

    if not api_key:
        planner = FakePlannerAdapter()
        log("orchestrator.demo.planner", planner="FakePlannerAdapter")
    else:
        client = OpenAI(api_key=api_key)
        planner = OpenAIResponsesPlannerAdapter(client=client, model=model)
        log("orchestrator.demo.planner", planner="OpenAIResponsesPlannerAdapter", model=model)

    orch = ReactOrchestrator(planner=planner)
    result = await orch.run(user_request=user_request)

    log("orchestrator.demo.result", result=result.__dict__)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
