from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from orchestrator.types import PlannerDecision


class PlanningAdapter(ABC):
    @abstractmethod
    async def decide_next_action(self, *, user_request: str, observation: Any | None) -> PlannerDecision:
        """
        Decide exactly one next action.

        Rules (Stage 2):
        - If no observation yet: typically start with calendar availability resource read.
        - Then weather forecast tool.
        - Then travel flight search tool.
        - Then finish.
        """
        raise NotImplementedError
