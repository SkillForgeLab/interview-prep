import json
import logging
import sys
from typing import Any, Dict

# Important for STDIO MCP servers:
#  - keep protocol on stdout;
#  - logs go to stderr.

logging.basicConfig(level=logging.INFO,
                    stream=sys.stderr,
                    format="%(message)s")


def log(event: str, **fields: Any) -> None:
    payload: Dict[str, Any] = {"event": event, **fields}
    logging.info(json.dumps(payload, ensure_ascii=False))
