from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Iterator

from shared.config import app_db_path


@contextmanager
def sqlite_conn() -> Iterator[sqlite3.Connection]:
    con = sqlite3.connect(app_db_path())
    try:
        yield con
    finally:
        con.close()
