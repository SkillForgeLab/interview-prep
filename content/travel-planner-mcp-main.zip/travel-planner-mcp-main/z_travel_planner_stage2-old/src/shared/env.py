from __future__ import annotations

import os
from pathlib import Path


def get_repo_root() -> Path:
    # src/shared/env.py -> shared -> src -> repo_root
    return Path(__file__).resolve().parents[2]


def get_db_path() -> Path:
    """
    Deterministic DB path:
      - if APP_DB_PATH is set: use it (temp db in tests)
      - else: repo_root/data/app.db
    """
    env = os.environ.get("APP_DB_PATH")
    if env:
        return Path(env)

    return get_repo_root() / "data" / "app.db"
