from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class DomainServerLaunch:
    command: str
    args: list[str]


def _csv_env(name: str, default: str) -> list[str]:
    raw = os.environ.get(name, default)
    return [x.strip() for x in raw.split(",") if x.strip()]


def travel_launch() -> DomainServerLaunch:
    return DomainServerLaunch(
        command=os.environ.get("TRAVEL_SERVER_COMMAND", "uv"),
        args=_csv_env("TRAVEL_SERVER_ARGS", "run,python,-m,domains.travel.server"),
    )


def weather_launch() -> DomainServerLaunch:
    return DomainServerLaunch(
        command=os.environ.get("WEATHER_SERVER_COMMAND", "uv"),
        args=_csv_env("WEATHER_SERVER_ARGS", "run,python,-m,domains.weather.server"),
    )


def calendar_launch() -> DomainServerLaunch:
    return DomainServerLaunch(
        command=os.environ.get("CALENDAR_SERVER_COMMAND", "uv"),
        args=_csv_env("CALENDAR_SERVER_ARGS", "run,python,-m,domains.calendar.server"),
    )


def gateway_url() -> str:
    return os.environ.get("GATEWAY_URL", "http://127.0.0.1:8080/mcp")


def http_timeout_seconds() -> float:
    return float(os.environ.get("HTTP_TIMEOUT_SECONDS", "10"))


def app_db_path() -> str:
    return os.environ.get("APP_DB_PATH", "./data/app.db")
