from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Domain = Literal["travel", "weather", "calendar"]


@dataclass(frozen=True)
class ToolRef:
    domain: Domain
    tool_name: str  # server-local tool name (e.g., "search_flights")


@dataclass(frozen=True)
class ResourceRef:
    domain: Domain
    uri: str  # full resource URI (e.g., "calendar://availability?...")

