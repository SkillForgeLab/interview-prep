from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Optional, Tuple

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from shared.logging import log


# ---------- Normalized result shapes ----------

@dataclass(frozen=True)
class NormalizedCallResult:
    content: list[dict]
    structured: Any | None


def _try_parse_json(text: str) -> Any | None:
    text = (text or "").strip()
    if not text:
        return None
    if not (text.startswith("{") or text.startswith("[")):
        return None
    try:
        return json.loads(text)
    except Exception:
        return None


def normalize_call_result(call_result: Any) -> NormalizedCallResult:
    dumped = call_result.model_dump() if hasattr(call_result, "model_dump") else call_result

    content = dumped.get("content") or []
    if not isinstance(content, list):
        content = []

    structured: Any | None = None

    if content:
        first = content[0]
        if isinstance(first, dict) and first.get("type") == "text":
            parsed = _try_parse_json(first.get("text") or "")
            if parsed is not None:
                structured = parsed

    return NormalizedCallResult(content=content, structured=structured)


def normalize_resource_read(read_result: Any) -> dict:
    """
    For Stage 2, we normalize resource reads into:
      { "contents": [...], "resource": <parsed-json-or-text> }
    """
    norm = normalize_call_result(read_result)

    if norm.structured is not None:
        return {"contents": norm.content, "resource": norm.structured}

    text = ""
    if norm.content:
        first = norm.content[0]
        if isinstance(first, dict) and first.get("type") == "text":
            text = first.get("text") or ""

    return {"contents": norm.content, "resource": {"text": text}}


# ---------- Logging helpers ----------

def log_domain(domain: str, event: str, **fields: Any) -> None:
    log(f"{domain}.{event}", **fields)


# ---------- MCP client wrapper ----------

class McpStdioClient:
    def __init__(self, name: str, command: str, args: list[str]) -> None:
        self._name = name
        self._params = StdioServerParameters(command=command, args=args)

    async def list_tools(self) -> Any:
        async with stdio_client(self._params) as (r, w):
            async with ClientSession(r, w) as session:
                await session.initialize()
                return await session.list_tools()

    async def call_tool(self, tool_name: str, arguments: dict) -> Any:
        async with stdio_client(self._params) as (r, w):
            async with ClientSession(r, w) as session:
                await session.initialize()
                return await session.call_tool(tool_name, arguments)

    async def list_resources(self) -> Any:
        async with stdio_client(self._params) as (r, w):
            async with ClientSession(r, w) as session:
                await session.initialize()
                return await session.list_resources()

    async def read_resource(self, uri: str) -> Any:
        async with stdio_client(self._params) as (r, w):
            async with ClientSession(r, w) as session:
                await session.initialize()
                return await session.read_resource(uri)


# ---------- Build clients from env ----------

def _env(name: str, default: str) -> str:
    return os.getenv(name, default)


def build_clients() -> Tuple[McpStdioClient, McpStdioClient, McpStdioClient]:
    travel_cmd = _env("TRAVEL_SERVER_COMMAND", "uv")
    travel_args = _env("TRAVEL_SERVER_ARGS", "run,python,-m,domains.travel.server").split(",")

    weather_cmd = _env("WEATHER_SERVER_COMMAND", "uv")
    weather_args = _env("WEATHER_SERVER_ARGS", "run,python,-m,domains.weather.server").split(",")

    calendar_cmd = _env("CALENDAR_SERVER_COMMAND", "uv")
    calendar_args = _env("CALENDAR_SERVER_ARGS", "run,python,-m,domains.calendar.server").split(",")

    travel = McpStdioClient("travel", travel_cmd, travel_args)
    weather = McpStdioClient("weather", weather_cmd, weather_args)
    calendar = McpStdioClient("calendar", calendar_cmd, calendar_args)

    return travel, weather, calendar
