from __future__ import annotations

from typing import Any, Dict

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from gateway.mcp_clients import (
    build_clients,
    log_domain,
    normalize_call_result,
    normalize_resource_read,
)
from shared.jsonrpc import JsonRpcRequest, RpcError
from shared.logging import log

app = FastAPI(title="MCP Gateway (Stage 2)", version="0.2.0")


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


def _rpc_ok(rpc_id: int | str, result: Any) -> JSONResponse:
    return JSONResponse({"jsonrpc": "2.0", "id": rpc_id, "result": result})


def _rpc_err(rpc_id: int | str, e: RpcError) -> JSONResponse:
    return JSONResponse({"jsonrpc": "2.0", "id": rpc_id, "error": e.to_jsonrpc_error()})


@app.post("/mcp")
async def mcp_endpoint(req: JsonRpcRequest) -> JSONResponse:
    """
    Minimal MCP-style JSON-RPC façade.

    Methods:
      - tools/list
      - tools/call
      - resources/list
      - resources/read
    """
    try:
        if req.get("jsonrpc") != "2.0":
            raise RpcError(code=-32600, message="Invalid Request: jsonrpc must be '2.0'")

        rpc_id = req.get("id")
        method = req.get("method")
        params = req.get("params", {}) or {}

        log("gateway.rpc.request", id=rpc_id, method=method)

        travel, weather, calendar = build_clients()

        # ---------- tools/list ----------
        if method == "tools/list":
            t_tools = await travel.list_tools()
            w_tools = await weather.list_tools()

            def _dump(x: Any) -> Any:
                return x.model_dump() if hasattr(x, "model_dump") else x

            merged: Dict[str, Any] = {"tools": []}

            for tool in _dump(t_tools).get("tools", []):
                tool["name"] = f"travel.{tool['name']}"
                merged["tools"].append(tool)

            for tool in _dump(w_tools).get("tools", []):
                tool["name"] = f"weather.{tool['name']}"
                merged["tools"].append(tool)

            # IMPORTANT: calendar is resources-only in this variant
            return _rpc_ok(rpc_id, merged)

        # ---------- tools/call ----------
        if method == "tools/call":
            name = params.get("name")
            arguments = params.get("arguments") or {}
            if not isinstance(name, str) or not name:
                raise RpcError(code=-32602, message="Invalid params: name must be a non-empty string")
            if not isinstance(arguments, dict):
                raise RpcError(code=-32602, message="Invalid params: arguments must be an object")

            if "." not in name:
                raise RpcError(code=-32602, message="Tool name must be namespaced: <domain>.<tool>")

            domain, tool_name = name.split(".", 1)
            client = {"travel": travel, "weather": weather}.get(domain)
            if client is None:
                raise RpcError(code=-32602, message=f"Unknown domain for tool: {domain}")

            log_domain(domain, "tool_call.begin", tool=name)
            call_result = await client.call_tool(tool_name, arguments=arguments)
            norm = normalize_call_result(call_result)
            log_domain(domain, "tool_call.end", tool=name)

            result: Dict[str, Any] = {"content": norm.content}
            if norm.structured is not None:
                result["structured"] = norm.structured
            return _rpc_ok(rpc_id, result)

        # ---------- resources/list ----------
        if method == "resources/list":
            resources = await calendar.list_resources()
            dumped = resources.model_dump() if hasattr(resources, "model_dump") else resources
            return _rpc_ok(rpc_id, dumped)

        # ---------- resources/read ----------
        if method == "resources/read":
            uri = params.get("uri")
            if not isinstance(uri, str) or not uri:
                raise RpcError(code=-32602, message="Invalid params: uri must be a non-empty string")

            log_domain("calendar", "resource_read.begin", uri=uri)
            read_result = await calendar.read_resource(uri)
            norm = normalize_resource_read(read_result)
            log_domain("calendar", "resource_read.end", uri=uri)

            return _rpc_ok(rpc_id, norm)

        raise RpcError(code=-32601, message=f"Method not found: {method}")

    except RpcError as e:
        return _rpc_err(req.get("id", 0), e)
    except Exception as e:
        return JSONResponse(
            {
                "jsonrpc": "2.0",
                "id": req.get("id", 0),
                "error": {"code": -32000, "message": "Internal error", "data": str(e)},
            }
        )
