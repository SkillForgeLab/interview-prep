from __future__ import annotations

import sqlite3
from pathlib import Path

from shared.env import get_db_path


def main() -> None:
    db_path: Path = get_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)

    con = sqlite3.connect(db_path)
    cur = con.cursor()

    # Travel
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS flights (
          tenant_id TEXT NOT NULL,
          origin TEXT NOT NULL,
          destination TEXT NOT NULL,
          date TEXT NOT NULL,
          flight_number TEXT NOT NULL,
          depart_time TEXT NOT NULL,
          arrive_time TEXT NOT NULL,
          price_usd INTEGER NOT NULL
        );
        """
    )

    # Weather
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS weather_forecasts (
          tenant_id TEXT NOT NULL,
          location TEXT NOT NULL,
          date TEXT NOT NULL,
          summary TEXT NOT NULL,
          high_f INTEGER NOT NULL,
          low_f INTEGER NOT NULL,
          precip_pct INTEGER NOT NULL
        );
        """
    )

    # Calendar raw events (optional but kept)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS calendar_events (
          tenant_id TEXT NOT NULL,
          start_ts TEXT NOT NULL,
          end_ts TEXT NOT NULL,
          title TEXT NOT NULL
        );
        """
    )

    # Calendar derived windows (THIS is what the resource reads)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS calendar_windows (
          tenant_id TEXT NOT NULL,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          nights INTEGER NOT NULL
        );
        """
    )

    # Reset
    cur.execute("DELETE FROM flights;")
    cur.execute("DELETE FROM weather_forecasts;")
    cur.execute("DELETE FROM calendar_events;")
    cur.execute("DELETE FROM calendar_windows;")

    # Seed: Travel flights
    flights = [
        ("t1", "PHX", "JFK", "2026-02-10", "UA450", "13:10", "21:40", 295),
        ("t1", "PHX", "JFK", "2026-02-10", "AA100", "08:00", "16:20", 320),
        ("t1", "PHX", "JFK", "2026-02-10", "DL220", "10:30", "18:55", 340),
        ("t1", "PHX", "JFK", "2026-02-11", "AA101", "08:00", "16:20", 310),
        ("t1", "PHX", "JFK", "2026-02-12", "UA451", "13:10", "21:40", 305),
    ]
    cur.executemany(
        """
        INSERT INTO flights
          (tenant_id, origin, destination, date, flight_number, depart_time, arrive_time, price_usd)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        flights,
    )

    # Seed: Weather forecasts
    forecasts = [
        ("t1", "JFK", "2026-02-10", "clear", 48, 32, 5),
        ("t1", "JFK", "2026-02-11", "rain", 41, 30, 70),
        ("t1", "JFK", "2026-02-12", "cloudy", 45, 31, 20),
        ("t1", "JFK", "2026-02-13", "clear", 50, 33, 5),
        ("t1", "JFK", "2026-02-14", "snow", 34, 22, 60),
    ]
    cur.executemany(
        """
        INSERT INTO weather_forecasts
          (tenant_id, location, date, summary, high_f, low_f, precip_pct)
        VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
        forecasts,
    )

    # Seed: Calendar events (kept for realism)
    events = [
        ("t1", "2026-02-10T09:00:00", "2026-02-10T12:00:00", "Project Meeting"),
        ("t1", "2026-02-11T13:00:00", "2026-02-11T17:00:00", "Client Review"),
        ("t1", "2026-02-15T08:00:00", "2026-02-16T18:00:00", "Conference"),
    ]
    cur.executemany(
        """
        INSERT INTO calendar_events
          (tenant_id, start_ts, end_ts, title)
        VALUES (?, ?, ?, ?);
        """,
        events,
    )

    # Seed: Calendar availability windows (what your resource returns)
    # These match the “known good” outputs you were seeing earlier.
    windows = [
        ("t1", "2026-02-12", "2026-02-15", 3),
        ("t1", "2026-02-16", "2026-02-20", 5),
    ]
    cur.executemany(
        """
        INSERT INTO calendar_windows
          (tenant_id, start_date, end_date, nights)
        VALUES (?, ?, ?, ?);
        """,
        windows,
    )

    con.commit()
    con.close()
    print(f"Initialized sqlite DB at: {db_path}")


if __name__ == "__main__":
    main()
