from __future__ import annotations

import os
import sys
from pathlib import Path

import asyncio
import httpx
import pytest

from orchestrator.fake_planner import FakePlannerAdapter
from orchestrator.react_loop import ReactOrchestrator
from travel_planner_stage2.tests.integration._helpers import (_free_port,
                                                              run_uvicorn_in_thread,
                                                              set_domain_server_env_to_python)


async def wait_for_gateway_ready(base_url: str, timeout_s: float = 6.0) -> None:
    import asyncio
    import httpx

    health_url = base_url.replace("/mcp", "/health")
    deadline = asyncio.get_event_loop().time() + timeout_s
    last_exc: Exception | None = None

    async with httpx.AsyncClient(timeout=1.0) as client:
        while asyncio.get_event_loop().time() < deadline:
            try:
                r = await client.get(health_url)
                if r.status_code == 200:
                    return
            except Exception as exc:
                last_exc = exc
            await asyncio.sleep(0.05)

    raise RuntimeError(f"Gateway not ready within {timeout_s}s. last_exc={last_exc!r}")


@pytest.mark.asyncio
async def test_e2e_happy_path(tmp_path: Path, monkeypatch):
    # DB setup
    db = tmp_path / "app.db"
    monkeypatch.setenv("APP_DB_PATH", str(db))

    # seed DB using project script logic (directly import + run)
    from travel_planner_stage2.scripts.setup_db import main as setup_db_main
    setup_db_main()

    # Make gateway use current python for stdio servers
    set_domain_server_env_to_python(monkeypatch, python_exe=sys.executable)

    # Start gateway on real HTTP port
    port = _free_port()
    monkeypatch.setenv("GATEWAY_URL", f"http://127.0.0.1:{port}/mcp")

    t, server = run_uvicorn_in_thread("gateway.main:app", port=port)
    await wait_for_gateway_ready(f"http://127.0.0.1:{port}/mcp")

    planner = FakePlannerAdapter()
    orch = ReactOrchestrator(planner=planner)

    result = await orch.run(user_request="Plan trip", max_steps=6)

    assert "Found flights" in result.final_message
    assert result.steps <= 6
    assert result.last_observation is not None
    assert isinstance(result.last_observation, dict)
    assert "options" in result.last_observation

    # shutdown
    server.should_exit = True
