from __future__ import annotations

import asyncio
import socket
import threading
import time

import httpx
import uvicorn


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def run_uvicorn_in_thread(app_path: str, port: int) -> tuple[threading.Thread, uvicorn.Server]:
    """
    Runs uvicorn in a background thread (real HTTP).
    app_path like: "gateway.main:app"
    """
    config = uvicorn.Config(app_path, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config=config)

    t = threading.Thread(target=server.run, daemon=True)
    t.start()

    # Give uvicorn a moment to import the app.
    time.sleep(0.1)

    # If the thread died immediately, uvicorn likely crashed on import.
    if not t.is_alive():
        raise RuntimeError("uvicorn thread exited immediately. App import likely failed.")

    return t, server


async def wait_for_gateway_ready(url: str, timeout_s: float = 5.0) -> None:
    deadline = asyncio.get_event_loop().time() + timeout_s
    async with httpx.AsyncClient(timeout=1.0) as client:
        while True:
            try:
                r = await client.post(
                    url,
                    json={"jsonrpc": "2.0", "id": "ready-1", "method": "tools/list", "params": {}},
                )
                if r.status_code == 200:
                    return
            except Exception:
                pass

            if asyncio.get_event_loop().time() >= deadline:
                raise RuntimeError(f"Gateway not ready at {url} within {timeout_s}s")
            await asyncio.sleep(0.05)


def set_domain_server_env_to_python(monkeypatch, *, python_exe: str) -> None:
    """
    Make gateway launch servers using current interpreter, not uv.
    This stabilizes tests.
    """
    monkeypatch.setenv("TRAVEL_SERVER_COMMAND", python_exe)
    monkeypatch.setenv("TRAVEL_SERVER_ARGS", "-m,domains.travel.server")

    monkeypatch.setenv("WEATHER_SERVER_COMMAND", python_exe)
    monkeypatch.setenv("WEATHER_SERVER_ARGS", "-m,domains.weather.server")

    monkeypatch.setenv("CALENDAR_SERVER_COMMAND", python_exe)
    monkeypatch.setenv("CALENDAR_SERVER_ARGS", "-m,domains.calendar.server")
