from __future__ import annotations

import sys
from pathlib import Path

import pytest

from orchestrator.fake_planner import FakePlannerAdapter
from orchestrator.react_loop import ReactOrchestrator
from travel_planner_stage2.tests.integration._helpers import _free_port, \
    run_uvicorn_in_thread, set_domain_server_env_to_python


@pytest.mark.asyncio
async def test_failure_calendar_down(tmp_path: Path, monkeypatch):
    # DB setup
    db = tmp_path / "app.db"
    monkeypatch.setenv("APP_DB_PATH", str(db))

    from travel_planner_stage2.scripts.setup_db import main as setup_db_main
    setup_db_main()

    # Use python for all servers, but break calendar command intentionally
    set_domain_server_env_to_python(monkeypatch, python_exe=sys.executable)
    monkeypatch.setenv("CALENDAR_SERVER_COMMAND",
                       "definitely-not-a-real-command")

    port = _free_port()
    monkeypatch.setenv("GATEWAY_URL", f"http://127.0.0.1:{port}/mcp")

    t, server = run_uvicorn_in_thread("gateway.main:app", port=port)

    planner = FakePlannerAdapter()
    orch = ReactOrchestrator(planner=planner)

    result = await orch.run(user_request="Plan trip", max_steps=2)

    assert "Resource read failed" in result.final_message
    assert result.last_observation is not None  # should be JSON-RPC error payload

    server.should_exit = True
