import pytest

from orchestrator.fake_planner import FakePlannerAdapter


@pytest.mark.asyncio
async def test_fake_planner_sequence():
    planner = FakePlannerAdapter()

    d1 = await planner.decide_next_action(user_request="x", observation=None)
    assert d1["action"] == "read_resource"
    #assert d1["action"] == "call_tool"
    #assert d1["name"] == "calendar.read_calendar_resource"

    d2 = await planner.decide_next_action(user_request="x", observation={"windows": [{"start_date": "2026-02-10", "end_date": "2026-02-12"}]})
    assert d2["action"] == "call_tool"
    assert d2["name"] == "weather.get_forecast"

    d3 = await planner.decide_next_action(user_request="x", observation={"days": [{"date": "2026-02-10", "precip_pct": 5}]})
    assert d3["action"] == "call_tool"
    assert d3["name"] == "travel.search_flights"

    d4 = await planner.decide_next_action(user_request="x", observation={"options": [{"flight_number": "UA450"}]})
    assert d4["action"] == "finish"
