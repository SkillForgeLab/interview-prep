from domains.calendar.server import availability

#
# def test_parse_calendar_uri():
#     path, params = availability(
#         "calendar://availability?tenant_id=t1&start=2026-02-10&end=2026-02-20&min_nights=3"
#     )
#     assert path == "availability"
#     assert params["tenant_id"] == "t1"
#     assert params["min_nights"] == "3"
