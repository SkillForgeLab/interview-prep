import sqlite3
from pathlib import Path

from domains.weather.sqlite_repo import SqliteWeatherRepository


def test_weather_tenant_isolation(tmp_path: Path, monkeypatch):
    db = tmp_path / "app.db"
    monkeypatch.setenv("APP_DB_PATH", str(db))

    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.execute(
        """
        CREATE TABLE weather_forecasts (
          tenant_id TEXT NOT NULL,
          location TEXT NOT NULL,
          date TEXT NOT NULL,
          summary TEXT NOT NULL,
          high_f INTEGER NOT NULL,
          low_f INTEGER NOT NULL,
          precip_pct INTEGER NOT NULL
        );
        """
    )
    cur.execute(
        "INSERT INTO weather_forecasts VALUES (?,?,?,?,?,?,?)",
        ("t1", "JFK", "2026-02-10", "clear", 48, 32, 5),
    )
    con.commit()
    con.close()

    repo = SqliteWeatherRepository()
    got_t1 = repo.get_forecast(tenant_id="t1", location="JFK", start_date="2026-02-10", end_date="2026-02-10")
    got_t2 = repo.get_forecast(tenant_id="t2", location="JFK", start_date="2026-02-10", end_date="2026-02-10")

    assert len(got_t1) == 1
    assert len(got_t2) == 0
