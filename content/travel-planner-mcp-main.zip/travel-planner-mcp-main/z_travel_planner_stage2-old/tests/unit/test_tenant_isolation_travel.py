import os
import sqlite3
from pathlib import Path

from domains.travel.sqlite_repo import SqliteFlightSearchRepository


def test_travel_tenant_isolation(tmp_path: Path, monkeypatch):
    db = tmp_path / "app.db"
    monkeypatch.setenv("APP_DB_PATH", str(db))

    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.execute(
        """
        CREATE TABLE flights (
          tenant_id TEXT NOT NULL,
          origin TEXT NOT NULL,
          destination TEXT NOT NULL,
          date TEXT NOT NULL,
          flight_number TEXT NOT NULL,
          depart_time TEXT NOT NULL,
          arrive_time TEXT NOT NULL,
          price_usd INTEGER NOT NULL
        );
        """
    )
    cur.execute(
        "INSERT INTO flights VALUES (?,?,?,?,?,?,?,?)",
        ("t1", "PHX", "JFK", "2026-02-10", "UA450", "13:10", "21:40", 295),
    )
    con.commit()
    con.close()

    repo = SqliteFlightSearchRepository()

    got_t1 = repo.search_flights(tenant_id="t1", origin="PHX", destination="JFK", date="2026-02-10")
    got_t2 = repo.search_flights(tenant_id="t2", origin="PHX", destination="JFK", date="2026-02-10")

    assert len(got_t1) == 1
    assert len(got_t2) == 0
