# Travel Planner (Stage 2) — Multi-server planning (read-only)

---

## Goal of This Stage (Read First)

This stage proves that 

By completing this stage, you verify that:


## System Components (Mental Model)
```
[ Orchestrator ]
      |
      | HTTP JSON-RPC
      v
[ Gateway ]
      |
      | MCP (stdio)
      v
[ Travel MCP Server ]
      |
      v
[ sqlite DB ]
```

## What you get
- 3 **MCP servers** `(stdio)`
    - Travel (tools): `search_flights`
    - Weather (tools): `get_forecast`
    - Calendar (resources): `calendar://availability?...` and `calendar://events?...`
- **Gateway** exposing `MCP-style JSON-RPC` over `HTTP`:
    - `tools/list`
    - `tools/call`
    - `resources/list`
    - `resources/read`
- **Orchestrator** with explicit `ReAct` loop:
    - **Planner** decides next step and explains why (routing decisions)
    - `Act` uses Gateway only
    - Observe stores normalized structured evidence 
    - Uses `FakeReasoningAdapter`
  - Deterministic and testable
- **Persistence**
  - sqlite
  - Tenant-isolated queries
- **Tests**
  - Unit test: tenant isolation
  - Integration test: HTTP → Gateway → MCP → DB

---

## macOS (Intel) — Run Instructions

### 0) Prerequisites
- macOS (Intel)
- uv installed
- Python 3.11+

## Environment Configuration
### File: `.env.example`
```env
# Orchestrator -> Gateway
GATEWAY_URL=http://127.0.0.1:8080/mcp
HTTP_TIMEOUT_SECONDS=10

# Travel server stdio launch params used by Gateway
TRAVEL_SERVER_COMMAND=uv
TRAVEL_SERVER_ARGS=run,python,-m,domains.travel.server

WEATHER_SERVER_COMMAND=uv
WEATHER_SERVER_ARGS=run,python,-m,domains.weather.server

CALENDAR_SERVER_COMMAND=uv
CALENDAR_SERVER_ARGS=run,python,-m,domains.calendar.server

# sqlite
APP_DB_PATH=./data/app.db

# OpenAI (optional for live model; tests do not require this)
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
```
### Important
- Stage 1 uses FakeReasoningAdapter 
- No OpenAI key is required

## Setup (Follow in Order)

### 1. Verify CPU architecture
```bash
uname -m
```
#### Expected 
- x86_64


### 2. Verify `uv`
```bash
which uv
uv --version
```

#### If missing, run 
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
#### Restart terminal after install.



### 3. Create virtual environment

#### a. Clone / enter project directory
```bash
cd z_travel_planner_stage2-old
```
#### Directory must contain:
- pyproject.toml
- src/
- scripts/
- tests/

#### b. Install `.venv`
```bash
rm -rf .venv
uv venv
```

#### c. Activate `.venv`
```bash
source .venv/bin/activate
```

#### d. Verify Python
```bash
which python
uv run python --version
```
#### Expected
- .../travel_planner_stage1/.venv/bin/python
- Python 3.11.14


### 4. Install dependencies
```bash
uv pip install -e ".[dev]"
```
#### Expected
- No errors
- mcp, fastapi, uvicorn, httpx installed


### 5. Initialize Database
```bash
uv run python scripts/setup_db.py
```
#### Expected
- Initialized sqlite DB at: data/app.db

### Verify database exists
```bash
ls data/app.db
```
#### Expected
- data/app.db


### 6. Configure environment variables
```bash
cp .env.example .env
```
#### You do not need to edit .env for Stage 1.
#### Important defaults:
- Uses FakeReasoningAdapter (no OpenAI key needed)
- Uses local sqlite
- Uses stdio MCP transport


## Start domain servers (stdio)
### Terminal 1 — Start Calendar MCP server
```bash
uv run python -m domains.calendar.server
```
### Terminal 2 — Start Weather MCP server
```bash
uv run python -m domains.weather.server
```
### Terminal 3 — Start Travel MCP server
```bash
uv run python -m domains.travel.server
```
#### Expected behavior:
- No stdout output
- Process stays running
- Logs (if any) go to stderr
#### ***🚨 If you see JSON printed to stdout → BUG (stdio protocol broken)***

## Start domain servers (stdio)

### Terminal 4 — Start Gateway
```bash
uv run python -m uvicorn gateway.main:app \
  --host 127.0.0.1 \
  --port 8080
```
#### Expected:
- Uvicorn running on http://127.0.0.1:8080


 
### Verify Gateway endpoints (quick smoke tests)

#### a. List tools:
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' \
  | python -m json.tool
```
#### Expected output:
- HTTP 200
- JSON with at least one tool:
- -  search_flights

#### b. Read calendar availability resource:
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":2,"method":"resources/read","params":{"uri":"calendar://availability?tenant_id=t1&start=2026-02-10&end=2026-02-20&min_nights=3"}}' \
| python -m json.tool
```

### Terminal 5 — Run Orchestrator demo (ReAct loop)
```bash
uv run python -m orchestrator.demo
```
#### Expected logs (shape, not exact values):
```
- HTTP 200
- orchestrator.react.reason (planner chooses next step)
- orchestrator.react.act (gateway call)
- orchestrator.react.observe (normalized evidence)
- repeats for calendar → weather → travel
- orchestrator.react.finish
```
#### This confirms
```
- Reason → Act → Observe loop executed
- Tool was called via Gateway
- Domain server executed
- Final decision was made
```


## Tests (Required for Definition of Done)
```bash
uv run pytest -q
```
#### Expected:
- ... passed
#### Tests include:
- Unit test: tenant isolation
- Integration test: real HTTP → Gateway → MCP → sqlite


## Clean shutdown
 In all terminals:
```bash
Ctrl+C
```
#### Order does not matter.

## JSON-RPC examples
### List tools: 
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"tools/list",
    "params":{}
    }
  }'
'
```

### Call tool 
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":2,
    "method":"tools/call",
    "params":{
      "name":"search_flights",
      "arguments":{
        "tenant_id":"t1",
        "origin":"PHX",
        "destination":"JFK",
        "date":"2026-02-10"
      }
    }
  }'
'
```


## Troubleshooting: Common failure symptoms & fixes
 
### ❌ Gateway returns JSON-RPC error
- Ensure all 3 domain servers are running (3 terminals).
- Confirm .env has correct server command/args.


### ❌ Orchestrator observation is text-only JSON
- Stage 2 includes observation normalization logic.
- The orchestrator will parse JSON text into structured dict when possible.

## Stage 2 exit checklist

 - I can explain why the planner called Calendar before Weather.
 - I can point to one log line that explains each next step. 
 - I can show one “resource URI → decision impact” mapping. 
 - I can run everything using ONLY this README on macOS Intel.