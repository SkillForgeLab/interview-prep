#!/usr/bin/env bash
set -euo pipefail
uv run python -m uvicorn gateway.main:app --host 127.0.0.1 --port 8080
