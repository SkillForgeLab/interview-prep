import os
import sqlite3
from pathlib import Path

DB_PATH = os.environ.get("TRAVEL_DB_PATH", "./data/travel.db")


def main() -> None:
    db_path = Path(DB_PATH)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    con = sqlite3.connect(db_path)
    cur = con.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS flights (
          tenant_id TEXT NOT NULL,
          origin TEXT NOT NULL,
          destination TEXT NOT NULL,
          date TEXT NOT NULL,
          flight_number TEXT NOT NULL,
          depart_time TEXT NOT NULL,
          arrive_time TEXT NOT NULL,
          price_usd INTEGER NOT NULL
        );
        """
    )

    cur.execute("DELETE FROM flights;")

    rows = [
        ("t1", "PHX", "JFK", "2026-02-10", "AA100", "08:00", "16:20", 320),
        ("t1", "PHX", "JFK", "2026-02-10", "DL220", "10:30", "18:55", 340),
        ("t1", "PHX", "JFK", "2026-02-10", "UA450", "13:10", "21:40", 295),
        ("t1", "PHX", "SFO", "2026-02-10", "WN777", "09:00", "11:10", 180),
        ("t2", "PHX", "JFK", "2026-02-10", "ZZ999", "06:00", "14:30", 999),
    ]

    cur.executemany(
        """
        INSERT INTO flights
          (tenant_id, origin, destination, date, flight_number, depart_time, arrive_time, price_usd)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        rows,
    )

    con.commit()
    con.close()
    print(f"Initialized sqlite DB at: {db_path}")


if __name__ == "__main__":
    main()
