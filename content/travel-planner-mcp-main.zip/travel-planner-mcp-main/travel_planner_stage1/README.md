# Travel Planner — Stage 1  
## Minimal ReAct Loop (Single MCP Server, Read-Only)

---

## Goal of This Stage (Read First)

This stage proves that a **correct, observable ReAct loop** can run end-to-end using **MCP over HTTP**, without relying on a real LLM.

By completing this stage, you verify that:

- MCP tools can be exposed over **HTTP JSON-RPC**
- A **Gateway** can proxy HTTP → MCP (stdio) correctly
- An **Orchestrator** can run an explicit:
  - **Reason → Act → Observe** loop
- Tool calls flow end-to-end:
  - Orchestrator → Gateway → MCP Server → sqlite → response
- Tenant isolation is enforced at the data layer
- The system works **without OpenAI or external dependencies**

If any of these fail, **Stage 1 is not complete**.

## System Components (Mental Model)
```
[ Orchestrator ]
      |
      | HTTP JSON-RPC
      v
[ Gateway ]
      |
      | MCP (stdio)
      v
[ Travel MCP Server ]
      |
      v
[ sqlite DB ]
```

## What you get
- **Travel MCP Server**
  - One read-only tool: `search_flights`
  - MCP stdio transport
- **Gateway**
  - HTTP façade over MCP
  - Supports:
    - `tools/list`
    - `tools/call`
- **Orchestrator Demo**
  - Explicit ReAct loop
  - Uses `FakeReasoningAdapter`
  - Deterministic and testable
- **Persistence**
  - sqlite
  - Tenant-isolated queries
- **Tests**
  - Unit test: tenant isolation
  - Integration test: HTTP → Gateway → MCP → DB

## Requirements
- macOS (Intel)
- uv installed
- Python 3.11+

## Environment Configuration
### File: `.env.example`
```env
# Orchestrator -> Gateway
GATEWAY_URL=http://127.0.0.1:8080/mcp
HTTP_TIMEOUT_SECONDS=10

# Travel server stdio launch params used by Gateway
TRAVEL_SERVER_COMMAND=uv
TRAVEL_SERVER_ARGS=run,python,-m,domains.travel.server

# sqlite
TRAVEL_DB_PATH=./data/travel.db

# OpenAI (optional for live model; tests do not require this)
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
```
### Important
- Stage 1 uses FakeReasoningAdapter 
- No OpenAI key is required

## Setup (Follow in Order)

### 1. Verify CPU architecture
```bash
uname -m
```
#### Expected 
- x86_64


### 2. Verify `uv`
```bash
which uv
uv --version
```

#### If missing, run 
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
#### Restart terminal after install.



### 3. Create virtual environment

#### a. Clone / enter project directory
```bash
cd travel_planner_stage1
```
#### Directory must contain:
- pyproject.toml
- src/
- scripts/
- tests/

#### b. Install `.venv`
```bash
rm -rf .venv
uv venv
```

#### c. Activate `.venv`
```bash
source .venv/bin/activate
```

#### d. Verify Python
```bash
which python
uv run python --version
```
#### Expected
- .../travel_planner_stage1/.venv/bin/python
- Python 3.11.14


### 4. Install dependencies
```bash
uv pip install -e ".[dev]"
```
#### Expected
- No errors
- mcp, fastapi, uvicorn, httpx installed


### 5. Initialize Database
```bash
uv run python scripts/setup_db.py
```
#### Expected
- Initialized sqlite DB at: data/travel.db

### Verify database exists
```bash
ls data/travel.db
```
#### Expected
- data/travel.db


### 6. Configure environment variables
```bash
cp .env.example .env
```
#### You do not need to edit .env for Stage 1.
#### Important defaults:
- Uses FakeReasoningAdapter (no OpenAI key needed)
- Uses local sqlite
- Uses stdio MCP transport


## Run the System
### Terminal 1 — Start Travel MCP server (Domain)
```bash
uv run python -m domains.travel.server
```
#### Expected behavior:
- No stdout output
- Process stays running
- Logs (if any) go to stderr
#### ***🚨 If you see JSON printed to stdout → BUG (stdio protocol broken)***

### Terminal 2 — Start Gateway
```bash
uv run python -m uvicorn gateway.main:app \
  --host 127.0.0.1 \
  --port 8080
```
#### Expected:
- Uvicorn running on http://127.0.0.1:8080


 
### Verify Gateway
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'
```
#### Expected output:
- HTTP 200
- JSON with at least one tool:
- -  search_flights


### Terminal 3 — Run Orchestrator demo (ReAct loop)
```bash
uv run python -m orchestrator.demo
```
#### Expected logs (shape, not exact values):
```
- HTTP 200
- {"event":"orchestrator.demo.adapter","adapter":"FakeReasoningAdapter"}
- {"event":"orchestrator.react.reason","step":1,"phase":"REASON"}
- {"event":"orchestrator.react.act","step":1,"phase":"ACT","tool_name":"search_flights"}
- {"event":"orchestrator.react.observe","step":1,"phase":"OBSERVE"}
- {"event":"orchestrator.react.finish","step":2}
```
#### This confirms
```
- Reason → Act → Observe loop executed
- Tool was called via Gateway
- Domain server executed
- Final decision was made
```


## Tests (Required for Definition of Done)
```bash
uv run pytest -q
```
#### Expected:
- 2 passed
#### Tests include:
- Unit test: tenant isolation
- Integration test: real HTTP → Gateway → MCP → sqlite


## Clean shutdown
 In all terminals:
```bash
Ctrl+C
```
#### Order does not matter.

## JSON-RPC examples
### List tools: 
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"tools/list",
    "params":{}
    }
  }'
'
```

### Call tool 
```bash
curl -s http://127.0.0.1:8080/mcp \
  -H 'content-type: application/json' \
  -d '{
    "jsonrpc":"2.0",
    "id":2,
    "method":"tools/call",
    "params":{
      "name":"search_flights",
      "arguments":{
        "tenant_id":"t1",
        "origin":"PHX",
        "destination":"JFK",
        "date":"2026-02-10"
      }
    }
  }'
'
```


## Common failure symptoms & fixes
 
### ❌ Gateway returns Internal error
- **Cause**
  - Travel MCP server not running
  - Wrong TRAVEL_SERVER_COMMAND
- **Fix:**
```bash
ps aux | grep domains.travel.server
```
##### Restart Terminal 1.


### ❌ Orchestrator hangs
- **Cause**
  - Gateway not reachable
  - Wrong port
- **Fix:**
```bash
curl http://127.0.0.1:8080/mcp
```

### ❌ No flights returned
- **Cause**
  - Wrong tenant_id
  - DB not initialized
- **Fix:**
```bash
uv run python scripts/setup_db.py
```