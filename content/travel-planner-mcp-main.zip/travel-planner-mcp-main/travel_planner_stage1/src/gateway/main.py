from __future__ import annotations

from typing import Any

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from mcp import types
import json

from gateway.mcp_travel_client import build_travel_client
from shared.jsonrpc import JsonRpcRequest, RpcError
from shared.logging_json import log

app = FastAPI(title="MCP Gateway (Stage 1)", version="0.1.0")


@app.post("/mcp")
async def mcp_endpoint(req: JsonRpcRequest) -> JSONResponse:
    """
    Minimal JSON-RPC endpoint.
    Methods:
      - tools/list
      - tools/call
    """
    try:
        if req.get("jsonrpc") != "2.0":
            raise RpcError(code=-32600, message="Invalid Request: jsonrpc must be '2.0'")

        rpc_id = req.get("id")
        method = req.get("method")
        params = req.get("params", {}) or {}

        log("gateway.rpc.request", id=rpc_id, method=method)

        client = build_travel_client()

        if method == "tools/list":
            tools = await client.list_tools()
            # tools is an MCP SDK object; return as dict-like structure.
            result = tools.model_dump() if hasattr(tools, "model_dump") else tools
            return JSONResponse({"jsonrpc": "2.0", "id": rpc_id, "result": result})

        if method == "tools/call":
            name = params.get("name")
            arguments = params.get("arguments") or {}
            if not isinstance(name, str) or not name:
                raise RpcError(code=-32602, message="Invalid params: name must be a non-empty string")
            if not isinstance(arguments, dict):
                raise RpcError(code=-32602, message="Invalid params: arguments must be an object")

            call_result = await client.call_tool(name=name, arguments=arguments)

            # Normalize MCP CallToolResult for JSON response.
            structured = getattr(call_result, "structuredContent", None)
            content = []
            for c in getattr(call_result, "content", []) or []:
                if isinstance(c, types.TextContent):
                    content.append({"type": "text", "text": c.text})
                else:
                    # Best-effort fallback
                    content.append({"type": "unknown", "value": getattr(c, "model_dump", lambda: str(c))()})

            structured = getattr(call_result, "structuredContent", None)

            # If structured is missing, attempt to parse the first text content as JSON.
            if structured is None and content:
                first = content[0]
                if first.get("type") == "text":
                    txt = first.get("text", "")
                    if isinstance(txt, str):
                        s = txt.lstrip()
                        if s.startswith("{") or s.startswith("["):
                            try:
                                structured = json.loads(txt)
                            except json.JSONDecodeError:
                                structured = None

            result: dict[str, Any] = {"content": content}
            if structured is not None:
                result["structured"] = structured

            return JSONResponse({"jsonrpc": "2.0", "id": rpc_id, "result": result})

        raise RpcError(code=-32601, message=f"Method not found: {method}")

    except RpcError as e:
        return JSONResponse({"jsonrpc": "2.0", "id": req.get("id", 0), "error": e.to_jsonrpc_error()})
    except Exception as e:
        # Minimal error mapping for Stage 1.
        return JSONResponse(
            {
                "jsonrpc": "2.0",
                "id": req.get("id", 0),
                "error": {"code": -32000, "message": "Internal error", "data": str(e)},
            }
        )
