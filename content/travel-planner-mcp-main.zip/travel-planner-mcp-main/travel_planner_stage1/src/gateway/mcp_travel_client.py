from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
from shared.logging_json import log


@dataclass
class TravelMcpClient:
    command: str
    args: list[str]
    env: dict[str, str]

    async def list_tools(self) -> Any:
        async with stdio_client(StdioServerParameters(command=self.command, args=self.args, env=self.env)) as (
            read,
            write,
        ):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                return tools

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        async with stdio_client(StdioServerParameters(command=self.command, args=self.args, env=self.env)) as (
            read,
            write,
        ):
            async with ClientSession(read, write) as session:
                await session.initialize()
                log("gateway.mcp.call_tool.begin", tool=name)
                result = await session.call_tool(name, arguments=arguments)
                log("gateway.mcp.call_tool.end", tool=name)
                return result


def build_travel_client() -> TravelMcpClient:
    cmd = os.environ.get("TRAVEL_SERVER_COMMAND", "uv")
    args_csv = os.environ.get("TRAVEL_SERVER_ARGS", "run,python,-m,domains.travel.server")
    args = [a.strip() for a in args_csv.split(",") if a.strip()]

    # Pass through env needed by the server.
    env = dict(os.environ)
    return TravelMcpClient(command=cmd, args=args, env=env)
