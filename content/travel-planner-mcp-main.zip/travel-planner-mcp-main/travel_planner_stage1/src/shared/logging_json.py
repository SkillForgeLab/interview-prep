import json
import logging
import sys
from typing import Any

# For STDIO MCP servers: never log to stdout. Use stderr.
logging.basicConfig(level=logging.INFO,
                    stream=sys.stderr,
                    format="%(message)s")


def log(event: str, **fields: Any) -> None:
    payload = {"event": event, **fields}
    logging.info(json.dumps(payload, ensure_ascii=False))
