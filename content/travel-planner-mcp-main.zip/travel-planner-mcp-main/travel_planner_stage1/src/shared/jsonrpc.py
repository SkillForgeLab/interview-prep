from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Optional, TypedDict

JsonRpcVersion = Literal["2.0"]


class JsonRpcError(TypedDict, total=False):
    code: int
    message: str
    data: Any


class JsonRpcRequest(TypedDict):
    jsonrpc: JsonRpcVersion
    id: int | str
    method: str
    params: dict[str, Any]


class JsonRpcResponse(TypedDict, total=False):
    jsonrpc: JsonRpcVersion
    id: int | str
    result: Any
    error: JsonRpcError


@dataclass(frozen=True)
class RpcError(Exception):
    code: int
    message: str
    data: Optional[Any] = None

    def to_jsonrpc_error(self) -> JsonRpcError:
        err: JsonRpcError = {"code": self.code, "message": self.message}
        if self.data is not None:
            err["data"] = self.data
        return err
