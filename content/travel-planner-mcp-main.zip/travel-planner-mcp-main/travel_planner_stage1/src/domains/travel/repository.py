from __future__ import annotations

from abc import ABC, abstractmethod

from shared.schemas import FlightOption


class FlightSearchRepository(ABC):
    @abstractmethod
    def search_flights(
            self, *, tenant_id: str, origin: str, destination: str, date: str
    ) -> list[FlightOption]:
        raise NotImplementedError
