# Stage 1 uses shared schemas for tool input/output.
# This file exists to keep domain-local schemas possible in later stages.
