from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

from domains.travel.sqlite_repo import SqliteFlightSearchRepository
from shared.logging_json import log
from shared.schemas import SearchFlightsInput, SearchFlightsOutput

mcp = FastMCP("travel-search")

DB_PATH = os.environ.get("TRAVEL_DB_PATH", "./data/travel.db")
repo = SqliteFlightSearchRepository(DB_PATH)


@mcp.tool()
def search_flights(tenant_id: str, origin: str, destination: str,
                   date: str) -> dict:
    """
    Search flights for a given origin, destination, and date.

    Read-only tool.
    Uses tenant_id for tenant isolation.
    """
    # Validate input using Pydantic schema.
    inp = SearchFlightsInput(
        tenant_id=tenant_id,
        origin=origin.upper(),
        destination=destination.upper(),
        date=date,
    )

    options = repo.search_flights(
        tenant_id=inp.tenant_id,
        origin=inp.origin,
        destination=inp.destination,
        date=inp.date,
    )

    out = SearchFlightsOutput(
        origin=inp.origin,
        destination=inp.destination,
        date=inp.date,
        options=options,
    )

    log(
        "travel.search_flights",
        tenant_id=inp.tenant_id,
        origin=inp.origin,
        destination=inp.destination,
        date=inp.date,
        options_count=len(options),
    )
    return out.model_dump()


def main() -> None:
    # Official docs show this pattern for running a stdio server.
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
