from __future__ import annotations

import sqlite3
from pathlib import Path

from shared.schemas import FlightOption
from domains.travel.repository import FlightSearchRepository


class SqliteFlightSearchRepository(FlightSearchRepository):
    def __init__(self, db_path: str) -> None:
        self._db_path = str(Path(db_path))

    def search_flights(
            self, *, tenant_id: str, origin: str, destination: str, date: str
    ) -> list[FlightOption]:
        con = sqlite3.connect(self._db_path)
        cur = con.cursor()

        # Tenant isolation is enforced in the query.
        cur.execute(
            """
            SELECT flight_number, depart_time, arrive_time, price_usd
            FROM flights
            WHERE tenant_id = ?
              AND origin = ?
              AND destination = ?
              AND date = ?
            ORDER BY price_usd ASC;
            """,
            (tenant_id, origin, destination, date),
        )

        rows = cur.fetchall()
        con.close()

        return [
            FlightOption(
                flight_number=r[0],
                depart_time=r[1],
                arrive_time=r[2],
                price_usd=int(r[3]),
            )
            for r in rows
        ]
