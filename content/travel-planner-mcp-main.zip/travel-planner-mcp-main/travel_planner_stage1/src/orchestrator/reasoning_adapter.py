from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, TypedDict


class NextAction(TypedDict):
    action: str  # "call_tool" | "finish"
    tool_name: str | None
    tool_args: dict[str, Any] | None
    final_message: str | None
    reason: str  # must be explicit; no hidden reasoning


class ReasoningAdapter(ABC):
    @abstractmethod
    async def decide_next_action(self, *,
                                 user_request: str,
                                 observation: dict[str, Any] | None) -> (
            NextAction):
        raise NotImplementedError
