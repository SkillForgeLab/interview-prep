from __future__ import annotations

import os
from typing import Any

import httpx
import json
from typing import Any, Dict, Optional

from orchestrator.reasoning_adapter import ReasoningAdapter
from shared.logging_json import log


def _normalize_tool_result(result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize gateway tool result into structured dict form.

    Supports:
    - {"structured": {...}}
    - {"content":[{"type":"text","text":"{...json...}"}]}
    """
    structured = result.get("structured")
    if isinstance(structured, dict):
        return structured

    content = result.get("content")
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict) and first.get("type") == "text":
            text = first.get("text")
            if isinstance(text, str):
                text_stripped = text.lstrip()
                if text_stripped.startswith("{") or text_stripped.startswith(
                        "["):
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, dict):
                            return parsed
                        return {"value": parsed}
                    except json.JSONDecodeError:
                        pass

    # Fallback: return the raw result so we don't lose information
    return result


class ReactOrchestrator:
    def __init__(self, *, adapter: ReasoningAdapter) -> None:
        self._adapter = adapter
        self._gateway_url = os.environ.get("GATEWAY_URL",
                                           "http://127.0.0.1:8080/mcp")
        self._timeout = float(os.environ.get("HTTP_TIMEOUT_SECONDS", "10"))

    async def run(self, *, user_request: str) -> dict[str, Any]:
        observation: dict[str, Any] | None = None
        step = 0

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            while True:
                step += 1
                log("orchestrator.react.reason", step=step, phase="REASON",
                    user_request=user_request, observation=observation)

                next_action = await self._adapter.decide_next_action(
                    user_request=user_request,
                    observation=observation,
                )

                log("orchestrator.react.reason.decision", step=step,
                    phase="REASON", decision=next_action)

                if next_action["action"] == "finish":
                    log("orchestrator.react.finish", step=step, phase="REASON",
                        final_message=next_action["final_message"])
                    return {
                        "final_message": next_action["final_message"],
                        "last_observation": observation,
                        "steps": step,
                    }

                if next_action["action"] != "call_tool":
                    raise RuntimeError(
                        f"Unsupported action: {next_action['action']}")

                tool_name = next_action["tool_name"]
                tool_args = next_action["tool_args"]
                if not tool_name or tool_args is None:
                    raise RuntimeError(
                        "call_tool requires tool_name and tool_args")

                log("orchestrator.react.act", step=step, phase="ACT",
                    tool_name=tool_name, tool_args=tool_args)

                rpc_req = {
                    "jsonrpc": "2.0",
                    "id": step,
                    "method": "tools/call",
                    "params": {"name": tool_name, "arguments": tool_args},
                }
                resp = await client.post(self._gateway_url, json=rpc_req)
                resp.raise_for_status()
                payload = resp.json()

                if "error" in payload:
                    log("orchestrator.react.observe.error", step=step,
                        phase="OBSERVE", error=payload["error"])
                    observation = {"error": payload["error"]}
                    # Stage 1: stop on tool failure.
                    return {
                        "final_message": "Tool call failed. See error in observation.",
                        "last_observation": observation,
                        "steps": step,
                    }

                raw_result = payload.get("result") or {}
                if not isinstance(raw_result, dict):
                    raw_result = {"value": raw_result}

                observation = _normalize_tool_result(raw_result)

                log("orchestrator.react.observe", step=step, phase="OBSERVE",
                    observation=observation)
