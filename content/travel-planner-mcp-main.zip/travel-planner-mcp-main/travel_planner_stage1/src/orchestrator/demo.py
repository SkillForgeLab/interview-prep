from __future__ import annotations

import asyncio
import os

from orchestrator.fake_reasoning import FakeReasoningAdapter
from orchestrator.openai_reasoning import OpenAIResponsesReasoningAdapter
from orchestrator.react_loop import ReactOrchestrator
from shared.logging_json import log


async def main() -> None:
    # Default to Fake adapter so it runs without OpenAI keys.
    use_openai = bool(os.environ.get("OPENAI_API_KEY"))

    adapter = OpenAIResponsesReasoningAdapter() if use_openai else FakeReasoningAdapter()
    log("orchestrator.demo.adapter", adapter=adapter.__class__.__name__)

    orch = ReactOrchestrator(adapter=adapter)

    user_request = "Find flights from PHX to JFK on 2026-02-10 for tenant t1."
    result = await orch.run(user_request=user_request)
    log("orchestrator.demo.result", result=result)


if __name__ == "__main__":
    asyncio.run(main())
