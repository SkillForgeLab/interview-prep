from __future__ import annotations

import os
from typing import Any, cast

from openai import OpenAI

from orchestrator.reasoning_adapter import NextAction, ReasoningAdapter


class OpenAIResponsesReasoningAdapter(ReasoningAdapter):
    """
    Uses OpenAI Responses API.
    Produces a strict JSON object that matches NextAction.
    """

    def __init__(self) -> None:
        self._client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self._model = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")

    async def decide_next_action(self, *, user_request: str, observation: dict[
                                                                              str, Any] | None) -> NextAction:
        # Note: OpenAI Python SDK is sync; keep Stage 1 simple and call sync.
        # Stage 2+ can add true async adapters if needed.
        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "action": {"type": "string", "enum": ["call_tool", "finish"]},
                "tool_name": {"type": ["string", "null"]},
                "tool_args": {"type": ["object", "null"]},
                "final_message": {"type": ["string", "null"]},
                "reason": {"type": "string"},
            },
            "required": ["action", "tool_name", "tool_args", "final_message",
                         "reason"],
        }

        prompt = {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": (
                        "You are the Planner for a travel assistant.\n"
                        "Return only JSON matching the schema.\n"
                        "ReAct rule: Reason must be explicit.\n"
                        f"User request: {user_request}\n"
                        f"Observation (null if none): {observation}\n"
                        "If observation is null, choose call_tool search_flights with needed args.\n"
                        "If observation contains options, choose finish.\n"
                    ),
                }
            ],
        }

        resp = self._client.responses.create(
            model=self._model,
            input=[prompt],
            response_format={
                "type": "json_schema",
                "json_schema": {"name": "NextAction", "schema": schema,
                                "strict": True},
            },
        )

        # The SDK returns structured JSON text in output; handle best-effort.
        text = resp.output_text
        import json

        data = json.loads(text)
        return cast(NextAction, data)
