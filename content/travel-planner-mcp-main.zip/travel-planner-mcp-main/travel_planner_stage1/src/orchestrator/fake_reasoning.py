from __future__ import annotations

from typing import Any

from orchestrator.reasoning_adapter import NextAction, ReasoningAdapter


class FakeReasoningAdapter(ReasoningAdapter):
    """
    Deterministic reasoning for tests and offline runs.
    It always performs exactly:
      1) call_tool(search_flights)
      2) finish
    """

    async def decide_next_action(self, *, user_request: str,
                                 observation: dict[str, Any] | None) -> NextAction:
        if observation is None:
            return NextAction(
                action="call_tool",
                tool_name="search_flights",
                tool_args={
                    "tenant_id": "t1",
                    "origin": "PHX",
                    "destination": "JFK",
                    "date": "2026-02-10",
                },
                final_message=None,
                reason="No observations yet. Need flight options. Call search_flights.",
            )

        return NextAction(
            action="finish",
            tool_name=None,
            tool_args=None,
            final_message="Found flight options. See results above.",
            reason="Observation contains flight options. No more tools needed.",
        )
