from __future__ import annotations

import os
import signal
import subprocess
import time
from pathlib import Path

import httpx
import pytest


@pytest.mark.asyncio
async def test_gateway_tools_list_and_call(tmp_path: Path) -> None:
    # Prepare DB
    env = dict(os.environ)
    db_path = tmp_path / "travel.db"
    env["TRAVEL_DB_PATH"] = str(db_path)

    # Create sqlite with one row
    import sqlite3

    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute(
        """
        CREATE TABLE flights (
          tenant_id TEXT NOT NULL,
          origin TEXT NOT NULL,
          destination TEXT NOT NULL,
          date TEXT NOT NULL,
          flight_number TEXT NOT NULL,
          depart_time TEXT NOT NULL,
          arrive_time TEXT NOT NULL,
          price_usd INTEGER NOT NULL
        );
        """
    )
    cur.execute(
        """
        INSERT INTO flights VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        ("t1", "PHX", "JFK", "2026-02-10", "AA100", "08:00", "16:20", 320),
    )
    con.commit()
    con.close()

    # Start gateway
    proc = subprocess.Popen(
        ["uv", "run", "python", "-m", "uvicorn", "gateway.main:app", "--host",
         "127.0.0.1", "--port", "18080"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    try:
        # Wait for server
        for _ in range(40):
            try:
                async with httpx.AsyncClient(timeout=1.0) as c:
                    r = await c.post(
                        "http://127.0.0.1:18080/mcp",
                        json={"jsonrpc": "2.0", "id": 1,
                              "method": "tools/list", "params": {}},
                    )
                    if r.status_code == 200:
                        break
            except Exception:
                time.sleep(0.1)
        else:
            raise RuntimeError("Gateway did not start")

        async with httpx.AsyncClient(timeout=5.0) as c:
            # tools/list
            r = await c.post(
                "http://127.0.0.1:18080/mcp",
                json={"jsonrpc": "2.0", "id": 1, "method": "tools/list",
                      "params": {}},
            )
            r.raise_for_status()
            payload = r.json()
            assert "result" in payload

            # tools/call
            r2 = await c.post(
                "http://127.0.0.1:18080/mcp",
                json={
                    "jsonrpc": "2.0",
                    "id": 2,
                    "method": "tools/call",
                    "params": {
                        "name": "search_flights",
                        "arguments": {"tenant_id": "t1", "origin": "PHX",
                                      "destination": "JFK",
                                      "date": "2026-02-10"},
                    },
                },
            )
            r2.raise_for_status()
            payload2 = r2.json()
            assert "result" in payload2
            structured = payload2["result"].get("structured")
            assert structured is not None
            assert structured["origin"] == "PHX"
            assert structured["destination"] == "JFK"
            assert len(structured["options"]) == 1
            assert structured["options"][0]["flight_number"] == "AA100"

    finally:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
