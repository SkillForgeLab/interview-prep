from __future__ import annotations

import os
from pathlib import Path

from domains.travel.sqlite_repo import SqliteFlightSearchRepository


def test_tenant_isolation_query(tmp_path: Path) -> None:
    # Create a tiny sqlite DB for the test.
    db_path = tmp_path / "t.db"
    os.environ["TRAVEL_DB_PATH"] = str(db_path)

    import sqlite3

    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute(
        """
        CREATE TABLE flights (
          tenant_id TEXT NOT NULL,
          origin TEXT NOT NULL,
          destination TEXT NOT NULL,
          date TEXT NOT NULL,
          flight_number TEXT NOT NULL,
          depart_time TEXT NOT NULL,
          arrive_time TEXT NOT NULL,
          price_usd INTEGER NOT NULL
        );
        """
    )
    cur.executemany(
        """
        INSERT INTO flights VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            ("t1", "PHX", "JFK", "2026-02-10", "AA100", "08:00", "16:20", 320),
            ("t2", "PHX", "JFK", "2026-02-10", "ZZ999", "06:00", "14:30", 999),
        ],
    )
    con.commit()
    con.close()

    repo = SqliteFlightSearchRepository(str(db_path))
    r1 = repo.search_flights(tenant_id="t1", origin="PHX", destination="JFK",
                             date="2026-02-10")
    assert [x.flight_number for x in r1] == ["AA100"]

    r2 = repo.search_flights(tenant_id="t2", origin="PHX", destination="JFK",
                             date="2026-02-10")
    assert [x.flight_number for x in r2] == ["ZZ999"]
