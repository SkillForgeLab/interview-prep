#!/usr/bin/env python3
"""
LLM triage agent - analyzes metadata and produces risk assessment.
Uses Claude API for reasoning.
"""

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv

import anthropic
from anthropic import Anthropic

from llm.prompts import SYSTEM_PROMPT, build_assessment_prompt, \
    build_retry_prompt
from validators.validate_schema import SchemaValidator

# Load environment variables
load_dotenv()


class TriageAgent:
    """LLM-powered triage agent for risk assessment."""

    def __init__(self, api_key: Optional[str] = None,
                 model: str = "claude-3-5-sonnet-20241022"):
        """
        Initialize triage agent.

        Args:
            api_key: Anthropic API key (or uses ANTHROPIC_API_KEY env var)
            model: Claude model to use
        """
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY not found in environment")

        self.model = model
        self.client = Anthropic(api_key=self.api_key)
        self.validator = SchemaValidator()

    def call_llm(
            self,
            user_prompt: str,
            max_tokens: int = 4000
    ) -> str:
        """
        Call Claude API.

        Args:
            user_prompt: User message content
            max_tokens: Maximum tokens to generate

        Returns:
            LLM response text
        """
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=SYSTEM_PROMPT,
                messages=[
                    {"role": "user", "content": user_prompt}
                ]
            )

            return message.content[0].text

        except anthropic.APIError as e:
            raise RuntimeError(f"Claude API error: {e}")

    def extract_json_from_response(self, response: str) -> str:
        """
        Extract JSON from LLM response (may have markdown formatting).

        Args:
            response: Raw LLM response

        Returns:
            Cleaned JSON string
        """
        # Try to extract from markdown code block
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response,
                               re.DOTALL)
        if json_match:
            return json_match.group(1)

        # Try to find JSON object directly
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            return json_match.group(0)

        # Return as-is and let JSON parser fail
        return response

    def assess_risk(
            self,
            secrets_path: Path,
            structure_path: Path,
            dependencies_path: Path,
            output_path: Path,
            max_retries: int = 3
    ) -> Dict[str, Any]:
        """
        Assess risk based on metadata files.

        Args:
            secrets_path: Path to secrets.json
            structure_path: Path to structure.json
            dependencies_path: Path to dependencies.json
            output_path: Where to write risk_assessment.json
            max_retries: Maximum retry attempts on validation failure

        Returns:
            Risk assessment dict

        Raises:
            FileNotFoundError: If input files don't exist
            ValueError: If unable to get valid JSON after retries
        """
        # Load metadata files
        with open(secrets_path, 'r') as f:
            secrets_json = f.read()

        with open(structure_path, 'r') as f:
            structure_json = f.read()

        with open(dependencies_path, 'r') as f:
            dependencies_json = f.read()

        # Build prompt
        user_prompt = build_assessment_prompt(
            secrets_json,
            structure_json,
            dependencies_json
        )

        print("🤖 Calling Claude API for risk assessment...")

        # Attempt to get valid response
        last_response = None
        last_error = None

        for attempt in range(max_retries):
            print(f"   Attempt {attempt + 1}/{max_retries}")

            # Call LLM
            if attempt == 0:
                response = self.call_llm(user_prompt)
            else:
                # Retry with error context
                retry_prompt = build_retry_prompt(str(last_error),
                                                  last_response)
                response = self.call_llm(retry_prompt)

            last_response = response

            # Extract JSON
            json_str = self.extract_json_from_response(response)

            # Try to parse
            try:
                assessment = json.loads(json_str)
            except json.JSONDecodeError as e:
                last_error = f"Invalid JSON: {e}"
                print(f"   ❌ JSON parse failed: {e}")
                continue

            # Validate against schema
            try:
                self.validator.validate(assessment,
                                        "./schemas/risk_assessment.v1.json")

                # Success!
                print(f"   ✅ Valid risk assessment generated")

                # Write to file
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, 'w') as f:
                    json.dump(assessment, f, indent=2)

                print(f"\n✅ Risk assessment complete:")
                print(
                    f"   Overall risk: {assessment['overall_risk']['level'].upper()}")
                print(
                    f"   Risk score: {assessment['overall_risk']['score']}/100")
                print(f"   Findings: {len(assessment['findings'])}")
                print(
                    f"   Allow merge: {assessment['merge_recommendation']['allow_merge']}")
                print(f"   Output: {output_path}")

                return assessment

            except Exception as e:
                last_error = f"Schema validation failed: {e}"
                print(f"   ❌ Schema validation failed: {e}")
                continue

        # All retries exhausted
        raise ValueError(
            f"Failed to get valid risk assessment after {max_retries} attempts.\n"
            f"Last error: {last_error}\n"
            f"Last response: {last_response[:500]}..."
        )


def triage_from_metadata(
        secrets_path: Path,
        structure_path: Path,
        dependencies_path: Path,
        output_path: Path
) -> Dict[str, Any]:
    """
    Convenience function for triaging from metadata files.

    Args:
        secrets_path: Path to secrets.json
        structure_path: Path to structure.json
        dependencies_path: Path to dependencies.json
        output_path: Where to write risk_assessment.json

    Returns:
        Risk assessment dict
    """
    agent = TriageAgent()
    return agent.assess_risk(
        secrets_path,
        structure_path,
        dependencies_path,
        output_path
    )


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 5:
        print(
            "Usage: python triage_agent.py <secrets.json> <structure.json> <dependencies.json> <output.json>")
        print(
            "Example: python triage_agent.py output/secrets.json output/structure.json output/dependencies.json output/risk_assessment.json")
        sys.exit(1)

    secrets_path = Path(sys.argv[1])
    structure_path = Path(sys.argv[2])
    dependencies_path = Path(sys.argv[3])
    output_path = Path(sys.argv[4])

    try:
        triage_from_metadata(
            secrets_path,
            structure_path,
            dependencies_path,
            output_path
        )
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)