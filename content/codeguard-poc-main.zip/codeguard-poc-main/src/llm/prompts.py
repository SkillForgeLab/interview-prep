"""
LLM prompt templates for risk assessment.
"""

SYSTEM_PROMPT = """You are a security-focused code review triage agent.

Your job is to assess pull request risk based ONLY on structured metadata.
You will NEVER see actual source code, only derived metrics and patterns.

Input artifacts you receive:
1. secrets_metadata: Redacted secret detections (NO actual secret values)
2. structure_metadata: Code complexity and risk patterns (NO function/variable names)
3. dependency_metadata: Dependencies and vulnerabilities (public package info only)

Your task:
- Analyze the metadata holistically
- Cross-reference findings across sources
- Assign overall risk level: low, medium, high, or critical
- Provide specific findings with evidence
- Give actionable recommendations

Risk assessment criteria:

CRITICAL risk (score 80-100):
- Any exposed secrets with high confidence
- Critical CVEs in new dependencies
- Critical CVEs + complex code patterns in same files

HIGH risk (score 60-79):
- High-severity CVEs in dependencies
- High complexity (cyclomatic > 15) + risky patterns (SQL, subprocess, eval)
- Multiple medium-severity issues in combination

MEDIUM risk (score 40-59):
- Medium-severity CVEs
- Moderate complexity (cyclomatic 10-15) with some risk patterns
- Basic exception handling in security-sensitive code

LOW risk (score 0-39):
- Low-severity CVEs only
- Low complexity, no concerning patterns
- No secrets, no vulnerabilities

Output requirements:
1. Be specific - reference exact metadata fields
2. Cross-reference findings when they compound risk
3. Explain reasoning clearly
4. Provide merge recommendation with conditions
5. Keep descriptions concise but actionable

Remember: You are seeing metadata ONLY. You cannot see:
- Actual secret values
- Function or variable names
- String literals or comments
- Actual code logic

Base your assessment solely on structural patterns, complexity metrics,
dependency vulnerabilities, and secret detection metadata."""

USER_PROMPT_TEMPLATE = """Analyze this pull request for security and quality risks.

=== SECRETS METADATA ===
```json
{secrets_json}
```

=== STRUCTURE METADATA ===
```json
{structure_json}
```

=== DEPENDENCY METADATA ===
```json
{dependencies_json}
```

Based on the metadata above, provide a complete risk assessment in JSON format.

Your response must be valid JSON matching this structure:
{{
  "schema_version": "1.0",
  "assessment_info": {{
    "assessed_at": "<ISO 8601 timestamp>",
    "model": {{
      "name": "<your model name>",
      "version": "<your model version>"
    }},
    "input_artifacts": {{
      "secrets": "secrets.json",
      "structure": "structure.json",
      "dependencies": "dependencies.json"
    }}
  }},
  "overall_risk": {{
    "level": "<low|medium|high|critical>",
    "score": <0-100>,
    "confidence": <0.0-1.0>,
    "reasoning": "<why this risk level, 200-1000 chars>"
  }},
  "findings": [
    {{
      "finding_id": "finding_<16 hex chars>",
      "category": "<secrets|complexity|vulnerability|pattern_risk|compliance>",
      "severity": "<critical|high|medium|low|info>",
      "description": "<clear description, max 500 chars>",
      "evidence": [
        {{
          "source": "<secrets_metadata|structure_metadata|dependency_metadata>",
          "detail": "<specific metadata reference, max 300 chars>"
        }}
      ]
    }}
  ],
  "recommendations": [
    {{
      "action": "<specific action to take, max 200 chars>",
      "priority": "<immediate|high|medium|low>",
      "rationale": "<why this action matters, max 500 chars>"
    }}
  ],
  "merge_recommendation": {{
    "allow_merge": <true|false>,
    "conditions": ["<condition 1>", "<condition 2>"]
  }}
}}

Important guidelines:
1. Generate unique finding_id values using format "finding_" + 16 random hex chars
2. Cross-reference findings when they compound risk (e.g., SQL pattern + vulnerable DB library)
3. Be specific in evidence.detail - cite exact field values from metadata
4. For secrets: ALWAYS recommend blocking merge if confidence > 0.7
5. For critical CVEs in new dependencies: ALWAYS recommend blocking merge
6. Provide at least 1 recommendation per finding above "info" severity
7. Keep confidence score realistic (0.7-0.9 range typical)

Respond with ONLY the JSON object, no other text."""

RETRY_PROMPT_TEMPLATE = """Your previous response failed JSON validation with this error:

{error_message}

Please provide the risk assessment again as valid JSON following the schema.
Ensure all required fields are present and correctly formatted.

Previous response that failed:
```
{previous_response}
```

Corrected JSON response:"""


def build_assessment_prompt(
        secrets_json: str,
        structure_json: str,
        dependencies_json: str
) -> str:
    """
    Build complete user prompt for risk assessment.

    Args:
        secrets_json: Secrets metadata as JSON string
        structure_json: Structure metadata as JSON string
        dependencies_json: Dependency metadata as JSON string

    Returns:
        Formatted user prompt
    """
    return USER_PROMPT_TEMPLATE.format(
        secrets_json=secrets_json,
        structure_json=structure_json,
        dependencies_json=dependencies_json
    )


def build_retry_prompt(error_message: str, previous_response: str) -> str:
    """
    Build retry prompt after validation failure.

    Args:
        error_message: Validation error description
        previous_response: LLM's previous invalid response

    Returns:
        Formatted retry prompt
    """
    return RETRY_PROMPT_TEMPLATE.format(
        error_message=error_message,
        previous_response=previous_response
    )