{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "https://schemas.codeguard.internal/dependency_metadata.v1.json",
  "title": "DependencyMetadata.v1",
  "description": "Dependency analysis with vulnerability data",
  "type": "object",
  "required": ["schema_version", "analysis_info", "dependencies", "stats"],
  "additionalProperties": false,
  "properties": {
    "schema_version": {
      "const": "1.0"
    },
    "analysis_info": {
      "type": "object",
      "required": ["analyzed_at", "ecosystem", "manifest_files"],
      "additionalProperties": false,
      "properties": {
        "analyzed_at": {
          "type": "string",
          "format": "date-time"
        },
        "ecosystem": {
          "enum": ["pypi", "npm", "maven", "go"],
          "description": "POC focuses on one ecosystem"
        },
        "manifest_files": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "description": "e.g., requirements.txt, pom.xml"
        }
      }
    },
    "dependencies": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "package_id",
          "name",
          "version",
          "is_new",
          "vulnerabilities"
        ],
        "additionalProperties": false,
        "properties": {
          "package_id": {
            "type": "string",
            "pattern": "^pkg_[a-f0-9]{16}$"
          },
          "name": {
            "type": "string",
            "description": "Package name (public info, OK to share)"
          },
          "version": {
            "type": "string"
          },
          "is_direct": {
            "type": "boolean",
            "description": "True if direct dependency, false if transitive"
          },
          "is_new": {
            "type": "boolean",
            "description": "True if added in this PR"
          },
          "license": {
            "type": "string",
            "description": "SPDX license identifier"
          },
          "vulnerabilities": {
            "type": "array",
            "items": {
              "type": "object",
              "required": ["cve_id", "severity", "summary"],
              "additionalProperties": false,
              "properties": {
                "cve_id": {
                  "type": "string",
                  "pattern": "^(CVE-\\d{4}-\\d+|GHSA-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4})$"
                },
                "severity": {
                  "enum": ["critical", "high", "medium", "low"]
                },
                "summary": {
                  "type": "string",
                  "maxLength": 500
                },
                "fixed_in": {
                  "type": "string",
                  "description": "Version that fixes the vulnerability"
                }
              }
            }
          }
        }
      }
    },
    "stats": {
      "type": "object",
      "required": ["total_dependencies", "new_dependencies"],
      "additionalProperties": false,
      "properties": {
        "total_dependencies": {
          "type": "integer",
          "minimum": 0
        },
        "direct_dependencies": {
          "type": "integer",
          "minimum": 0
        },
        "new_dependencies": {
          "type": "integer",
          "minimum": 0
        },
        "vulnerable_dependencies": {
          "type": "integer",
          "minimum": 0
        },
        "vulnerabilities_by_severity": {
          "type": "object",
          "additionalProperties": false,
          "properties": {
            "critical": {
              "type": "integer",
              "minimum": 0
            },
            "high": {
              "type": "integer",
              "minimum": 0
            },
            "medium": {
              "type": "integer",
              "minimum": 0
            },
            "low": {
              "type": "integer",
              "minimum": 0
            }
          }
        }
      }
    }
  }
}