#!/usr/bin/env python3
"""
CodeGuard POC - Main orchestrator script.
Runs complete metadata extraction → LLM triage → report generation pipeline.
"""

import sys
import argparse
from pathlib import Path
from datetime import datetime

from extractors.extract_secrets import extract_secrets
from extractors.extract_structure import extract_structure
from extractors.extract_dependencies import extract_dependencies
from llm.triage_agent import triage_from_metadata
from llm.triage_agent_openai import triage_from_metadata_openai
from reporters.generate_report import generate_report


def print_banner():
    """Print fancy banner."""
    print("""
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   CodeGuard POC v0.1.0                                    ║
║   Metadata-Only Code Review Risk Assessment               ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
""")


def run_pipeline(
        repo_path: Path,
        base_sha: str,
        head_sha: str,
        output_dir: Path,
        llm_provider: str = "claude",
        model: str = None
) -> int:
    """
    Run complete analysis pipeline.

    Args:
        repo_path: Path to git repository
        base_sha: Base commit SHA (PR base)
        head_sha: Head commit SHA (PR head)
        output_dir: Directory for output files

    Returns:
        Exit code (0 = success, 1 = failure)
    """
    start_time = datetime.now()

    print_banner()
    print(f"Repository: {repo_path}")
    print(f"Base SHA:   {base_sha}")
    print(f"Head SHA:   {head_sha}")
    print(f"Output:     {output_dir}")
    print()

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    # Define output paths
    secrets_path = output_dir / "secrets.json"
    structure_path = output_dir / "structure.json"
    dependencies_path = output_dir / "dependencies.json"
    assessment_path = output_dir / "risk_assessment.json"
    report_path = output_dir / "report.md"
    summary_path = output_dir / "summary.txt"

    try:
        # ============================================================
        # PHASE 1: Metadata Extraction
        # ============================================================
        print("=" * 60)
        print("PHASE 1: METADATA EXTRACTION")
        print("=" * 60)
        print()

        print("➤ Extracting secrets metadata...")
        extract_secrets(
            repo_path,
            base_sha,
            head_sha,
            secrets_path,
            scan_mode="diff"
        )
        print()

        print("➤ Extracting structure metadata...")
        extract_structure(
            repo_path,
            base_sha,
            head_sha,
            structure_path
        )
        print()

        print("➤ Extracting dependency metadata...")
        extract_dependencies(
            repo_path,
            base_sha,
            head_sha,
            dependencies_path
        )
        print()

        # ============================================================
        # PHASE 2: LLM Risk Assessment
        # ============================================================
        print("=" * 60)
        print("PHASE 2: LLM RISK ASSESSMENT")
        print("=" * 60)
        print()

        print(f"➤ Analyzing metadata with LLM ({llm_provider})...")
        if llm_provider == "openai":
            # Use OpenAI
            default_model = model or "gpt-4-turbo-preview"
            triage_from_metadata_openai(
                secrets_path,
                structure_path,
                dependencies_path,
                assessment_path,
                model=default_model
            )
        else:
            # Use Claude (default)
            triage_from_metadata(
                secrets_path,
                structure_path,
                dependencies_path,
                assessment_path
            )
        print()

        # ============================================================
        # PHASE 3: Report Generation
        # ============================================================
        print("=" * 60)
        print("PHASE 3: REPORT GENERATION")
        print("=" * 60)
        print()

        print("➤ Generating human-readable report...")
        generate_report(
            assessment_path,
            report_path,
            summary_path
        )
        print()

        # ============================================================
        # Summary
        # ============================================================
        elapsed = datetime.now() - start_time

        print("=" * 60)
        print("ANALYSIS COMPLETE")
        print("=" * 60)
        print()
        print(f"✅ All phases completed successfully")
        print(f"⏱️  Total time: {elapsed.total_seconds():.1f} seconds")
        print()
        print("📄 Output files:")
        print(f"   - Secrets:      {secrets_path}")
        print(f"   - Structure:    {structure_path}")
        print(f"   - Dependencies: {dependencies_path}")
        print(f"   - Assessment:   {assessment_path}")
        print(f"   - Report:       {report_path}")
        print(f"   - Summary:      {summary_path}")
        print()
        print(f"📖 View full report: cat {report_path}")
        print()

        # Print summary
        with open(summary_path, 'r') as f:
            summary = f.read().strip()
        print("📊 " + summary)
        print()

        return 0

    except Exception as e:
        print()
        print("=" * 60)
        print("❌ ANALYSIS FAILED")
        print("=" * 60)
        print()
        print(f"Error: {e}")
        print()
        import traceback
        traceback.print_exc()
        return 1


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="CodeGuard POC - Metadata-only code review risk assessment",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze PR in test repository
  python run.py --repo tests/test_repo --base main --head feature-with-issues

  # Analyze with custom output directory
  python run.py --repo /path/to/repo --base main --head feature --output ./results

  # Analyze comparing two specific commits
  python run.py --repo /path/to/repo --base abc123 --head def456
"""
    )

    parser.add_argument(
        '--repo',
        type=Path,
        required=True,
        help='Path to git repository'
    )

    parser.add_argument(
        '--base',
        type=str,
        required=True,
        help='Base commit SHA or branch name (PR base)'
    )

    parser.add_argument(
        '--head',
        type=str,
        required=True,
        help='Head commit SHA or branch name (PR head)'
    )

    parser.add_argument(
        '--output',
        type=Path,
        default=Path('output'),
        help='Output directory (default: ./output)'
    )

    parser.add_argument(
        '--llm',
        type=str,
        choices=['claude', 'openai'],
        default='claude',
        help='LLM provider to use (default: claude)'
    )

    parser.add_argument(
        '--model',
        type=str,
        default=None,
        help='Specific model to use (e.g., gpt-4-turbo-preview, claude-3-5-sonnet-20241022)'
    )

    args = parser.parse_args()

    # Validate repository path
    if not args.repo.exists():
        print(f"❌ Error: Repository not found: {args.repo}")
        return 1

    # Run pipeline
    exit_code = run_pipeline(
        args.repo,
        args.base,
        args.head,
        args.output,
        llm_provider=args.llm,
        model=args.model
    )

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
