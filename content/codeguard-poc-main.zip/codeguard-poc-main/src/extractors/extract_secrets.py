#!/usr/bin/env python3
"""
Secrets extractor - scans code for potential secrets.
Outputs REDACTED metadata only (never actual secret values).

NOTE:

    POC: We'll use simple regex patterns instead of TruffleHog
    to avoid external binary dependency.
    This still demonstrates the metadata-only principle.

    Production: Would use TruffleHog or similar tool.
"""

import re
import hashlib
import math
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Set
from collections import Counter
import json

from git import Repo
from validators.validate_schema import validate_secrets_metadata

# Simple secret detection patterns
SECRET_PATTERNS = {
    "github_token": re.compile(r'ghp_[a-zA-Z0-9]{36}'),
    "aws_key": re.compile(r'AKIA[0-9A-Z]{16}'),
    "api_key": re.compile(
        r'["\']?api[_-]?key["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']',
        re.IGNORECASE),
    "password": re.compile(
        r'["\']?password["\']?\s*[:=]\s*["\']([^"\']{8,})["\']',
        re.IGNORECASE),
    "private_key": re.compile(r'-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----'),
    "jwt": re.compile(r'eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+'),
}


def calculate_entropy(text: str) -> float:
    """
    Calculate Shannon entropy of a string.
    Higher entropy = more random = more likely to be a secret.

    Args:
        text: String to analyze

    Returns:
        Entropy value (typically 0-8 for base-256)
    """
    if not text:
        return 0.0

    # Count character frequencies
    counts = Counter(text)
    length = len(text)

    # Calculate Shannon entropy
    entropy = 0.0
    for count in counts.values():
        probability = count / length
        entropy -= probability * math.log2(probability)

    return entropy


def generate_finding_id(file_path: str, line_number: int,
                        secret_type: str) -> str:
    """
    Generate deterministic finding ID.

    Args:
        file_path: Path to file
        line_number: Line number
        secret_type: Type of secret

    Returns:
        finding_id in format "secret_<16_hex_chars>"
    """
    content = f"{file_path}:{line_number}:{secret_type}"
    hash_digest = hashlib.sha256(content.encode()).hexdigest()
    return f"secret_{hash_digest[:16]}"


def scan_file_for_secrets(
        file_path: Path,
        repo_root: Path,
        in_diff: bool
) -> List[Dict[str, Any]]:
    """
    Scan a single file for secrets.

    Args:
        file_path: Absolute path to file
        repo_root: Absolute path to repository root
        in_diff: True if file is in PR diff

    Returns:
        List of secret findings (metadata only, values REDACTED)
    """
    findings = []

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Warning: Could not read {file_path}: {e}")
        return findings

    relative_path = str(file_path.relative_to(repo_root))

    for line_num, line in enumerate(lines, start=1):
        for secret_type, pattern in SECRET_PATTERNS.items():
            match = pattern.search(line)
            if match:
                # Extract matched text for entropy calculation
                # (but NEVER include in output)
                matched_text = match.group(
                    1) if match.groups() else match.group(0)

                finding = {
                    "finding_id": generate_finding_id(
                        relative_path,
                        line_num,
                        secret_type
                    ),
                    "secret_type": secret_type,
                    "file_path": relative_path,
                    "line_number": line_num,
                    "confidence": 0.85,  # Simplified: would be from detector
                    "entropy": round(calculate_entropy(matched_text), 2),
                    "in_diff": in_diff
                }
                findings.append(finding)

    return findings


def get_diff_files(repo: Repo, base_sha: str, head_sha: str) -> Set[str]:
    """
    Get list of files changed between two commits.

    Args:
        repo: GitPython Repo object
        base_sha: Base commit SHA
        head_sha: Head commit SHA

    Returns:
        Set of relative file paths that changed
    """
    base_commit = repo.commit(base_sha)
    head_commit = repo.commit(head_sha)

    diff = base_commit.diff(head_commit)

    changed_files = set()
    for diff_item in diff:
        if diff_item.a_path:
            changed_files.add(diff_item.a_path)
        if diff_item.b_path:
            changed_files.add(diff_item.b_path)

    return changed_files


def extract_secrets(
        repo_path: Path,
        base_sha: str,
        head_sha: str,
        output_path: Path,
        scan_mode: str = "diff"
) -> Dict[str, Any]:
    """
    Extract secrets metadata from repository.

    Args:
        repo_path: Path to git repository
        base_sha: Base commit SHA (PR base)
        head_sha: Head commit SHA (PR head)
        output_path: Where to write secrets.json
        scan_mode: "diff" or "full"

    Returns:
        Secrets metadata dict

    Raises:
        ValueError: If repo_path is not a git repo
        FileNotFoundError: If repo_path doesn't exist
    """
    repo_path = Path(repo_path).resolve()

    if not repo_path.exists():
        raise FileNotFoundError(f"Repository not found: {repo_path}")

    try:
        repo = Repo(repo_path)
    except Exception as e:
        raise ValueError(f"Not a git repository: {repo_path}") from e

    # Get changed files for diff mode
    diff_files = get_diff_files(repo, base_sha,
                                head_sha) if scan_mode == "diff" else set()

    # Scan all Python files
    all_findings = []
    scanned_files = 0

    for py_file in repo_path.rglob("*.py"):
        if py_file.is_file():
            relative_path = str(py_file.relative_to(repo_path))
            in_diff = relative_path in diff_files if scan_mode == "diff" else False

            # In diff mode, only scan changed files
            # In full mode, scan everything
            if scan_mode == "full" or in_diff:
                findings = scan_file_for_secrets(py_file, repo_path, in_diff)
                all_findings.extend(findings)
                scanned_files += 1

    # Calculate stats
    secrets_by_type = Counter(f["secret_type"] for f in all_findings)
    secrets_in_diff = sum(1 for f in all_findings if f["in_diff"])

    # Build metadata object
    metadata = {
        "schema_version": "1.0",
        "scan_info": {
            "scan_mode": scan_mode,
            "scanned_at": datetime.utcnow().isoformat() + "Z",
            "scanner": {
                "name": "simple_regex_scanner",
                "version": "0.1.0"
            }
        },
        "findings": all_findings,
        "stats": {
            "total_files_scanned": scanned_files,
            "secrets_found": len(all_findings),
            "secrets_in_diff": secrets_in_diff,
            "secrets_by_type": dict(secrets_by_type)
        }
    }

    # Validate against schema
    validate_secrets_metadata_dict(metadata)

    # Write to file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(metadata, f, indent=2)

    print(f"✅ Secrets scan complete:")
    print(f"   Files scanned: {scanned_files}")
    print(f"   Secrets found: {len(all_findings)}")
    print(f"   Output: {output_path}")

    return metadata


def validate_secrets_metadata_dict(data: Dict[str, Any]) -> None:
    """Validate secrets metadata dict against schema."""
    from validators.validate_schema import SchemaValidator
    validator = SchemaValidator()
    validator.validate(data, "secrets_metadata.v1.json")


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 5:
        print(
            "Usage: python extract_secrets.py <repo_path> <base_sha> <head_sha> <output_path>")
        print(
            "Example: python extract_secrets.py ./test_repo main feature output/secrets.json")
        sys.exit(1)

    repo_path = Path(sys.argv[1])
    base_sha = sys.argv[2]
    head_sha = sys.argv[3]
    output_path = Path(sys.argv[4])

    try:
        extract_secrets(repo_path, base_sha, head_sha, output_path)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)
