#!/usr/bin/env python3
"""
Dependency extractor - analyzes dependencies and checks vulnerabilities.
Uses OSV.dev API for vulnerability data.
"""

import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Set, Optional
import requests
from git import Repo

from validators.validate_schema import SchemaValidator


def parse_requirements_txt(file_path: Path) -> List[Dict[str, str]]:
    """
    Parse requirements.txt file.

    Args:
        file_path: Path to requirements.txt

    Returns:
        List of dicts with 'name' and 'version'
    """
    dependencies = []

    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()
    except FileNotFoundError:
        return dependencies

    for line in lines:
        line = line.strip()

        # Skip comments and empty lines
        if not line or line.startswith('#'):
            continue

        # Parse package==version or package>=version
        match = re.match(r'^([a-zA-Z0-9_-]+)\s*([=><]=?)\s*([0-9.]+)', line)
        if match:
            name = match.group(1)
            version = match.group(3)
            dependencies.append({
                'name': name,
                'version': version
            })

    return dependencies


def query_osv_api(package_name: str, version: str, ecosystem: str = "PyPI") -> \
List[Dict[str, Any]]:
    """
    Query OSV.dev API for vulnerabilities.

    Args:
        package_name: Name of package
        version: Version string
        ecosystem: Package ecosystem (PyPI, npm, Maven, etc.)

    Returns:
        List of vulnerability dicts
    """
    url = "https://api.osv.dev/v1/query"

    payload = {
        "package": {
            "name": package_name,
            "ecosystem": ecosystem
        },
        "version": version
    }

    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()

        if "vulns" in data:
            return data["vulns"]
        return []

    except requests.exceptions.RequestException as e:
        print(f"Warning: OSV API query failed for {package_name}: {e}")
        return []


def parse_osv_vulnerability(vuln: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Parse OSV vulnerability data into our schema format.

    Args:
        vuln: Raw vulnerability dict from OSV API

    Returns:
        Parsed vulnerability dict or None
    """
    # Extract CVE ID (may be in aliases)
    cve_id = vuln.get("id", "")
    if not cve_id.startswith("CVE-"):
        # Check aliases for CVE
        for alias in vuln.get("aliases", []):
            if alias.startswith("CVE-"):
                cve_id = alias
                break

    # If still no CVE, use GHSA or original ID
    if not cve_id.startswith("CVE-") and not cve_id.startswith("GHSA-"):
        return None

    # Determine severity
    severity_map = {
        "CRITICAL": "critical",
        "HIGH": "high",
        "MEDIUM": "medium",
        "MODERATE": "medium",
        "LOW": "low"
    }

    severity = "medium"  # default
    if "severity" in vuln:
        for sev in vuln["severity"]:
            if "type" in sev and sev["type"] == "CVSS_V3":
                score = sev.get("score", "")
                # CVSS v3 score to severity
                if "CRITICAL" in score.upper():
                    severity = "critical"
                elif "HIGH" in score.upper():
                    severity = "high"
                elif "MEDIUM" in score.upper() or "MODERATE" in score.upper():
                    severity = "medium"
                elif "LOW" in score.upper():
                    severity = "low"

    # Get summary
    summary = vuln.get("summary", "No description available")[:500]

    # Get fixed version
    fixed_in = None
    if "affected" in vuln:
        for affected in vuln["affected"]:
            if "ranges" in affected:
                for range_item in affected["ranges"]:
                    if "events" in range_item:
                        for event in range_item["events"]:
                            if "fixed" in event:
                                fixed_in = event["fixed"]
                                break

    return {
        "cve_id": cve_id,
        "severity": severity,
        "summary": summary,
        "fixed_in": fixed_in
    }


def generate_package_id(name: str, version: str) -> str:
    """
    Generate deterministic package ID.

    Args:
        name: Package name
        version: Version string

    Returns:
        package_id in format "pkg_<16_hex_chars>"
    """
    content = f"{name}:{version}"
    hash_digest = hashlib.sha256(content.encode()).hexdigest()
    return f"pkg_{hash_digest[:16]}"


def get_changed_dependencies(
        repo: Repo,
        base_sha: str,
        head_sha: str,
        manifest_path: str = "requirements.txt"
) -> Set[str]:
    """
    Get list of newly added dependencies.

    Args:
        repo: GitPython Repo object
        base_sha: Base commit SHA
        head_sha: Head commit SHA
        manifest_path: Path to manifest file

    Returns:
        Set of package names that are new in head
    """
    try:
        # Get requirements.txt at base
        base_commit = repo.commit(base_sha)
        base_req = None
        try:
            base_req_content = (
                        base_commit.tree / manifest_path).data_stream.read()
            base_deps = set()
            for line in base_req_content.decode('utf-8').split('\n'):
                match = re.match(r'^([a-zA-Z0-9_-]+)', line.strip())
                if match:
                    base_deps.add(match.group(1).lower())
        except KeyError:
            base_deps = set()

        # Get requirements.txt at head
        head_commit = repo.commit(head_sha)
        try:
            head_req_content = (
                        head_commit.tree / manifest_path).data_stream.read()
            head_deps = set()
            for line in head_req_content.decode('utf-8').split('\n'):
                match = re.match(r'^([a-zA-Z0-9_-]+)', line.strip())
                if match:
                    head_deps.add(match.group(1).lower())
        except KeyError:
            head_deps = set()

        # Return new dependencies
        return head_deps - base_deps

    except Exception as e:
        print(f"Warning: Could not compare dependencies: {e}")
        return set()


def extract_dependencies(
        repo_path: Path,
        base_sha: str,
        head_sha: str,
        output_path: Path,
        manifest_file: str = "requirements.txt",
        ecosystem: str = "pypi"
) -> Dict[str, Any]:
    """
    Extract dependency metadata from repository.

    Args:
        repo_path: Path to git repository
        base_sha: Base commit SHA
        head_sha: Head commit SHA
        output_path: Where to write dependencies.json
        manifest_file: Name of manifest file
        ecosystem: Package ecosystem

    Returns:
        Dependency metadata dict
    """
    repo_path = Path(repo_path).resolve()

    if not repo_path.exists():
        raise FileNotFoundError(f"Repository not found: {repo_path}")

    try:
        repo = Repo(repo_path)
    except Exception as e:
        raise ValueError(f"Not a git repository: {repo_path}") from e

    # Parse manifest file
    manifest_path = repo_path / manifest_file
    dependencies_list = parse_requirements_txt(manifest_path)

    # Get new dependencies
    new_dep_names = get_changed_dependencies(repo, base_sha, head_sha,
                                             manifest_file)

    # Analyze each dependency
    dependencies = []
    vulnerable_count = 0
    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}

    print(f"Analyzing {len(dependencies_list)} dependencies...")

    for dep in dependencies_list:
        name = dep["name"]
        version = dep["version"]

        print(f"  Checking {name} {version}...")

        # Query vulnerabilities
        vulns_raw = query_osv_api(name, version, "PyPI")
        vulnerabilities = []

        for vuln_raw in vulns_raw:
            vuln = parse_osv_vulnerability(vuln_raw)
            if vuln:
                vulnerabilities.append(vuln)
                severity_counts[vuln["severity"]] += 1

        if vulnerabilities:
            vulnerable_count += 1

        dependencies.append({
            "package_id": generate_package_id(name, version),
            "name": name,
            "version": version,
            "is_direct": True,  # Simplified for POC
            "is_new": name.lower() in new_dep_names,
            "license": "Unknown",  # Would need PyPI API for this
            "vulnerabilities": vulnerabilities
        })

    # Build metadata object
    metadata = {
        "schema_version": "1.0",
        "analysis_info": {
            "analyzed_at": datetime.utcnow().isoformat() + "Z",
            "ecosystem": ecosystem,
            "manifest_files": [manifest_file]
        },
        "dependencies": dependencies,
        "stats": {
            "total_dependencies": len(dependencies),
            "direct_dependencies": len(dependencies),
            "new_dependencies": sum(1 for d in dependencies if d["is_new"]),
            "vulnerable_dependencies": vulnerable_count,
            "vulnerabilities_by_severity": severity_counts
        }
    }

    # Validate against schema
    validator = SchemaValidator()
    validator.validate(metadata, "dependency_metadata.v1.json")

    # Write to file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(metadata, f, indent=2)

    print(f"✅ Dependency analysis complete:")
    print(f"   Total dependencies: {len(dependencies)}")
    print(f"   Vulnerable: {vulnerable_count}")
    print(f"   New in PR: {sum(1 for d in dependencies if d['is_new'])}")
    print(f"   Output: {output_path}")

    return metadata


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 5:
        print(
            "Usage: python extract_dependencies.py <repo_path> <base_sha> <head_sha> <output_path>")
        print(
            "Example: python extract_dependencies.py ./test_repo main feature output/dependencies.json")
        sys.exit(1)

    repo_path = Path(sys.argv[1])
    base_sha = sys.argv[2]
    head_sha = sys.argv[3]
    output_path = Path(sys.argv[4])

    try:
        extract_dependencies(repo_path, base_sha, head_sha, output_path)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)