#!/usr/bin/env python3
"""
Structure extractor - analyzes code structure using tree-sitter.
Outputs anonymized metadata (NO function names, NO variable names).
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Set, Optional
from collections import defaultdict

from git import Repo
import tree_sitter_python as tspython
from tree_sitter import Language, Parser, Node

from validators.validate_schema import SchemaValidator

# Initialize tree-sitter Python parser
PY_LANGUAGE = Language(tspython.language())
parser = Parser(PY_LANGUAGE)

# Risk pattern detection
RISK_PATTERNS = {
    "sql_query": [
        b"SELECT", b"INSERT", b"UPDATE", b"DELETE", b"DROP", b"CREATE TABLE"
    ],
    "subprocess_execution": [
        b"subprocess.", b"os.system", b"os.popen", b"os.exec"
    ],
    "eval_usage": [
        b"eval(", b"exec("
    ],
    "file_operations": [
        b"open(", b"file(", b"Path("
    ],
    "network_call": [
        b"requests.", b"urllib.", b"http.client", b"socket."
    ],
    "crypto_operations": [
        b"cryptography", b"Crypto.", b"hashlib", b"secrets."
    ],
    "password_handling": [
        b"password", b"passwd", b"pwd"
    ]
}


def calculate_cyclomatic_complexity(node: Node) -> int:
    """
    Calculate cyclomatic complexity of a function.
    CC = number of decision points + 1

    Decision points: if, elif, for, while, except, and, or, case

    Args:
        node: Function definition node

    Returns:
        Cyclomatic complexity score
    """
    decision_points = 0

    def traverse(n: Node):
        nonlocal decision_points

        if n.type in [
            'if_statement',
            'elif_clause',
            'for_statement',
            'while_statement',
            'except_clause',
            'case_clause',  # Python 3.10+ match/case
        ]:
            decision_points += 1

        # Count boolean operators (and, or) as decision points
        if n.type == 'boolean_operator':
            decision_points += 1

        for child in n.children:
            traverse(child)

    traverse(node)
    return decision_points + 1


def calculate_nesting_depth(node: Node) -> int:
    """
    Calculate maximum nesting depth of a function.

    Args:
        node: Function definition node

    Returns:
        Maximum nesting depth
    """

    def get_depth(n: Node, current_depth: int = 0) -> int:
        if n.type in [
            'if_statement',
            'for_statement',
            'while_statement',
            'with_statement',
            'try_statement',
        ]:
            current_depth += 1

        max_depth = current_depth
        for child in n.children:
            child_depth = get_depth(child, current_depth)
            max_depth = max(max_depth, child_depth)

        return max_depth

    return get_depth(node)


def count_parameters(node: Node) -> int:
    """
    Count function parameters.

    Args:
        node: Function definition node

    Returns:
        Number of parameters
    """
    params_node = node.child_by_field_name('parameters')
    if not params_node:
        return 0

    # Count parameter nodes (excluding self, cls)
    param_count = 0
    for child in params_node.children:
        if child.type in ['identifier', 'typed_parameter',
                          'default_parameter']:
            # Skip 'self' and 'cls'
            if child.type == 'identifier':
                param_name = child.text.decode('utf-8')
                if param_name not in ['self', 'cls']:
                    param_count += 1
            else:
                param_count += 1

    return param_count


def detect_risk_patterns(node: Node, source_code: bytes) -> List[str]:
    """
    Detect risky code patterns in function.

    Args:
        node: Function definition node
        source_code: Full source code as bytes

    Returns:
        List of detected pattern names
    """
    detected = set()

    # Get function source code
    func_start = node.start_byte
    func_end = node.end_byte
    func_source = source_code[func_start:func_end]

    # Check for each pattern
    for pattern_name, keywords in RISK_PATTERNS.items():
        for keyword in keywords:
            if keyword in func_source:
                detected.add(pattern_name)
                break

    return sorted(detected)


def classify_exception_handling(node: Node) -> str:
    """
    Classify exception handling in function.

    Args:
        node: Function definition node

    Returns:
        "none", "basic", or "comprehensive"
    """
    has_try = False
    has_specific_except = False
    has_finally = False

    def traverse(n: Node):
        nonlocal has_try, has_specific_except, has_finally

        if n.type == 'try_statement':
            has_try = True

            # Check for specific exception types
            for child in n.children:
                if child.type == 'except_clause':
                    # Check if it specifies exception type
                    if len(child.children) > 1:
                        has_specific_except = True
                elif child.type == 'finally_clause':
                    has_finally = True

        for child in n.children:
            traverse(child)

    traverse(node)

    if not has_try:
        return "none"
    elif has_specific_except or has_finally:
        return "comprehensive"
    else:
        return "basic"


def generate_function_id(file_path: str, node: Node,
                         source_code: bytes) -> str:
    """
    Generate anonymous function ID (NOT actual function name).

    Args:
        file_path: Relative file path
        node: Function definition node
        source_code: Full source code

    Returns:
        function_id in format "func_<16_hex_chars>"
    """
    # Create signature shape (structure, not names)
    line_start = node.start_point[0] + 1
    param_count = count_parameters(node)

    # Hash based on location and structure
    content = f"{file_path}:{line_start}:params={param_count}"
    hash_digest = hashlib.sha256(content.encode()).hexdigest()

    return f"func_{hash_digest[:16]}"


def analyze_function(
        node: Node,
        source_code: bytes,
        file_path: str
) -> Dict[str, Any]:
    """
    Analyze a single function and extract metadata.

    Args:
        node: Function definition node
        source_code: Full source code
        file_path: Relative file path

    Returns:
        Function metadata dict
    """
    line_start = node.start_point[0] + 1
    line_end = node.end_point[0] + 1
    lines_of_code = line_end - line_start + 1

    # Determine function type
    func_type = "function"
    parent = node.parent
    if parent and parent.type == 'class_definition':
        func_type = "method"
        # Check if it's __init__
        name_node = node.child_by_field_name('name')
        if name_node and name_node.text == b'__init__':
            func_type = "constructor"

    complexity = {
        "cyclomatic": calculate_cyclomatic_complexity(node),
        "nesting_depth": calculate_nesting_depth(node),
        "parameter_count": count_parameters(node),
        "lines_of_code": lines_of_code
    }

    risk_indicators = {
        "patterns_detected": detect_risk_patterns(node, source_code),
        "exception_handling": classify_exception_handling(node)
    }

    return {
        "function_id": generate_function_id(file_path, node, source_code),
        "type": func_type,
        "line_start": line_start,
        "line_end": line_end,
        "complexity": complexity,
        "risk_indicators": risk_indicators
    }


def analyze_file(
        file_path: Path,
        repo_root: Path,
        in_diff: bool
) -> Optional[Dict[str, Any]]:
    """
    Analyze a single Python file.

    Args:
        file_path: Absolute path to file
        repo_root: Absolute path to repo root
        in_diff: True if file changed in PR

    Returns:
        File metadata dict or None if parse fails
    """
    try:
        with open(file_path, 'rb') as f:
            source_code = f.read()
    except Exception as e:
        print(f"Warning: Could not read {file_path}: {e}")
        return None

    # Parse with tree-sitter
    tree = parser.parse(source_code)
    root_node = tree.root_node

    relative_path = str(file_path.relative_to(repo_root))

    # Calculate file hash
    file_hash = hashlib.sha256(source_code).hexdigest()

    # Find all function definitions
    functions = []

    def find_functions(node: Node):
        if node.type == 'function_definition':
            func_metadata = analyze_function(node, source_code, relative_path)
            functions.append(func_metadata)

        for child in node.children:
            find_functions(child)

    find_functions(root_node)

    return {
        "file_path": relative_path,
        "in_diff": in_diff,
        "file_hash": file_hash,
        "functions": functions
    }


def get_diff_files(repo: Repo, base_sha: str, head_sha: str) -> Set[str]:
    """Get set of files changed between commits."""
    base_commit = repo.commit(base_sha)
    head_commit = repo.commit(head_sha)
    diff = base_commit.diff(head_commit)

    changed_files = set()
    for diff_item in diff:
        if diff_item.a_path:
            changed_files.add(diff_item.a_path)
        if diff_item.b_path:
            changed_files.add(diff_item.b_path)

    return changed_files


def extract_structure(
        repo_path: Path,
        base_sha: str,
        head_sha: str,
        output_path: Path,
        language: str = "python"
) -> Dict[str, Any]:
    """
    Extract code structure metadata from repository.

    Args:
        repo_path: Path to git repository
        base_sha: Base commit SHA
        head_sha: Head commit SHA
        output_path: Where to write structure.json
        language: Programming language (only "python" supported in POC)

    Returns:
        Structure metadata dict
    """
    repo_path = Path(repo_path).resolve()

    if not repo_path.exists():
        raise FileNotFoundError(f"Repository not found: {repo_path}")

    try:
        repo = Repo(repo_path)
    except Exception as e:
        raise ValueError(f"Not a git repository: {repo_path}") from e

    # Get changed files
    diff_files = get_diff_files(repo, base_sha, head_sha)

    # Analyze all Python files
    files_metadata = []
    total_functions = 0
    high_complexity_count = 0

    for py_file in repo_path.rglob("*.py"):
        if py_file.is_file():
            relative_path = str(py_file.relative_to(repo_path))
            in_diff = relative_path in diff_files

            file_meta = analyze_file(py_file, repo_path, in_diff)
            if file_meta:
                files_metadata.append(file_meta)
                total_functions += len(file_meta["functions"])

                # Count high complexity functions (cyclomatic > 10)
                for func in file_meta["functions"]:
                    if func["complexity"]["cyclomatic"] > 10:
                        high_complexity_count += 1

    # Build metadata object
    metadata = {
        "schema_version": "1.0",
        "analysis_info": {
            "analyzed_at": datetime.utcnow().isoformat() + "Z",
            "language": language,
            "parser": {
                "name": "tree-sitter",
                "version": "0.20.4"
            }
        },
        "files": files_metadata,
        "stats": {
            "total_files": len(files_metadata),
            "files_in_diff": sum(1 for f in files_metadata if f["in_diff"]),
            "total_functions": total_functions,
            "high_complexity_functions": high_complexity_count
        }
    }

    # Validate against schema
    validator = SchemaValidator()
    validator.validate(metadata, "structure_metadata.v1.json")

    # Write to file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(metadata, f, indent=2)

    print(f"✅ Structure analysis complete:")
    print(f"   Files analyzed: {len(files_metadata)}")
    print(f"   Functions found: {total_functions}")
    print(f"   High complexity: {high_complexity_count}")
    print(f"   Output: {output_path}")

    return metadata


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 5:
        print(
            "Usage: python extract_structure.py <repo_path> <base_sha> <head_sha> <output_path>")
        print(
            "Example: python extract_structure.py ./test_repo main feature output/structure.json")
        sys.exit(1)

    repo_path = Path(sys.argv[1])
    base_sha = sys.argv[2]
    head_sha = sys.argv[3]
    output_path = Path(sys.argv[4])

    try:
        extract_structure(repo_path, base_sha, head_sha, output_path)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)