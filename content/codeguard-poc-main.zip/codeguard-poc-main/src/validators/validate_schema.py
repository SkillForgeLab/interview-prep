#!/usr/bin/env python3
"""
Schema validation utility.
Validates JSON data against JSON Schema files.
"""

import json
from pathlib import Path
from typing import Dict, Any
import jsonschema
from jsonschema import validate, ValidationError


class SchemaValidator:
    """Validates JSON data against schemas."""

    def __init__(self, schema_dir: Path = Path("src/schemas")):
        """
        Initialize validator.

        Args:
            schema_dir: Directory containing schema files
        """
        self.schema_dir = Path(schema_dir)
        self._schema_cache: Dict[str, Dict[str, Any]] = {}

    def load_schema(self, schema_name: str) -> Dict[str, Any]:
        """
        Load a JSON schema file.

        Args:
            schema_name: Name of schema file (e.g., "secrets_metadata.v1.json")

        Returns:
            Parsed JSON schema

        Raises:
            FileNotFoundError: If schema file doesn't exist
            json.JSONDecodeError: If schema file is invalid JSON
        """
        if schema_name in self._schema_cache:
            return self._schema_cache[schema_name]

        schema_path = self.schema_dir / schema_name

        if not schema_path.exists():
            raise FileNotFoundError(f"Schema not found: {schema_path}")

        with open(schema_path, 'r') as f:
            schema = json.load(f)

        self._schema_cache[schema_name] = schema
        return schema

    def validate(self, data: Dict[str, Any], schema_name: str) -> None:
        """
        Validate data against a schema.

        Args:
            data: JSON data to validate
            schema_name: Name of schema file

        Raises:
            ValidationError: If data doesn't conform to schema
            FileNotFoundError: If schema file doesn't exist
        """
        schema = self.load_schema(schema_name)

        try:
            validate(instance=data, schema=schema)
        except ValidationError as e:
            # Re-raise with more context
            raise ValidationError(
                f"Validation failed for {schema_name}: {e.message}\n"
                f"Path: {' -> '.join(str(p) for p in e.path)}"
            )

    def validate_file(self, json_path: Path, schema_name: str) -> None:
        """
        Validate a JSON file against a schema.

        Args:
            json_path: Path to JSON file
            schema_name: Name of schema file

        Raises:
            ValidationError: If data doesn't conform to schema
            FileNotFoundError: If file doesn't exist
            json.JSONDecodeError: If file is invalid JSON
        """
        if not json_path.exists():
            raise FileNotFoundError(f"JSON file not found: {json_path}")

        with open(json_path, 'r') as f:
            data = json.load(f)

        self.validate(data, schema_name)


def validate_secrets_metadata(json_path: Path) -> None:
    """Validate secrets metadata JSON."""
    validator = SchemaValidator()
    validator.validate_file(json_path, "secrets_metadata.v1.json")


def validate_structure_metadata(json_path: Path) -> None:
    """Validate structure metadata JSON."""
    validator = SchemaValidator()
    validator.validate_file(json_path, "structure_metadata.v1.json")


def validate_dependency_metadata(json_path: Path) -> None:
    """Validate dependency metadata JSON."""
    validator = SchemaValidator()
    validator.validate_file(json_path, "dependency_metadata.v1.json")


def validate_risk_assessment(json_path: Path) -> None:
    """Validate risk assessment JSON."""
    validator = SchemaValidator()
    validator.validate_file(json_path, "risk_assessment.v1.json")


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Usage: python validate_schema.py <json_file> <schema_name>")
        print(
            "Example: python validate_schema.py output/secrets.json secrets_metadata.v1.json")
        sys.exit(1)

    json_file = Path(sys.argv[1])
    schema_name = sys.argv[2]

    try:
        validator = SchemaValidator()
        validator.validate_file(json_file, schema_name)
        print(f"✅ {json_file} is valid against {schema_name}")
    except ValidationError as e:
        print(f"❌ Validation failed: {e}")
        sys.exit(1)
    except FileNotFoundError as e:
        print(f"❌ File not found: {e}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON: {e}")
        sys.exit(1)