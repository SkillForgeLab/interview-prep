Goal
Run this uv command in PyCharm.

Command you have
uv run python ./src/run.py \
  --repo tests/test_repo \
  --base main \
  --head feature-with-issues \
  --llm openai \
  --model gpt-4-0125-preview

Option 1 (best) Run Configuration (Run/Debug)
1) Open: Run > Edit Configurations…
2) Click: +  > Python
3) Set:
   - Name: run.py (uv)
   - Script path: <project_root>/src/run.py
   - Parameters:
     --repo tests/test_repo --base main --head feature-with-issues --llm openai --model gpt-4-0125-preview
   - Working directory: <project_root>

4) IMPORTANT: choose the right interpreter
   Pick ONE approach:

   A) Use uv’s environment interpreter
   - In Terminal, find the interpreter path:
     uv run python -c "import sys; print(sys.executable)"
   - In PyCharm:
     Settings/Preferences > Project > Python Interpreter > Add Interpreter > Existing environment
     Paste that path.

   B) If you are using a normal venv (not uv)
   - Make sure dependencies are installed in that venv (pip/uv).
   - Select that venv as the interpreter in PyCharm.

5) Click Apply > Run.

Notes
- PyCharm “Parameters” is one line. Do not use "\" there.
- Keep paths relative to the Working directory, or use absolute paths.

Option 2 Run in PyCharm Terminal (fastest)
1) Open PyCharm Terminal
2) Run the original multiline command exactly (backslashes work in zsh/bash):
   uv run python ./src/run.py \
     --repo tests/test_repo \
     --base main \
     --head feature-with-issues \
     --llm openai \
     --model gpt-4-0125-preview

Option 3 Use a PyCharm “Shell Script” configuration (if available)
- Run > Edit Configurations… > + > Shell Script
- Script:
  uv run python ./src/run.py --repo tests/test_repo --base main --head feature-with-issues --llm openai --model gpt-4-0125-preview
- Working directory: <project_root>

Quick check (helps debug interpreter issues)
- In PyCharm Terminal:
  uv run python -c "import sys; print(sys.executable)"

Key terms to memorize
- interpreter: the Python executable PyCharm uses.
- working directory: the folder your relative paths start from.
- parameters: the CLI args after the script path.

Summary
- Best: create a Python Run Configuration for src/run.py.
- Set params on one line.
- Make PyCharm use the same interpreter as uv (get it via sys.executable).
