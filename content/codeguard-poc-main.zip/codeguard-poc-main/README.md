# macOS (Intel) — Run Instructions

---

## Prerequisites

- macOS (Intel)
- uv installed

### 1. Verify CPU architecture

```bash
uname -m
```

#### Expected

- x86_64

### 2. Verify `uv`

```bash
which uv
uv --version
```

#### If missing, run

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

#### Restart terminal after install.

---

### PHASE 1: FOUNDATION

- TASK 1a: CREATE PROJECT STRUCTURE
    - OBJECTIVE: Create directory structure and placeholder files.
    - COMMANDS:
      ```bash
         mkdir -p codeguard-poc
         cd codeguard-poc
         
         mkdir -p schemas
         mkdir -p extractors
         mkdir -p llm
         mkdir -p validators
         mkdir -p reporters
         mkdir -p tests/test_repo/src
         mkdir -p tests/expected_outputs
         mkdir -p output
         
         touch schemas/__init__.py
         touch extractors/__init__.py
         touch llm/__init__.py
         touch validators/__init__.py
         touch reporters/__init__.py
         touch tests/__init__.py
      ```
      **SUCCESS CRITERIA** <br/>
      > - ✅ All directories created
      >- ✅ All __init__.py files present

- TASK 1b: CREATE REQUIREMENTS FILE
    - FILE: `pyproject.toml`
      ```
      [project]
      name = "codeguard-poc"
      version = "0.1.0"
      description = "Add your description here"
      requires-python = ">=3.11"
      
      dependencies = [
          "python-dotenv>=1.0.1",
          "GitPython>=3.1.41",
          "tree-sitter>=0.20.4",
          "tree-sitter-python>=0.20.4",
          "jsonschema>=4.21.1",
          "requests>=2.31.0",
          "anthropic>=0.18.1",
          "pydantic>=2.5.3",
      ]
      
      [build-system]
      requires = ["setuptools>=78.1.0"]
      build-backend = "setuptools.build_meta"
      
      [tool.setuptools]
      package-dir = { "" = "src" }
      
      [tool.setuptools.packages.find]
      where = ["src"]
      ```

- TASK 1c: SAMPLE ENVIRONMENT FILE
    - FILE: `.env.example`
    ```env
    # LLM Configuration - Choose ONE provider
    # For Claude:
    ANTHROPIC_API_KEY=your-anthropic-key-here
    
    # For OpenAI:
    OPENAI_API_KEY=your-openai-key-here
    OPENAI_TRACING_ENABLED=true
    
    # Paths
    TRUFFLEHOG_PATH=/usr/local/bin/trufflehog
    
    # Validation
    STRICT_SCHEMA_VALIDATION=true
    ```
  
- TASK 1d: PYTHON VERSION FILE
    - FILE: `.python-version`
    ```
    3.11
    ```

- TASK 2: CREATE VIRTUAL ENVIRONMENT
    - **Copy environment variables**
      ```bash
      cp .env.example .env
      ```
    - **Enable environment configuration**
      ```bash
      set -a
      source .env
      set +a
      ```
      - **Test environment configuration:**
         ```bash
            uv run python -c "from dotenv import load_dotenv; import os; load_dotenv(); print('API Key loaded:', 'ANTHROPIC_API_KEY' in os.environ)"
         ```
         > **EXPECTED OUTPUT**  
         API Key loaded: True <br/><br/>
         **SUCCESS CRITERIA** <br/>
         >- ✅ .env file exists with real API key
         >- ✅ .gitignore prevents .env from being committed
         >- ✅ Environment variables load successfully

    - **Install `.venv`**
      ```bash
      rm -rf .venv
      uv venv
      ```
    - **Activate `.venv`**
      ```bash
      source .venv/bin/activate
      ```
      - **Verify Python Installation**
        ```bash
        which python
        uv run python --version
        ```
        > **Expected**<br/>
        .../.venv/bin/python <br/>
        Python 3.11.14<br/>

- TASK 3: INSTALL DEPENDENCIES
    - Run from project root directory
    ```bash
    uv pip install -e ".[dev]"
    ```
    **Expected**
    ```
    No errors
    ```

---

### PHASE 2: JSON SCHEMAS

- TASK 4: CREATE SECRETS METADATA SCHEMA
    - FILE:
      `schemas/secrets_metadata.v1.json`
    - TEST:
      ```bash
         uv run python -c "import json; schema = json.load(open('src/schemas/secrets_metadata.v1.json')); print('Schema valid:', schema['title'])"
      ```
      > **EXPECTED OUTPUT**  
      Schema valid: SecretsMetadata.v1 <br/><br/>
      **SUCCESS CRITERIA** <br/>
      >- ✅ Schema file is valid JSON
      >- ✅ Schema loads without errors

- TASK 5: CREATE STRUCTURE METADATA SCHEMA
    - FILE: `schemas/structure_metadata.v1.json`
    - TEST:
      ```bash
         uv run python -c "import json; schema = json.load(open('src/schemas/structure_metadata.v1.json')); print('Schema valid:', schema['title'])"
      ```
      > **EXPECTED OUTPUT**  
      Schema valid: StructureMetadata.v1 <br/><br/>
      **SUCCESS CRITERIA** <br/>
      >- ✅ Schema file is valid JSON
      >- ✅ Schema loads without errors

- TASK 6: CREATE DEPENDENCY METADATA SCHEMA
    - FILE: `schemas/dependency_metadata.v1.json`
    - TEST:
      ```bash
         uv run python -c "import json; schema = json.load(open('src/schemas/dependency_metadata.v1.json')); print('Schema valid:', schema['title'])"
      ```
      > **EXPECTED OUTPUT**  
      Schema valid: DependencyMetadata.v1 <br/><br/>
      **SUCCESS CRITERIA** <br/>
      >- ✅ Schema file is valid JSON
      >- ✅ Schema loads without errors

- TASK 7: CREATE RISK ASSESSMENT SCHEMA
    - FILE: `schemas/risk_assessment.v1.json`
    - TEST:
      ```bash
         uv run python -c "import json; schema = json.load(open('src/schemas/risk_assessment.v1.json')); print('Schema valid:', schema['title'])"
      ```
      > **EXPECTED OUTPUT**  
      Schema valid: RiskAssessment.v1 <br/><br/>
      **SUCCESS CRITERIA** <br/>
      >- ✅ Schema file is valid JSON
      >- ✅ Schema loads without errors
      >- ✅ All 4 schemas created

 ---

### PHASE 3: VALIDATORS

- TASK 8a: CREATE SCHEMA VALIDATOR
    - FILE: `validators/validate_schema.py`
    - TEST: <br/>
      **Create a test JSON file**
      ```bash
        cat > ./tmp/test_secrets.json << 'EOF'
        {
          "schema_version": "1.0",
          "scan_info": {
            "scan_mode": "diff",
            "scanned_at": "2024-02-15T10:30:00Z",
            "scanner": {
              "name": "test",
              "version": "1.0"
            }
          },
          "findings": [],
          "stats": {
            "total_files_scanned": 0,
            "secrets_found": 0
           }
        }EOF
      ```     

- TASK 8b: VALIDATE `JSON` FILE
  - Run: 
    ```bash
       uv run python ./src/validators/validate_schema.py ./tmp/test_secrets.json secrets_metadata.v1.json
    ```
  >   **EXPECTED OUTPUT**  
    ✅ ./tmp/test_secrets.json is valid against
    secrets_metadata.v1.json <br/><br/>
    **SUCCESS CRITERIA** <br/>
  >  - ✅ Validator loads schemas correctly
  >  - ✅ Validator accepts valid JSON
  >  - ✅ Validator rejects invalid JSON (test by breaking the JSON)

---

### PHASE 4: EXTRACTORS

- TASK 9: Create Secrets Extractor (Simplified - No TruffleHog)
    - FILE: `extractors/extract_secrets.py`
    - TEST: <br/>
      **Can't test until we have test repo in Task 13**
      > **SUCCESS CRITERIA** <br/>
      >- ✅ Code runs without syntax errors
      >- ✅ Imports work correctly
      >- ✅ Will test with actual repo in later task

- TASK 10: Create Structure Extractor (Tree-sitter)
    - FILE: `extractors/extract_structure.py`
    - TEST: <br/>
      **Can't test until we have test repo in Task 13**
      > **SUCCESS CRITERIA** <br/>
      >- ✅ Code runs without syntax errors
      >- ✅ Imports work correctly
      >- ✅ Tree-sitter parser initializes
      >- ✅ Will test with actual repo in later task

- TASK 11: Create Dependency Extractor
    - FILE: `extractors/extract_dependencies.py`
    - TEST: <br/>
      **Can't test until we have test repo in Task 13**
      > **SUCCESS CRITERIA** <br/>
      >- ✅ Code runs without syntax errors
      >- ✅ Imports work correctly
      >- ✅ OSV API integration works (will test later) - TODO: What is OSV API?
      >- ✅ Will test with actual repo in later task

---

### PHASE 5: TEST REPOSITORY

- TASK 12a: CREATE TEST REPOSITORY
    - OBJECTIVE: Create a test repository with intentional security issues
      to validate our extractors.
    - COMMANDS: Refer to `README.md` in **test_repo** GitHub repository

- TASK 12b: TEST EXTRACTORS:
    - **Test secrets extractor**
        ```bash
          uv run python src/extractors/extract_secrets.py \
          tests/test_repo \
          main \
          feature-with-issues \
          output/test_secrets.json
        ```
    - **Test structure extractor**
        ```bash
          uv run python src/extractors/extract_structure.py \
          tests/test_repo \
          main \
          feature-with-issues \
          output/test_structure.json
        ```
    - **Test dependency extractor**
        ```bash
          uv run python src/extractors/extract_dependencies.py \
          tests/test_repo \
          main \
          feature-with-issues \
          output/test_dependencies.json
        ```      

---

### PHASE 6: LLM INTEGRATION

- TASK 13: Create LLM Prompt Templates
    - FILE: `llm/prompts.py`

- TASK 14: Create LLM Triage Agent
    - FILE: `llm/triage_agent.py`

  - TEST:
      - First ensure you have metadata from test repo
        (Should have run extractors in Task 12)
          - RUN LLM Triage
            ```bash
                uv run python ./src/llm/triage_agent.py \
                ./output/test_secrets.json \
                ./output/test_structure.json \
                ./output/test_dependencies.json \
                ./output/test_risk_assessment.json
            ```
          >   **EXPECTED OUTPUT**<br/>
          >  - 🤖 Calling Claude API for risk assessment... <br/>
              - Attempt 1/3 <br/>
              - ✅ Valid risk assessment generated<br/><br/>

          >   **✅ Risk assessment complete:**
          >    - Overall risk: HIGH
          >    - Risk score: 75/100
          >    - Findings: 3-4
          >    - Allow merge: False
          >    - Output: output/test_risk_assessment.json

          >   **SUCCESS CRITERIA** <br/>
          >    - ✅ LLM responds with valid JSON
          >    - ✅ JSON validates against risk_assessment schema
          >    - ✅ LLM identifies secrets, complexity, and vulnerability issues
          >    - ✅ LLM recommends blocking merge

  - TEST (OPEN AI): Direct usage (without run.py)
    ```bash
       uv run python ./src/llm/triage_agent_openai.py \
       ./output/test_secrets.json \
       ./output/test_structure.json \
       ./output/test_dependencies.json \
       ./output/test_risk_assessment.json \
       gpt-4-turbo-preview
    ```

---

### PHASE 7: REPORT GENERATION

- TASK 15: Create Report Generator
    - FILE: `reporters/generate_report.py`
    - TEST:
         ```bash
            uv run python ./src/reporters/generate_report.py \
            ./output/test_risk_assessment.json \
            ./output/test_report.md \
            ./output/test_summary.txt
         ```
- 
---

### PHASE 8: MAIN ORCHESTRATOR

- TASK 16: Create Main Orchestrator Script
    - FILE: `run.py`
    - TEST:
        - Use OpenAI with default model (gpt-4-turbo-preview)
          ```bash
             uv run python ./src/run.py \
             --repo tests/test_repo \
             --base main \
             --head feature-with-issues \
             --llm openai
           ```
        - Use OpenAI with specific model
          ```bash
             uv run python ./src/run.py \
             --repo tests/test_repo \
             --base main \
             --head feature-with-issues \
             --llm openai \
             --model gpt-4-0125-preview 
           ```
        - Use cheaper/faster GPT-3.5
          ```bash
             uv run python ./src/run.py \
             --repo tests/test_repo \
             --base main \
             --head feature-with-issues \
             --llm openai \
             --model gpt-3.5-turbo
           ```
        - Use Claude
          ```bash
             uv run python ./src/run.py \
             --repo tests/test_repo \
             --base main \
             --head feature-with-issues 
           ```
        - Use Claude with specific model
          ```bash
             uv run python ./src/run.py \
             --repo tests/test_repo \
             --base main \
             --head feature-with-issues \
             --llm claude \
             --model claude-3-5-sonnet-20241022
           ``` 
-
---

## 📌 FAQ

#### Regenerate the lock after updating pyproject.toml:

```bash
uv lock --upgrade
uv sync
```

#### If you want to force just one dependency line to move:

```bash
uv lock --upgrade-package openai-agents
uv sync
```
