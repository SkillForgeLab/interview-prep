# client/src/main.py
"""
MCP Client — Streamable HTTP transport.

Connects to the MCP server, calls its streaming tool,
and receives progress notifications before the final result.
"""
import asyncio
import logging
import os

from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client
from mcp.types import CallToolResult, TextContent

from src.logging_config import setup_logging

# ── Logging ──────────────────────────────────────────────
setup_logging()
logger = logging.getLogger("mcp-client")

# ── Config ───────────────────────────────────────────────
SERVER_URL = os.getenv("MCP_SERVER_URL", "http://localhost/mcp")


async def handle_progress(
    progress: float,
    total: float | None,
    message: str | None,
) -> None:
    """Log progress notifications as they arrive."""
    logger.info(
        "Progress",
        extra={
            "progress": progress,
            "total": total,
            "progress_message": message,
        },
    )


def text_result(result: CallToolResult) -> str:
    """Extract the first text block from a tool result."""
    for block in result.content:
        if isinstance(block, TextContent):
            return block.text
    return "<tool returned no text>"


async def main() -> None:
    logger.info("Client starting", extra={"server": SERVER_URL})

    # ── Open a Streamable HTTP session ───────────────────
    # streamable_http_client is the transport layer.
    # ClientSession is the MCP protocol layer on top.
    async with streamable_http_client(SERVER_URL) as (
        read_stream,
        write_stream,
        _,              # unused: get_session_id callable
    ):
        async with ClientSession(read_stream, write_stream) as session:
            # ── Capability negotiation ───────────────────
            # initialize() exchanges protocol versions and
            # capability lists with the server.
            await session.initialize()
            logger.info("Session initialized")

            # ── List available tools ─────────────────────
            tools = await session.list_tools()
            logger.info(
                "Tools available",
                extra={"tools": [t.name for t in tools.tools]},
            )

            # ────────────────────────────────────────────
            # TOOL 1: stream_numbers
            # ────────────────────────────────────────────
            logger.info("Calling stream_numbers_tool (count=5)")

            # Progress events are delivered as notifications
            # on the read_stream between chunks; the SDK
            # surfaces them via the on_progress callback if set.
            result1 = await session.call_tool(
                "stream_numbers_tool",
                arguments={"count": 5},
                progress_callback=handle_progress,
            )
            logger.info(
                "stream_numbers_tool result",
                extra={"result": text_result(result1)},
            )

    logger.info("Client done")


if __name__ == "__main__":
    asyncio.run(main())
