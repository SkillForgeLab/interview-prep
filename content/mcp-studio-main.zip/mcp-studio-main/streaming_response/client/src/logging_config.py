"""Client logging that renders fields supplied through ``extra``."""

import json
import logging


class ExtraFormatter(logging.Formatter):
    """Append nonstandard LogRecord attributes as JSON."""

    _standard_fields = frozenset(logging.makeLogRecord({}).__dict__) | {
        "asctime",
        "message",
    }

    def format(self, record: logging.LogRecord) -> str:
        rendered_message = super().format(record)
        extra_fields = {
            key: value
            for key, value in record.__dict__.items()
            if key not in self._standard_fields
        }
        if not extra_fields:
            return rendered_message
        return f"{rendered_message} {json.dumps(extra_fields, default=str)}"


def setup_logging() -> None:
    """Configure logging with human-readable messages and JSON fields."""
    handler = logging.StreamHandler()
    handler.setFormatter(
        ExtraFormatter("%(asctime)s [%(levelname)s] %(name)s — %(message)s")
    )
    logging.basicConfig(level=logging.INFO, handlers=[handler], force=True)
