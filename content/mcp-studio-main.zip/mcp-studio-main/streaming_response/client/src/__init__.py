"""Streamable HTTP MCP client package."""
