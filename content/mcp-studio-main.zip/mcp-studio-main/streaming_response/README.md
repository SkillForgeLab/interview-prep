## How to run

Open three terminals and run the services in dependency order from the
repository root.

### Terminal 1 — server:

```shell
docker compose -f streaming_response/docker-compose.yaml up --build server
```

Wait until you see:

```text
Uvicorn running on http://0.0.0.0:8000
```

### Terminal 2 — nginx:

```shell
docker compose -f streaming_response/docker-compose.yaml up nginx
```

Wait until you see:

```text
Configuration complete; ready for start up
```

### Alternatively, 
#### Start the persistent services (server nginx) in the background:
```shell
docker compose -f streaming_response/docker-compose.yaml up --build -d server nginx
```

### Terminal 3 — client (mcp):

```shell
docker compose -f streaming_response/docker-compose.yaml run --rm client
```

Use `run --rm` for the client because it is a one-shot program that exits after
calling the MCP tool. You can rerun that command repeatedly.

### Terminal 3 — client (REST):
```shell
curl -N \
  -X POST http://localhost/api/v1/stream \
  -H 'Content-Type: application/json' \
  -d '{"count": 3}'
```

## Useful Commands

**Show container status**
```shell
docker compose -f streaming_response/docker-compose.yaml ps
```

**Follow all logs**
```shell
docker compose -f streaming_response/docker-compose.yaml logs -f
```

**Stop and remove the stack**
```shell
docker compose -f streaming_response/docker-compose.yaml down
```