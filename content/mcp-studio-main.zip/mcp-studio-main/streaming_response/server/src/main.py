# server/src/main.py
"""
FastAPI application hosting a FastMCP Streamable HTTP server.

🔑 Jargon: Streamable HTTP Transport — an MCP transport
           where each tool call is a single HTTP POST
           that can stream SSE events back to the client
           before sending the final HTTP response.
"""
from contextlib import asynccontextmanager
import json
import logging
import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from mcp.server.fastmcp import Context, FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from pydantic import BaseModel, Field

from src.logging_config import setup_logging
from src.services.number_stream import generate_number_progress
from src.tools.stream_tool import stream_numbers

# ── Bootstrap ────────────────────────────────────────────
load_dotenv()
setup_logging(os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

# ── Create the MCP server instance ───────────────────────
# FastMCP owns the MCP protocol implementation.
# The name appears in MCP capability negotiation.
mcp = FastMCP(
    name="streamable-http-server",
    transport_security=TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=["nginx", "localhost:*", "127.0.0.1:*"],
        allowed_origins=[],
    ),
)

# ── Register tools ───────────────────────────────────────
# @mcp.tool() binds the function as an MCP tool.
# The docstring becomes the tool description sent to clients.

@mcp.tool(description="Stream N numbered chunks to the client.")
async def stream_numbers_tool(count: int, ctx: Context) -> str:
    """Delegates to the stream_numbers implementation."""
    return await stream_numbers(count, ctx)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """Start and stop FastMCP resources with the FastAPI application."""
    logger.info("Starting MCP session manager", extra={"path": "/mcp"})
    async with mcp.session_manager.run():
        yield
    logger.info("MCP session manager stopped")


# FastAPI owns the application lifecycle.
app = FastAPI(title="Streamable HTTP MCP Server", lifespan=lifespan)


class StreamRequest(BaseModel):
    """Input accepted by the conventional REST streaming endpoint."""

    count: int = Field(ge=1, le=20)


@app.post("/api/v1/stream")
async def stream_endpoint(request: StreamRequest) -> StreamingResponse:
    """Stream progress as Server-Sent Events without requiring MCP."""

    async def events():
        async for event in generate_number_progress(request.count):
            payload = json.dumps(
                {
                    "progress": event.current,
                    "total": event.total,
                    "message": f"chunk {event.current}/{event.total}",
                }
            )
            yield f"event: progress\ndata: {payload}\n\n"

        completed = json.dumps(
            {"message": f"Streamed {request.count} chunks successfully."}
        )
        yield f"event: complete\ndata: {completed}\n\n"

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# FastMCP handles MCP protocol requests at /mcp.
app.mount("/", mcp.streamable_http_app())
