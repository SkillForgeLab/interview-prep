"""Streamable HTTP MCP server package."""
