# server/src/logging_config.py
import json
import logging
import sys
from datetime import datetime, timezone


class JSONFormatter(logging.Formatter):
    """
    Structured JSON log formatter.
    Every log line is a valid JSON object.
    """

    def format(self, record: logging.LogRecord) -> str:
        # Build a structured log record dict
        log_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level":     record.levelname,
            "logger":    record.name,
            "message":   record.getMessage(),
        }
        # Attach fields supplied through logging's extra={...}.
        standard_fields = {
            "args", "asctime", "created", "exc_info", "exc_text", "filename",
            "funcName", "levelname", "levelno", "lineno", "message", "module",
            "msecs", "msg", "name", "pathname", "process", "processName",
            "relativeCreated", "stack_info", "taskName", "thread", "threadName",
        }
        log_record.update(
            key_value
            for key_value in record.__dict__.items()
            if key_value[0] not in standard_fields
        )
        return json.dumps(log_record)


def setup_logging(level: str = "INFO") -> None:
    """Configure root logger to emit JSON to stdout."""
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        handlers=[handler],
    )
