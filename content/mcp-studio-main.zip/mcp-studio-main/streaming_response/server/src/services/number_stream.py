"""Shared number-streaming logic used by MCP and REST transports."""

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass


@dataclass(frozen=True)
class NumberProgress:
    """One progress update produced by the number stream."""

    current: int
    total: int


async def generate_number_progress(count: int) -> AsyncIterator[NumberProgress]:
    """Generate observable progress events for a bounded number stream."""
    bounded_count = max(1, min(count, 20))

    for current in range(1, bounded_count + 1):
        yield NumberProgress(current=current, total=bounded_count)
        await asyncio.sleep(0.3)
