"""Transport-independent application services."""
