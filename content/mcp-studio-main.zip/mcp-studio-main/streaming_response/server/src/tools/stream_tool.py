# server/src/tools/stream_tool.py
"""
Tool 1 — stream_numbers
-----------------------
Server streams N numbered chunks to the client.
Each chunk is a separate SSE event sent over the
same HTTP request (Streamable HTTP transport).

🔑 Jargon: SSE — Server-Sent Events: a one-way stream
           of text messages pushed from server → client
           over a persistent HTTP connection.
"""
import logging

from mcp.server.fastmcp import Context  # per-request context

from src.services.number_stream import generate_number_progress

logger = logging.getLogger(__name__)


async def stream_numbers(count: int, ctx: Context) -> str:
    """
    Stream `count` numbers back to the caller.

    Args:
        count: How many numbers to stream (1–20).
        ctx:   MCP request context — used to send
               progress notifications mid-stream.

    Returns:
        A final summary string after streaming completes.
    """
    logger.info(
        "stream_numbers called",
        extra={"count": count},
    )

    total = 0
    async for event in generate_number_progress(count):
        total = event.total
        # Send a progress notification to the client.
        # This triggers a streaming chunk over SSE.
        await ctx.report_progress(
            progress=event.current,
            total=event.total,
            message=f"chunk {event.current}/{event.total}",
        )

    logger.info("stream_numbers complete", extra={"count": total})
    # Final return value — sent as the tool result
    return f"Streamed {total} chunks successfully."
