# Streamable HTTP and Elicitation with MCP

This guide explains the `streamable_elicitation` example from first principles. It covers Docker, nginx, ASGI, Starlette, FastMCP, progress notifications, elicitation, and the MCP client/server request flow.

## 1. What the application does

The example contains three programs:

1. An MCP client that discovers and calls tools.
2. An MCP server that implements those tools.
3. An nginx reverse proxy between the client and server.

All three run in Docker containers connected to the same Docker network.

```mermaid
flowchart LR
    C["MCP client"] -->|"http://nginx/mcp"| N["nginx port 80"]
    N -->|"http://server:8000/mcp"| S["MCP server"]
    S --> T1["stream_numbers_tool"]
    S --> T2["elicit_and_stream"]
```

The client performs two calls:

- `stream_numbers_tool(count=5)` sends five progress notifications and then a final result.
- `elicit_and_stream()` asks the client for a batch size, streams that many progress notifications, and then returns a final result.

## 2. What MCP is

MCP stands for **Model Context Protocol**. A protocol is an agreed-upon set of message formats and behaviors.

MCP defines operations such as:

- Initialize a client/server session.
- Ask a server which tools it provides.
- Call a tool using JSON arguments.
- Return text, images, audio, resources, or errors.
- Report progress while a tool is running.
- Ask the client for additional information through elicitation.

Because both programs understand MCP, the client does not need a custom HTTP API for every server tool.

## 3. End-to-end request flow

```mermaid
sequenceDiagram
    participant C as "MCP client"
    participant N as "nginx"
    participant S as "MCP server"

    C->>N: Connect to /mcp
    N->>S: Forward to server:8000/mcp
    C->>S: Initialize session
    C->>S: List tools
    C->>S: Call stream_numbers_tool(count=5)
    loop Five iterations
        S-->>C: Progress notification
    end
    S-->>C: Final tool result

    C->>S: Call elicit_and_stream
    S-->>C: Request batch_size
    C-->>S: Accept with batch_size=3
    loop Three iterations
        S-->>C: Progress notification
    end
    S-->>C: Final tool result
```

Progress notifications are not partial tool return values. The tool still produces one final MCP result. Progress is a separate notification channel that tells the client what is happening before the final result is ready.

## 4. Docker and Docker Compose

The Compose file is `streamable_elicitation/docker-compose.yaml`.

### Server container

```yaml
server:
  build: ./server
  expose:
    - "8000"
```

`build: ./server` tells Docker Compose to use the Dockerfile in the server directory.

`expose: 8000` makes port 8000 available to other containers. It does not publish that port directly on the host machine.

### nginx container

```yaml
nginx:
  image: nginx:alpine
  ports:
    - "80:80"
```

The port mapping means:

```text
host port 80 -> nginx container port 80
```

nginx is the public entry point. The Python server remains internal to the Docker network.

### Client container

```yaml
client:
  environment:
    MCP_SERVER_URL: http://nginx/mcp
```

Docker Compose provides internal DNS. A service can reach another service using its Compose service name.

Therefore:

- `nginx` resolves to the nginx container.
- `server` resolves to the server container.
- `localhost` inside the client would refer to the client itself, not nginx or the server.

### Shared network

All services join `mcp-net`:

```yaml
networks:
  mcp-net:
    driver: bridge
```

Containers must share a network before they can resolve one another by service name.

### Health checks and startup order

Starting a container does not guarantee that its application is ready. The Compose configuration therefore waits for:

```text
server healthy -> nginx healthy -> start client
```

The server health check opens a TCP connection to port 8000. nginx exposes `/health`, and its health check requests that endpoint.

Without these checks, the client can start first and receive `502 Bad Gateway` or `Connection refused` while the server is still booting.

## 5. The Dockerfiles

The server Dockerfile starts from a minimal Python image:

```dockerfile
FROM python:3.14.3-slim
```

It installs `uv`, copies the dependency manifest, and installs the project:

```dockerfile
RUN pip install --no-cache-dir uv
COPY pyproject.toml .
RUN uv pip install --system --no-cache .
```

The dependency manifest is copied before the source code so Docker can reuse the dependency layer when only application code changes.

The source is copied afterward:

```dockerfile
COPY src/ ./src/
```

The server starts with:

```dockerfile
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000", "--log-level", "info"]
```

This tells Uvicorn to:

- Import `app` from `src/main.py`.
- Listen on all container network interfaces.
- Accept connections on port 8000.

The JSON-array `CMD` is kept on one physical line. Splitting it across Dockerfile lines without continuation characters causes Docker to interpret an argument such as `--host` as a new Dockerfile instruction.

The client container is a one-shot program:

```dockerfile
CMD ["python", "src/main.py"]
```

It runs its calls and then exits.

## 6. nginx reverse proxy

The nginx configuration declares the Python backend:

```nginx
upstream mcp_backend {
  server server:8000;
}
```

It forwards MCP requests:

```nginx
location /mcp {
  proxy_pass http://mcp_backend;
}
```

The effective route is:

```text
http://nginx/mcp -> http://server:8000/mcp
```

These settings are important for progress delivery:

```nginx
proxy_buffering off;
proxy_cache off;
proxy_read_timeout 300s;
```

If buffering were enabled, nginx could collect several events before forwarding them. Disabling buffering allows the client to observe progress as it happens.

## 7. Uvicorn, ASGI, Starlette, and FastMCP

The server-side stack is:

```text
HTTP connection
    -> Uvicorn
    -> ASGI interface
    -> Starlette application
    -> FastMCP protocol handler
    -> Python tool function
```

### Uvicorn

Uvicorn is the network server. It listens for HTTP connections and passes requests into the Python application.

### ASGI

ASGI is a standard interface between asynchronous Python web servers and Python web applications. It lets Uvicorn run applications written with Starlette, FastAPI, and other compatible frameworks.

### Starlette

FastMCP creates a complete Starlette ASGI application:

```python
app: Starlette = mcp.streamable_http_app()
```

The `: Starlette` portion is a type annotation. It helps editors and static type checkers but does not change the runtime value.

### FastMCP

FastMCP implements the MCP protocol. It handles session initialization, tool discovery, tool calls, notifications, elicitation, and result serialization.

## 8. Why use the generated Starlette app directly?

For a server that only exposes MCP, this is the simplest arrangement:

```python
app: Starlette = mcp.streamable_http_app()
```

It provides:

- The `/mcp` endpoint.
- MCP request handling.
- MCP session management.
- The correct application lifespan.
- Fewer routing and startup details to configure manually.

### Why not use a naive FastAPI mount?

This looks reasonable but has traps:

```python
app = FastAPI()
app.mount("/mcp", mcp.streamable_http_app())
```

First, the generated MCP app already uses `/mcp` by default. Mounting it at `/mcp` can produce:

```text
/mcp + /mcp = /mcp/mcp
```

Second, the MCP session manager has startup and shutdown work. A mounted sub-application's lifespan is not automatically composed with the parent application in the way developers often expect. Routes may exist while the session manager is not running.

### When a FastAPI parent is appropriate

Use a FastAPI parent when the same process must expose ordinary API routes as well as MCP:

```text
/health
/users
/orders
/mcp
```

A correct integration explicitly manages the MCP lifespan and avoids duplicating the path:

```python
from contextlib import asynccontextmanager

from fastapi import FastAPI
from mcp.server.fastmcp import FastMCP
from starlette.routing import Mount

mcp = FastMCP(
    name="my-server",
    streamable_http_path="/",
)


@mcp.tool()
async def hello(name: str) -> str:
    return f"Hello, {name}"


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with mcp.session_manager.run():
        yield


app = FastAPI(
    lifespan=lifespan,
    routes=[Mount("/mcp", app=mcp.streamable_http_app())],
)


@app.get("/health")
async def health():
    return {"status": "ok"}
```

Here:

- FastAPI owns the top-level application.
- `streamable_http_path="/"` prevents `/mcp/mcp`.
- `Mount("/mcp", ...)` exposes MCP at `/mcp`.
- The FastAPI lifespan explicitly runs the MCP session manager.

The current example does not need ordinary Python HTTP routes because nginx already provides `/health`. Using FastMCP's generated Starlette application directly is therefore the smaller and clearer design.

## 9. Creating the MCP server

The server instance is created with:

```python
mcp = FastMCP(
    name="streamable-elicitation-server",
    transport_security=TransportSecuritySettings(...),
)
```

The name is included in the initialization information sent to clients.

The transport-security settings validate HTTP `Host` headers:

```python
allowed_hosts=["nginx", "localhost:*", "127.0.0.1:*"]
```

This permits the Docker proxy and local development addresses while retaining DNS-rebinding protection.

## 10. Tool definitions and dependency injection

The decorator registers a Python function as an MCP tool:

```python
@mcp.tool(description="Stream N numbered chunks to the client.")
async def stream_numbers_tool(count: int, ctx: Context) -> str:
    return await stream_numbers(count, ctx)
```

FastMCP uses the function signature to build the tool schema:

- `count: int` becomes a client-supplied integer argument.
- `-> str` describes the return type.
- `ctx: Context` is special and is injected by FastMCP.

The client sends only:

```json
{"count": 5}
```

FastMCP creates `ctx` for the current request. The context provides operations such as progress reporting and elicitation.

## 11. Asynchronous Python

An asynchronous function is declared with `async def`:

```python
async def stream_numbers(...):
```

`await` pauses the current function until an asynchronous operation finishes, while allowing the event loop to handle other work.

For example:

```python
await asyncio.sleep(0.3)
```

This delays the current tool without blocking the entire server process.

## 12. Progress notifications

The helper limits the requested count:

```python
count = max(1, min(count, 20))
```

Examples:

```text
-5  -> 1
8   -> 8
100 -> 20
```

It reports each step:

```python
await ctx.report_progress(
    progress=i,
    total=count,
    message=f"chunk {i}/{count}",
)
```

For `count=3`, the client receives approximately:

```text
1 / 3 - chunk 1/3
2 / 3 - chunk 2/3
3 / 3 - chunk 3/3
```

The final tool result is separate:

```python
return f"Streamed {count} chunks successfully."
```

## 13. Elicitation

Elicitation lets the server ask the client for information during a tool call.

The server first describes the expected response with Pydantic:

```python
class BatchRequest(BaseModel):
    batch_size: int = Field(default=3, ge=1, le=20)
```

This says that `batch_size` must be an integer from 1 through 20.

The tool sends the request:

```python
result = await ctx.elicit(
    message="How many numbered chunks should the server stream?",
    schema=BatchRequest,
)
```

The server pauses while the client chooses one of three actions:

- `accept`: return valid data.
- `decline`: refuse the request.
- `cancel`: stop the interaction.

If accepted, the validated value is available as:

```python
result.data.batch_size
```

## 14. The client session

The client opens the Streamable HTTP transport:

```python
async with streamablehttp_client(SERVER_URL) as (
    read_stream,
    write_stream,
    _,
):
```

Conceptually:

- `read_stream` carries messages arriving from the server.
- `write_stream` carries messages going to the server.
- The unused third value provides access to the transport session ID.

The protocol session is created over those streams:

```python
async with ClientSession(
    read_stream,
    write_stream,
    elicitation_callback=handle_elicit,
) as session:
```

The transport moves bytes and HTTP messages. `ClientSession` understands their MCP meaning.

## 15. Initialization and tool discovery

The client initializes the session:

```python
await session.initialize()
```

This handshake exchanges information such as protocol versions, identities, and supported capabilities.

The client then asks for the tool catalog:

```python
tools = await session.list_tools()
```

FastMCP generates this catalog from the decorated Python functions.

## 16. Calling tools from the client

The first call supplies an argument and a progress callback:

```python
result1 = await session.call_tool(
    "stream_numbers_tool",
    arguments={"count": 5},
    progress_callback=handle_progress,
)
```

Whenever the server calls `ctx.report_progress()`, the SDK invokes `handle_progress()`.

The elicitation tool requires no initial arguments:

```python
result2 = await session.call_tool(
    "elicit_and_stream",
    progress_callback=handle_progress,
)
```

During that call, the server sends an elicitation request and the SDK invokes the registered elicitation callback.

## 17. The elicitation callback

The demonstration client always accepts with a batch size of three:

```python
reply = {"batch_size": 3}
return ElicitResult(action="accept", content=reply)
```

In a real client, the callback might:

- Display a form to a user.
- Ask for input in a terminal.
- Read application configuration.
- Ask an AI model to choose a value.

The code is the source of truth: despite an older comment mentioning different behavior on subsequent requests, the current callback always accepts with `batch_size=3`.

## 18. MCP result content

An MCP tool result can contain different block types, including text, images, audio, and resources.

The client safely searches for text:

```python
for block in result.content:
    if isinstance(block, TextContent):
        return block.text
```

This is safer than assuming that `result.content[0]` is always a text block.

## 19. Structured logging

The server converts log records into JSON:

```json
{
  "timestamp": "2026-07-29T01:46:54.217028+00:00",
  "level": "INFO",
  "logger": "src.tools.stream_tool",
  "message": "stream_numbers called",
  "count": 3
}
```

Structured logs are easier for log systems to index and query. A system can search directly for fields such as `level`, `logger`, or `count` instead of parsing arbitrary text.

## 20. Python packaging configuration

Each `pyproject.toml` declares the project dependencies and build backend.

For example:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src"]
```

The Hatch configuration explicitly tells the build system which Python package directory belongs in the wheel. Without it, Hatch cannot infer a package named `mcp_server` or `mcp_client` from a directory named `src`, and the Docker build fails.

## 21. Running the example

From the repository root:

```bash
docker compose -f streaming_response/docker-compose.yaml up --build
```

Expected sequence:

1. The server starts and becomes healthy.
2. nginx starts and becomes healthy.
3. The client initializes an MCP session.
4. The client discovers two tools.
5. The first tool emits five progress notifications.
6. The second tool asks for a batch size.
7. The client accepts with `batch_size=3`.
8. The server emits three progress notifications.
9. The client receives the final result and exits.

Stop and remove the Compose containers with:

```bash
docker compose -f streaming_response/docker-compose.yaml down
```

## 22. Key ideas to remember

- Docker containers are isolated processes; Compose networks let them communicate.
- Docker service names act as internal hostnames.
- nginx forwards public requests to the internal Python server.
- Uvicorn runs the ASGI application.
- FastMCP generates a Starlette application and implements MCP behavior.
- A type-annotated `Context` is injected by FastMCP rather than supplied by the client.
- Progress notifications are separate from the final tool result.
- Elicitation allows a server to request validated information from a client.
- Application lifespan is essential for MCP session management.
- Use the generated Starlette app directly for an MCP-only process.
- Use a FastAPI parent when the same process also needs ordinary HTTP endpoints, but explicitly compose the MCP lifespan and routing.
