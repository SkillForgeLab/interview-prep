# Streaming Responses with FastAPI and MCP

This guide explains the `streaming_response` example from first principles. It
is intended for developers who are comfortable reading basic Python but are new
to the Model Context Protocol (MCP), asynchronous generators, Server-Sent
Events (SSE), and container networking.

## 1. What this project demonstrates

The project exposes one operation—streaming numbered progress updates—through
two interfaces:

1. An MCP tool for MCP-aware clients and AI applications.
2. A conventional REST endpoint for tools such as `curl` and ordinary HTTP
   applications.

Both interfaces use the same transport-independent Python service. This is
important: the MCP tool and REST endpoint are adapters around shared application
logic rather than separate implementations.

```mermaid
flowchart TD
    MC["MCP client"] -->|" MCP messages at /mcp "| N["nginx"]
    RC["REST client or curl"] -->|" POST /api/v1/stream "| N
    N --> F["FastAPI application"]
    F --> MA["FastMCP tool adapter"]
    F --> RA["REST SSE adapter"]
    MA --> S["Shared number-stream service"]
    RA --> S
```

```
MCP client → MCP adapter ─┐
                         ├→ shared streaming service
REST client → REST adapter┘
```

The source code is organized as follows:

```text
streaming_response/
├── docker-compose.yaml
├── nginx/
│   └── nginx.conf
├── server/
│   ├── Dockerfile
│   ├── pyproject.toml
│   └── src/
│       ├── main.py
│       ├── logging_config.py
│       ├── services/
│       │   └── number_stream.py
│       └── tools/
│           └── stream_tool.py
└── client/
    ├── Dockerfile
    ├── pyproject.toml
    └── src/
        ├── main.py
        └── logging_config.py
```

## 2. What MCP is

MCP stands for **Model Context Protocol**. A protocol is an agreed-upon set of
messages and rules that allows independent programs to communicate.

MCP defines operations such as:

- Initialize a client/server session.
- Discover the tools offered by a server.
- Call a tool by name with structured arguments.
- Return text, images, resources, or errors.
- Send progress notifications before a tool finishes.

An MCP tool is not the same thing as a REST endpoint. A REST client sends an
HTTP request to a URL chosen by the application, such as `/api/v1/stream`. 
An MCP client sends standardized JSON-RPC messages to an MCP endpoint, usually
`/mcp`.

The MCP SDK handles the protocol envelope, session ID, tool discovery, and
message parsing. Your code focuses on declaring tools and implementing their
behavior.

## 3. Progress is not the final tool result

The streaming tool sends two kinds of information:

1. Zero or more progress notifications while work is running.
2. One final tool result when the work is complete.

For `count=3`, the conceptual result is:

```text
Progress: 1 of 3
Progress: 2 of 3
Progress: 3 of 3
Final result: "Streamed 3 chunks successfully."
```

The progress messages are not pieces of the final string. They are separate
protocol notifications. This distinction lets a user interface display a
progress bar while still receiving one authoritative tool result at the end.

## 4. End-to-end MCP flow

The MCP client does more than send `{"count": 5}`. It first creates and
initializes an MCP session.

```mermaid
sequenceDiagram
    participant C as "MCP client"
    participant N as "nginx"
    participant F as "FastAPI and FastMCP"
    participant S as "Shared service"
    C ->> N: Initialize MCP session
    N ->> F: Forward POST /mcp
    F -->> C: Session and capabilities
    C ->> F: notifications/initialized
    C ->> F: tools/list
    F -->> C: stream_numbers_tool
    C ->> F: tools/call count=5
    F ->> S: generate_number_progress(5)
    loop Five events
        S -->> F: NumberProgress
        F -->> C: MCP progress notification
    end
    F -->> C: Final MCP tool result
```

The SDK hides most of the JSON-RPC details, but knowing this lifecycle explains
why an MCP endpoint cannot normally be called by posting only a tool argument.

## 5. Shared application logic

The transport-independent implementation is in
`server/src/services/number_stream.py`.

### The progress data class

```python
@dataclass(frozen=True)
class NumberProgress:
    current: int
    total: int
```

A data class is a convenient way to represent related values. A progress event
contains:

- `current`: the current step.
- `total`: the total number of steps.

`frozen=True` makes each event immutable after it is created. Consumers can read
it but cannot accidentally change it.

### The asynchronous generator

```python
async def generate_number_progress(
        count: int,
) -> AsyncIterator[NumberProgress]:
    bounded_count = max(1, min(count, 20))

    for current in range(1, bounded_count + 1):
        yield NumberProgress(current=current, total=bounded_count)
        await asyncio.sleep(0.3)
```

This function is both asynchronous and a generator:

- `async` allows the function to wait without blocking the entire server.
- `yield` produces one event at a time instead of building a complete list.
- `AsyncIterator[NumberProgress]` describes the sequence of values it produces.

The count is bounded between 1 and 20:

```text
count=-5  -> 1
count=8   -> 8
count=100 -> 20
```

The delay makes streaming observable. During `await asyncio.sleep(0.3)`,
Python's event loop can process other requests instead of freezing the server
thread.

Consumers read the generator using `async for`:

```python
async for event in generate_number_progress(5):
    print(event.current, event.total)
```

The service knows nothing about MCP, FastAPI, HTTP, or SSE. This makes it
reusable and easy to test.

## 6. The MCP tool adapter

The MCP-specific adapter is in `server/src/tools/stream_tool.py`.

```python
async def stream_numbers(count: int, ctx: Context) -> str:
    total = 0

    async for event in generate_number_progress(count):
        total = event.total
        await ctx.report_progress(
            progress=event.current,
            total=event.total,
            message=f"chunk {event.current}/{event.total}",
        )

    return f"Streamed {total} chunks successfully."
```

The adapter translates each transport-independent `NumberProgress` object into
an MCP progress notification.

`Context` is supplied by FastMCP for the current tool request. It provides
request-specific operations such as progress reporting and MCP logging. The
client does not pass the context in its arguments.

The function eventually returns a normal string. FastMCP turns that string into
an MCP tool result.

## 7. Registering the MCP tool

The MCP server is created in `server/src/main.py`:

```python
mcp = FastMCP(
    name="streamable-http-server",
    transport_security=TransportSecuritySettings(...),
)
```

The name identifies the server during MCP capability negotiation.

The Python function becomes a discoverable MCP tool through a decorator:

```python
@mcp.tool(description="Stream N numbered chunks to the client.")
async def stream_numbers_tool(count: int, ctx: Context) -> str:
    return await stream_numbers(count, ctx)
```

The decorator tells FastMCP to include this function in `tools/list`. FastMCP
uses the function signature to build the input schema:

- `count: int` is a client-provided integer.
- `ctx: Context` is injected by FastMCP.
- `-> str` describes the result type.

This registered function is intentionally thin. It delegates to the MCP adapter
instead of containing all application logic.

## 8. FastAPI lifespan and FastMCP

FastAPI owns the web application's startup and shutdown lifecycle:

```python
@asynccontextmanager
async def lifespan(_app: FastAPI):
    logger.info("Starting MCP session manager")
    async with mcp.session_manager.run():
        yield
    logger.info("MCP session manager stopped")
```

An asynchronous context manager has two phases:

```text
Code before yield  -> application startup
yield              -> application serves requests
Code after yield   -> application shutdown
```

FastMCP's session manager must remain active while MCP requests are processed.
Placing it around `yield` guarantees that it starts with FastAPI and shuts down
cleanly with FastAPI.

The FastAPI application is created with this lifespan:

```python
app = FastAPI(
    title="Streamable HTTP MCP Server",
    lifespan=lifespan,
)
```

FastMCP's ASGI application is mounted after the ordinary FastAPI routes:

```python
app.mount("/", mcp.streamable_http_app())
```

FastMCP uses `/mcp` as its Streamable HTTP path. Mounting its application at `/`
preserves that URL.

Route order matters because a mount at `/` can match every remaining path. The
REST endpoint is registered before the FastMCP application is mounted.

## 9. The REST streaming adapter

Not every caller understands MCP. The FastAPI route provides a conventional HTTP
interface:

```python
class StreamRequest(BaseModel):
    count: int = Field(ge=1, le=20)


@app.post("/api/v1/stream")
async def stream_endpoint(request: StreamRequest) -> StreamingResponse:
    ...
```

Pydantic validates the request body. Valid input looks like:

```json
{
  "count": 5
}
```

Values below 1 or above 20 receive a FastAPI validation response instead of
starting the stream.

The inner generator converts shared events into SSE text:

```python
async def events():
    async for event in generate_number_progress(request.count):
        payload = json.dumps(
            {
                "progress": event.current,
                "total": event.total,
                "message": f"chunk {event.current}/{event.total}",
            }
        )
        yield f"event: progress\ndata: {payload}\n\n"
```

An SSE message uses lines such as:

```text
event: progress
data: {"progress": 1, "total": 3, "message": "chunk 1/3"}

```

The blank line terminates one SSE event. `StreamingResponse` forwards each
yielded string without waiting for the complete generator:

```python
return StreamingResponse(
    events(),
    media_type="text/event-stream",
    headers={
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    },
)
```

The final SSE event has the type `complete`. As with the MCP tool, progress and
completion are distinct events.

## 10. MCP streaming versus REST SSE

Both interfaces ultimately travel over HTTP, but they expose different
contracts.

| Concern         | MCP interface                 | REST interface                    |
|-----------------|-------------------------------|-----------------------------------|
| URL             | `/mcp`                        | `/api/v1/stream`                  |
| Intended caller | MCP client or AI application  | Browser, service, or `curl`       |
| Discovery       | `tools/list`                  | OpenAPI or external documentation |
| Invocation      | `tools/call` JSON-RPC message | HTTP POST body                    |
| Progress        | MCP progress notification     | SSE `progress` event              |
| Completion      | MCP tool result               | SSE `complete` event              |
| Session         | MCP session required          | No application session required   |

The REST endpoint does not call the MCP endpoint internally. Doing that would
add an unnecessary network round trip and couple the REST API to MCP session
mechanics. Instead, both adapters call `generate_number_progress()` directly.

## 11. The MCP client

The client is implemented in `client/src/main.py`.

### Opening the transport

```python
async with streamable_http_client(SERVER_URL) as (
        read_stream,
        write_stream,
        _,
):
```

The transport carries MCP messages over HTTP:

- `read_stream` delivers messages from the server.
- `write_stream` sends messages to the server.
- The third value provides access to the session ID but is unused here.

### Creating and initializing a session

```python
async with ClientSession(read_stream, write_stream) as session:
    await session.initialize()
```

Initialization negotiates the MCP protocol version and supported capabilities.
Tool calls should happen only after this handshake.

### Discovering tools

```python
tools = await session.list_tools()
```

This asks the server for its tool definitions. The result includes
`stream_numbers_tool`, its description, and its input schema.

### Calling the tool

```python
result = await session.call_tool(
    "stream_numbers_tool",
    arguments={"count": 5},
    progress_callback=handle_progress,
)
```

The SDK sends a `tools/call` request. Whenever the server calls
`ctx.report_progress()`, the SDK invokes `handle_progress()`.

The returned tool content can contain several block types. The helper safely
finds a text block:

```python
for block in result.content:
    if isinstance(block, TextContent):
        return block.text
```

This avoids assuming that the first result block is always text.

## 12. nginx and streaming

nginx is the public entry point. It forwards both interfaces to the Python
server:

```text
/mcp  -> server:8000/mcp
/api/ -> server:8000/api/
```

The relevant configuration is:

```nginx
proxy_buffering off;
proxy_cache off;
proxy_read_timeout 300s;
```

Buffering is normally useful for conventional responses, but it can hide
incremental events by waiting for more data. Disabling it allows progress events
to reach the caller immediately.

The extended read timeout allows a long-running stream to remain open without
nginx closing it prematurely.

## 13. Docker networking

Docker Compose starts three services:

- `server`: FastAPI, FastMCP, and the shared service.
- `nginx`: reverse proxy exposed on host port 80.
- `client`: one-shot MCP client.

All services join `mcp-net`. Docker provides DNS using service names:

```text
client -> http://nginx/mcp
nginx  -> http://server:8000
```

Inside the client container, `localhost` means the client container itself. It
does not mean nginx or the server.

Health checks enforce this startup order:

```text
server healthy -> nginx healthy -> client may start
```

This prevents the client from racing a server that has started its container but
has not finished application startup.

## 14. Running the example

From the `mcp-studio` repository root, start the persistent services:

```bash
docker compose \
  -f streaming_response/docker-compose.yaml \
  up --build -d server nginx
```

Check their status:

```bash
docker compose \
  -f streaming_response/docker-compose.yaml \
  ps
```

### Call through MCP

Run the one-shot MCP client:

```bash
docker compose \
  -f streaming_response/docker-compose.yaml \
  run --rm client
```

Expected progress resembles:

```text
Progress 1/5: chunk 1/5
Progress 2/5: chunk 2/5
Progress 3/5: chunk 3/5
Progress 4/5: chunk 4/5
Progress 5/5: chunk 5/5
Streamed 5 chunks successfully.
```

### Call through REST

Use `curl -N` so curl does not buffer the stream:

```bash
curl -N \
  -X POST http://localhost/api/v1/stream \
  -H 'Content-Type: application/json' \
  -d '{"count": 3}'
```

Expected response:

```text
event: progress
data: {"progress": 1, "total": 3, "message": "chunk 1/3"}

event: progress
data: {"progress": 2, "total": 3, "message": "chunk 2/3"}

event: progress
data: {"progress": 3, "total": 3, "message": "chunk 3/3"}

event: complete
data: {"message": "Streamed 3 chunks successfully."}
```

### View logs

```bash
docker compose \
  -f streaming_response/docker-compose.yaml \
  logs -f server nginx
```

### Stop the project

```bash
docker compose \
  -f streaming_response/docker-compose.yaml \
  down
```

## 15. Why the design is useful

The project applies a useful architectural rule:

> Keep application behavior independent of the protocol used to expose it.

The shared service decides how progress is generated. The adapters decide how
progress is represented:

```text
Shared NumberProgress
        |
        +-- MCP adapter  -> ctx.report_progress(...)
        |
        +-- REST adapter -> event: progress / data: {...}
```

This separation provides several benefits:

- The core behavior is implemented once.
- MCP and REST cannot drift into different algorithms.
- The generator can be unit tested without starting a server.
- Another adapter, such as WebSocket or a background job, can reuse it.
- Transport-specific objects such as MCP `Context` do not leak into business
  logic.

## 16. Common beginner questions

### Is Streamable HTTP the same as SSE?

No. Streamable HTTP is an MCP transport that can use an SSE response stream when
incremental server-to-client messages are needed. SSE is the lower-level text
event format used for streaming those messages.

The REST endpoint also uses SSE, but it does not use the MCP protocol.

### Why use `asyncio.sleep()` instead of `time.sleep()`?

`time.sleep()` blocks the Python thread. `await asyncio.sleep()` pauses only the
current coroutine and lets the event loop serve other work.

### Why is there still one final MCP result?

Progress notifications describe intermediate state. The final tool result
communicates the completed outcome. A caller can ignore progress and still
receive a valid result.

### Why not have REST call the MCP tool over HTTP?

That would require REST requests to create MCP sessions and would add
serialization, network, and failure overhead inside the same application.
Calling the shared service directly is simpler.

### Why is FastMCP mounted at `/`?

FastMCP's generated application already handles `/mcp`. Mounting it at `/`
preserves the final path as `/mcp`. Mounting it at `/mcp` without adjusting
FastMCP's internal path could produce `/mcp/mcp`.

### Why register FastAPI routes before mounting FastMCP?

The FastMCP application is mounted at `/`, which is a broad route. Registering
`/api/v1/stream` first ensures FastAPI matches the specific REST route before
falling through to the mounted MCP application.

## 17. Suggested next steps

Once this example is comfortable, useful extensions include:

1. Add unit tests for `generate_number_progress()`.
2. Handle client disconnection in the REST generator.
3. Add authentication to both `/mcp` and `/api/`.
4. Add request IDs to logs.
5. Replace the artificial delay with real work.
6. Add metrics for active streams and duration.
7. Decide whether production deployment should use stateful or stateless MCP
   sessions.

The central idea remains the same: implement the behavior once, then expose it
through small, protocol-specific adapters.
