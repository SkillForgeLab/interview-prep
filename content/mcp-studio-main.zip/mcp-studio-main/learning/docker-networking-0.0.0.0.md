# Understanding `0.0.0.0`, `server:8000`, Docker Containers, and Uvicorn

This guide explains the networking behind the following configuration:

```dockerfile
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000", "--log-level", "info"]
```

It answers these questions:

- Why does Uvicorn use `0.0.0.0`?
- What does `server:8000` mean?
- What is the “server container”?
- Is the server Uvicorn, FastMCP, Starlette, or Docker?
- How does nginx find the Python application?
- Does `0.0.0.0` expose the application publicly?

## 1. The short answer

In this project:

- `server` is the Docker Compose service name and internal hostname.
- The server container is the isolated container created for that service.
- Uvicorn is the HTTP server process running inside the container.
- Starlette is the ASGI application hosted by Uvicorn.
- FastMCP is the MCP protocol implementation inside the Starlette application.
- `8000` is the container port on which Uvicorn listens.
- `0.0.0.0` tells Uvicorn to accept IPv4 connections through every network
  interface in its container.
- nginx connects to `server:8000`; Docker resolves `server` to the container's
  internal IP address.

```mermaid
flowchart TD
    C["MCP client container"] -->|" http://nginx/mcp "| N["nginx container"]
    N -->|" http://server:8000/mcp "| D["server container"]
    D --> U["Uvicorn"]
    U --> A["Starlette ASGI app"]
    A --> M["FastMCP"]
    M --> T["Python tool"]
```

## 2. What the Uvicorn command means

Consider the complete command:

```dockerfile
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000", "--log-level", "info"]
```

Each part has a specific purpose.

### `uvicorn`

Start the Uvicorn HTTP server process.

Uvicorn is responsible for:

- Opening a network socket.
- Listening for HTTP connections.
- Reading HTTP requests.
- Passing requests to the Python ASGI application.
- Sending the application's HTTP responses back to clients.

### `src.main:app`

Import the variable named `app` from the Python module `src.main`.

It corresponds to:

```text
src.main:app
│        │
│        └── Variable named app
└─────────── Python module src/main.py
```

The variable is defined as:

```python
app: Starlette = mcp.streamable_http_app()
```

### `--host 0.0.0.0`

Listen on every IPv4 network interface available inside the container.

### `--port 8000`

Listen for connections addressed to TCP port 8000.

### `--log-level info`

Emit informational messages as well as warnings and errors.

## 3. What “bind” and “listen” mean

Before a network program can receive connections,
it creates a socket and binds that socket to an address and port.

Conceptually, Uvicorn performs an operation like:

```text
bind(address="0.0.0.0", port=8000)
listen()
```

The address identifies one or more network interfaces.
The port identifies the application endpoint on those interfaces.

An address and port together are commonly written as:

```text
address:port
```

For example:

```text
127.0.0.1:8000
172.20.0.2:8000
```

## 4. A container has network interfaces

A Docker container is an isolated environment with its own process and
network namespaces.

From the application's perspective, it resembles a small machine
with its own network interfaces.

A server container might have addresses similar to:

```text
127.0.0.1   Loopback interface inside the container
172.20.0.2  Docker network interface assigned to the container
```

The exact `172.x.x.x` address is only an example.
Docker assigns the actual address when it creates the container.

## 5. `127.0.0.1` versus `0.0.0.0`

These addresses have different meanings when an application binds to them.

### Binding to `127.0.0.1`

```text
Uvicorn binds to 127.0.0.1:8000
```

This means Uvicorn accepts connections only through the container's loopback
interface.

Processes in the same container can connect to it, but nginx is in a different
container. nginx cannot enter the server container's loopback interface.

```mermaid
flowchart TD
    N["nginx container"] -. " cannot reach " .-> L["server container 127.0.0.1:8000"]
```

An important networking rule is:

> Every container has its own `localhost`.

Inside the nginx container, `localhost` refers to nginx.  
Inside the server container, `localhost` refers to the server container.

### Binding to `0.0.0.0`

```text
Uvicorn binds to 0.0.0.0:8000
```

When used as a binding address, `0.0.0.0` means every available local IPv4
interface.

Uvicorn can therefore accept connections arriving through:

```text
127.0.0.1:8000
172.20.0.2:8000
```

The Docker-network address is what allows nginx to reach Uvicorn from another
container.

## 6. Is `0.0.0.0` a destination address?

Normally, no.

`0.0.0.0` is used here as a wildcard binding address. 
It tells Uvicorn where to listen; it is not the name nginx uses to locate the application.

Uvicorn listens using:

```text
0.0.0.0:8000
```

nginx connects using:

```text
server:8000
```

Those values serve different purposes:

```text
0.0.0.0:8000  Local instruction: listen on all container IPv4 interfaces
server:8000   Remote destination: find the Compose service named server
```

## 7. What `server` means in Docker Compose

The Compose file contains:

```yaml
services:
  server:
    build: ./server
```

Here, `server` is the service name chosen by the developer.

Docker Compose uses that name in two ways:

1. It identifies the service in the Compose configuration.
2. It becomes an internal DNS hostname on shared Compose networks.

The name is not a special Docker keyword. It could be changed:

```yaml
services:
  mcp_backend:
    build: ./server
```

If renamed, nginx would connect to:

```text
mcp_backend:8000
```

The Uvicorn command could remain unchanged.

## 8. What the “server container” means

Docker Compose creates a container for the `server` service. That is what
“server container” refers to.

Conceptually, it contains:

```text
Server container
├── Minimal Linux filesystem
├── Python runtime
├── Installed dependencies
├── Application source under /app/src
└── Running Uvicorn process
    └── Starlette/FastMCP application
```

The container is not Uvicorn itself. The container is the isolated environment
in which Uvicorn runs.

Depending on the Compose project name, its generated container name may
resemble:

```text
streamable_elicitation-server-1
```

That generated name is different from the stable service hostname `server` used
by other containers.

## 9. How Docker resolves `server`

All three services join the same Compose network:

```yaml
networks:
  - mcp-net
```

Docker provides a DNS service on that network. When nginx asks for the address
of `server`, Docker returns the current internal IP of a container belonging to
that service.

Suppose Docker assigns this example address:

```text
172.20.0.2
```

The lookup behaves conceptually like:

```text
server:8000
    ↓ Docker DNS resolves server
172.20.0.2:8000
    ↓ Network connection enters the server container
Uvicorn accepts the connection on port 8000
```

Applications should use the service name rather than hard-coding the IP because
container IP addresses can change when containers are recreated.

## 10. Reading the nginx configuration precisely

The nginx configuration contains:

```nginx
upstream mcp_backend {
    server server:8000;
}
```

The repeated word `server` is confusing because each occurrence has a different
role:

```text
server server:8000;
│      │      │
│      │      └── TCP port where Uvicorn listens
│      └───────── Docker Compose service hostname
└──────────────── nginx configuration directive
```

The first `server` is nginx syntax meaning “declare an upstream server.”

The second `server` is the Docker Compose hostname.

nginx then forwards requests with:

```nginx
location /mcp {
    proxy_pass http://mcp_backend;
}
```

`mcp_backend` is the nginx upstream group name. It points to `server:8000`.

### What `proxy_pass` does

`proxy_pass` tells nginx where to forward a request that matches the surrounding
`location` block.

In this configuration:

```nginx
location /mcp {
    proxy_pass http://mcp_backend;
}
```

nginx follows this rule:

> When an HTTP request has a path beginning with `/mcp`, send that request to
> the upstream group named `mcp_backend`.

The upstream definition connects that group to the Python server:

```nginx
upstream mcp_backend {
    server server:8000;
}
```

The effective mapping is therefore:

```text
mcp_backend -> server:8000
```

For example, the client might send:

```http
POST /mcp HTTP/1.1
Host: nginx
Content-Type: application/json
```

nginx matches `location /mcp`, resolves the `mcp_backend` upstream, opens a
connection to `server:8000`, and forwards an equivalent request to Uvicorn.

```mermaid
flowchart LR
    C["MCP client"] -->|"POST http://nginx/mcp"| N["nginx"]
    N -->|"proxy_pass"| D["server:8000/mcp"]
    D --> U["Uvicorn"]
    U --> A["Starlette/FastMCP app"]
```

The response travels back through the same proxy in reverse:

```text
FastMCP -> Uvicorn -> nginx -> MCP client
```

nginx is acting as a reverse proxy because it receives requests on behalf of a
backend server. The client knows about nginx but does not need to know the
backend container's internal IP address.

### What `proxy_pass` does not do

`proxy_pass` does not start Uvicorn or the server container. It assumes that a
working HTTP server is already accepting connections at the configured
upstream address.

If Uvicorn is not running, has not finished starting, is listening on the wrong
port, or is bound only to `127.0.0.1`, nginx cannot reach it. nginx will commonly
respond to the client with:

```text
502 Bad Gateway
```

This means nginx received the client's request but could not obtain a valid
response from its configured backend.

### How the request path is handled

The current `proxy_pass` has no URI suffix:

```nginx
location /mcp {
    proxy_pass http://mcp_backend;
}
```

nginx preserves the original request path:

```text
Incoming path:  /mcp
Forwarded path: /mcp

Incoming path:  /mcp/example
Forwarded path: /mcp/example
```

Trailing slashes can change that behavior. For example:

```nginx
location /mcp/ {
    proxy_pass http://mcp_backend/;
}
```

Here nginx replaces the matching `/mcp/` prefix with `/`:

```text
Incoming path:  /mcp/example
Forwarded path: /example
```

The placement of trailing slashes in `location` and `proxy_pass` is therefore
significant.

### Why streaming-related proxy settings matter

The same location includes:

```nginx
proxy_buffering off;
proxy_cache off;
proxy_read_timeout 300s;
```

These settings complement `proxy_pass`:

- `proxy_buffering off` forwards streamed events promptly instead of collecting
  them into a larger buffered response.
- `proxy_cache off` prevents nginx from serving an old cached MCP response.
- `proxy_read_timeout 300s` allows a long-running tool to remain quiet for up to
  five minutes before nginx treats the backend as unresponsive.

### Why put nginx in front of Uvicorn?

The client could theoretically connect directly to `http://server:8000/mcp`
from the same Docker network. nginx provides a gateway where a production
system can centralize concerns such as:

- TLS and HTTPS termination.
- Authentication and authorization.
- Request logging.
- Timeouts and request-size limits.
- Rate limiting.
- Load balancing across multiple backend containers.
- Routing different URL paths to different applications.
- Buffering behavior for streamed responses.

## 11. The complete connection path

When the MCP client uses:

```text
http://nginx/mcp
```

the request travels through these layers:

```mermaid
sequenceDiagram
    participant C as "Client container"
    participant DD as "Docker DNS"
    participant N as "nginx container"
    participant S as "Server container"
    participant U as "Uvicorn"
    participant A as "Starlette/FastMCP app"
    C ->> DD: Resolve nginx
    DD -->> C: nginx container IP
    C ->> N: HTTP request to nginx:80/mcp
    N ->> DD: Resolve server
    DD -->> N: server container IP
    N ->> S: HTTP request to server:8000/mcp
    S ->> U: Connection reaches port 8000
    U ->> A: Pass request through ASGI
    A -->> U: Return MCP HTTP response
    U -->> N: HTTP response
    N -->> C: Proxied HTTP response
```

The phrase “nginx connects to the server container” therefore means:

1. nginx resolves the Compose hostname `server`.
2. Docker returns the server container's internal network address.
3. nginx opens a TCP connection to port 8000 at that address.
4. Uvicorn, which is listening on that port and interface, accepts the
   connection.

## 12. What “server” refers to at each layer

The word “server” is overloaded. Its meaning depends on context.

| Phrase                   | Precise meaning                                                   |
|--------------------------|-------------------------------------------------------------------|
| Compose `server` service | A service definition in `docker-compose.yaml`                     |
| `server` hostname        | The internal Docker DNS name for that service                     |
| Server container         | The isolated environment created for the Compose service          |
| Uvicorn server           | The HTTP server process listening on port 8000                    |
| Starlette application    | The ASGI web application hosted by Uvicorn                        |
| FastMCP server           | The MCP protocol implementation inside the application            |
| nginx `server` directive | nginx configuration syntax, unrelated to the Compose service name |

A precise description of this project is:

> nginx connects to the Docker Compose service named `server` on port 8000. The
> connection enters that service's container, where Uvicorn is listening and
> hosting a Starlette application created by FastMCP.

## 13. Does `0.0.0.0` make the application public?

Not by itself.

Three separate controls are involved.

### Application binding

```bash
uvicorn --host 0.0.0.0 --port 8000
```

This lets Uvicorn accept connections that reach the container on port 8000.

### Docker-internal availability

```yaml
expose:
  - "8000"
```

This documents and makes the server port available to connected containers. It
does not publish port 8000 directly on the host.

### Host port publishing

```yaml
ports:
  - "8000:8000"
```

This would publish the container's port 8000 on the host. The current server
service does not do this.

Instead, nginx publishes port 80:

```yaml
ports:
  - "80:80"
```

Therefore, the intended exposure is:

```text
Host/network clients -> nginx port 80 -> internal Uvicorn port 8000
```

Uvicorn is reachable from the Docker network, while nginx controls the
externally published entry point.

## 14. `expose` versus `ports`

These Compose settings are easy to confuse.

### `expose`

```yaml
expose:
  - "8000"
```

Meaning:

- The service uses port 8000 internally.
- Other containers on an appropriate network can connect.
- No host port is created by this setting.

### `ports`

```yaml
ports:
  - "8000:8000"
```

Meaning:

- Publish container port 8000 through host port 8000.
- A host process can connect to `localhost:8000`.
- Depending on host firewall and Docker settings, other machines may also be
  able to connect.

The current architecture publishes nginx, not Uvicorn, so all MCP traffic passes
through the reverse proxy.

## 15. A house analogy

The networking can be remembered with this analogy:

```text
Server container       = House
Docker internal IP     = Street address
Docker service name    = Name in the directory
Port 8000              = Door number
Uvicorn                 = Person answering the door
Starlette/FastMCP app   = Service provided inside
nginx                   = Front desk or gateway
```

nginx asks Docker's directory:

> Where is the house called `server`?

Docker returns the internal address. nginx goes to door 8000. Uvicorn answers
because it is listening on every container IPv4 interface at that port.

## 16. What would happen with different configurations?

### Uvicorn binds to `127.0.0.1`

```dockerfile
CMD ["uvicorn", "src.main:app", "--host", "127.0.0.1", "--port", "8000"]
```

Expected result:

- Code inside the server container can reach Uvicorn.
- nginx in another container cannot reach it through the Docker-network
  interface.
- nginx will usually report `Connection refused` or `502 Bad Gateway`.

### Uvicorn binds to `0.0.0.0`

```dockerfile
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Expected result:

- Uvicorn accepts connections through the container's loopback interface.
- Uvicorn also accepts connections through its Docker-network interface.
- nginx can connect to `server:8000`.

### nginx tries `localhost:8000`

```nginx
server localhost:8000;
```

Expected result:

- `localhost` refers to the nginx container.
- nginx looks for port 8000 inside its own container.
- Uvicorn is in another container, so the request fails.

### nginx uses `server:8000`

```nginx
server server:8000;
```

Expected result:

- Docker resolves `server` to the correct service container.
- nginx reaches Uvicorn through the shared Docker network.

## 17. IPv4 and IPv6 note

`0.0.0.0` is the wildcard address for IPv4.

The corresponding IPv6 wildcard address is:

```text
::
```

Whether an application should bind to IPv4, IPv6, or both depends on the runtime
and network configuration. This example's Docker network communication uses the
IPv4 binding successfully.

## 18. A debugging checklist

If nginx cannot reach Uvicorn, check the following in order:

1. Is the Uvicorn process running?
2. Is it listening on port 8000?
3. Is it bound to `0.0.0.0` rather than only `127.0.0.1`?
4. Are nginx and the server attached to the same Docker network?
5. Does nginx use the correct Compose service name?
6. Does nginx use the same port on which Uvicorn listens?
7. Did the server pass its health check before nginx started?
8. Does MCP transport security allow the forwarded `Host` header?

Useful Compose commands include:

```bash
docker compose -f streaming_response/docker-compose.yaml ps
docker compose -f streaming_response/docker-compose.yaml logs server
docker compose -f streaming_response/docker-compose.yaml logs nginx
```

## 19. Final mental model

Keep the following layers separate:

```text
Docker Compose service name: server
    ↓ resolves through Docker DNS
Server container's internal IP
    ↓ connection arrives at port 8000
Uvicorn HTTP server
    ↓ passes request through ASGI
Starlette application
    ↓ delegates MCP behavior
FastMCP
    ↓ calls
Python tool function
```

The central statement can now be read precisely:

> Uvicorn binds to `0.0.0.0:8000`, meaning it accepts IPv4 connections arriving
> at port 8000 through any interface in its container. nginx connects to
`server:8000`, where `server` is the Docker Compose service hostname. Docker
> resolves that hostname to the current internal address of the container created
> for the `server` service.
