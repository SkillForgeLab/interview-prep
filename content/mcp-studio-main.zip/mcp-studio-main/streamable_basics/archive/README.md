# MCP Lifecycle Studio

A runnable MCP client and FastAPI-hosted server that exposes what happens under
the hood. Every HTTP exchange and every client-side JSON-RPC message is written
as structured JSON, including the handshake, capability negotiation,
`notifications/initialized`, discovery, invocation, and transport teardown.

For a ground-up explanation of the protocol, code architecture, and every step
of the runtime path, read [Code Flow and Technical Concepts](docs/code-flow.md).

The project pins the latest stable releases available when it was created:
MCP Python SDK 1.28.1, FastAPI 0.139.2, and Uvicorn 0.51.0. MCP SDK 2.x was
still a prerelease and is intentionally not used.

## Run it

Install/sync dependencies:

```bash
UV_CACHE_DIR=/tmp/mcp-studio-uv-cache uv sync
```

Copy and customize the environment template:

```bash
cp .env.example .env
```

Both commands load `.env` automatically through `python-dotenv`. Values already
exported by the shell take precedence, and client command-line flags override
the client defaults.

Start the server in terminal 1:

```bash
UV_CACHE_DIR=/tmp/mcp-studio-uv-cache uv run mcp-studio-server
```

Run the lifecycle client in terminal 2:

```bash
UV_CACHE_DIR=/tmp/mcp-studio-uv-cache uv run mcp-studio-client
```

Try another tool call:

```bash
UV_CACHE_DIR=/tmp/mcp-studio-uv-cache uv run mcp-studio-client \
  --tool echo --arguments '{"message":"show me the wire"}'
```

Human-readable structured events appear in both terminals. Machine-readable
JSON Lines are saved to `traces/client.jsonl` and `traces/server.jsonl`.

## Learning mode

To stop at each lifecycle boundary, set these values in `.env`:

```dotenv
MCP_LEARNING_MODE=true
MCP_LEARNING_BREAK_STYLE=pause
```

Run the client normally. It prints a snapshot at every checkpoint and waits for
Enter before continuing. This lets you inspect both terminals and the JSONL
trace files after each exchange.

For Python or IDE debugging, use:

```dotenv
MCP_LEARNING_MODE=true
MCP_LEARNING_BREAK_STYLE=debugger
```

This calls `breakpoint()` at every checkpoint. Inspect the local `step` and
`snapshot` variables, then use the debugger's continue command to advance.

Set `MCP_LEARNING_MODE=false` for the original uninterrupted behavior.

## What is captured

```text
client SDK boundary                    server HTTP boundary
  initialize request ──────────────────> POST /mcp/
  initialize result <─────────────────── HTTP response + session ID
  notifications/initialized ───────────> POST /mcp/
  tools/list ───────────────────────────> POST /mcp/
  tools/list result <──────────────────── HTTP response
  tools/call ───────────────────────────> POST /mcp/
  tools/call result <──────────────────── HTTP response
  transport context closes ─────────────> DELETE /mcp/
```

The current MCP protocol does not define a JSON-RPC `shutdown` method. For
Streamable HTTP, graceful session termination is an HTTP `DELETE` carrying the
`Mcp-Session-Id`; closing the SDK transport context performs it.

## Add calls without adding trace code

Register another `@mcp.tool()`, resource, or prompt in `server.py`, then call it
normally from the client. `TracedSendStream` and `TracedReceiveStream` wrap the
client SDK's message streams, while `TraceASGIMiddleware` wraps the entire MCP
ASGI app. Because both operate below individual protocol methods, new and
custom calls are automatically recorded.

Trace records contain:

- monotonic sequence and elapsed time
- UTC timestamp
- side, layer, and direction
- event/method and correlation ID
- complete headers and bodies

Authorization and cookie headers are redacted by default. Set
`MCP_TRACE_SHOW_SECRETS=1` only in a safe local environment to include them.
Change output paths with `MCP_CLIENT_TRACE` and `MCP_SERVER_TRACE`.

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `HOST` | `127.0.0.1` | Uvicorn bind address |
| `PORT` | `8000` | Uvicorn port |
| `MCP_SERVER_URL` | `http://127.0.0.1:8000/mcp/` | Client endpoint |
| `MCP_TOOL` | `add` | Tool selected by the client |
| `MCP_TOOL_ARGUMENTS` | `{"a": 20, "b": 22}` | JSON tool arguments |
| `MCP_CLIENT_TRACE` | `traces/client.jsonl` | Client trace file |
| `MCP_SERVER_TRACE` | `traces/server.jsonl` | Server trace file |
| `MCP_TRACE_SHOW_SECRETS` | `false` | Include sensitive headers when true |
| `MCP_LEARNING_MODE` | `false` | Enable lifecycle checkpoints |
| `MCP_LEARNING_BREAK_STYLE` | `pause` | Wait for Enter or invoke `debugger` |

Run tests:

```bash
UV_CACHE_DIR=/tmp/mcp-studio-uv-cache uv run pytest
```
