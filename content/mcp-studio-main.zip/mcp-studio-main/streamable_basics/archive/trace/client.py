"""MCP client that demonstrates and traces the complete lifecycle."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from typing import Any

from dotenv import load_dotenv
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

from .learning import LearningController
from .tracing import TracedReceiveStream, TracedSendStream, WireTracer

load_dotenv()


async def run_lifecycle(url: str, tool: str,
                        arguments: dict[str, Any]) -> None:
    tracer = WireTracer("client",
                        os.getenv("MCP_CLIENT_TRACE", "traces/client.jsonl"))
    learning = LearningController.from_environment()
    tracer.record(
        layer="application",
        direction="local",
        event="connect",
        data={"url": url},
    )
    await learning.checkpoint(
        "01_before_transport_connect",
        url=url,
        explanation="No MCP session exists yet.",
    )

    # Closing these contexts performs the Streamable HTTP session teardown.
    async with streamable_http_client(url) as (read, write, get_session_id):
        await learning.checkpoint(
            "02_transport_connected",
            url=url,
            session_id=get_session_id(),
            explanation="Transport streams exist; MCP is not initialized yet.",
        )
        async with ClientSession(
                TracedReceiveStream(read, tracer),
                TracedSendStream(write, tracer),
        ) as session:
            tracer.record(
                layer="lifecycle",
                direction="local",
                event="initialize begin",
                data={},
            )
            await learning.checkpoint(
                "03_before_initialize",
                session_id=get_session_id(),
                explanation=(
                    "The next SDK call sends initialize, receives capabilities, "
                    "then sends notifications/initialized."
                ),
            )
            initialized = await session.initialize()
            tracer.record(
                layer="lifecycle",
                direction="local",
                event="initialize complete",
                data={
                    "result": initialized,
                    "session_id": get_session_id(),
                },
            )
            await learning.checkpoint(
                "04_after_initialize",
                session_id=get_session_id(),
                initialize_result=initialized,
                explanation="Protocol version and capabilities are now negotiated.",
            )

            await learning.checkpoint(
                "05_before_tools_list",
                session_id=get_session_id(),
                explanation="The next request discovers server tool schemas.",
            )
            tools = await session.list_tools()
            tracer.record(
                layer="lifecycle",
                direction="local",
                event="tools/list complete",
                data=tools,
            )
            await learning.checkpoint(
                "06_after_tools_list",
                session_id=get_session_id(),
                tools=tools,
                explanation="Tool names, descriptions, and JSON Schemas are available.",
            )

            await learning.checkpoint(
                "07_before_tools_call",
                session_id=get_session_id(),
                tool=tool,
                arguments=arguments,
                explanation="The next request validates arguments and invokes the tool.",
            )
            result = await session.call_tool(tool, arguments=arguments)
            tracer.record(
                layer="lifecycle",
                direction="local",
                event="tools/call complete",
                data=result,
            )
            await learning.checkpoint(
                "08_after_tools_call",
                session_id=get_session_id(),
                tool=tool,
                result=result,
                explanation="The tool result has returned as MCP content.",
            )

            print(
                json.dumps(
                    {
                        "server": initialized.serverInfo.model_dump(
                            mode="json", by_alias=True
                        ),
                        "available_tools": [item.name for item in tools.tools],
                        "called": tool,
                        "result": result.model_dump(
                            mode="json", by_alias=True, exclude_none=True
                        ),
                    },
                    indent=2,
                )
            )
            await learning.checkpoint(
                "09_before_client_session_close",
                session_id=get_session_id(),
                explanation="Leaving ClientSession stops its message-processing tasks.",
            )

        tracer.record(
            layer="lifecycle",
            direction="local",
            event="session closed",
            data={"session_id": get_session_id()},
        )
        await learning.checkpoint(
            "10_before_transport_close",
            session_id=get_session_id(),
            explanation=(
                "Leaving the transport context sends HTTP DELETE for this session."
            ),
        )

    tracer.record(
        layer="lifecycle",
        direction="local",
        event="transport closed",
        data={
            "note": "Streamable HTTP teardown sends DELETE when a session exists"},
    )
    await learning.checkpoint(
        "11_lifecycle_complete",
        session_id=get_session_id(),
        explanation="The stateful MCP session and HTTP transport are closed.",
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--url",
        default=os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp/"),
    )
    parser.add_argument("--tool", default=os.getenv("MCP_TOOL", "add"))
    parser.add_argument(
        "--arguments",
        default=os.getenv("MCP_TOOL_ARGUMENTS", '{"a": 20, "b": 22}'),
        type=json.loads,
        help="Tool arguments as JSON",
    )
    return parser


def main() -> None:
    args = _parser().parse_args()
    asyncio.run(run_lifecycle(args.url, args.tool, args.arguments))


if __name__ == "__main__":
    main()
