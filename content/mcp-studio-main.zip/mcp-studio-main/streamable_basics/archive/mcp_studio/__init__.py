"""MCP Studio: inspect every message in an MCP lifecycle."""

__version__ = "0.1.0"
