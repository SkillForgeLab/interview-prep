"""FastAPI-hosted MCP server with automatic wire tracing."""

from __future__ import annotations

import contextlib
import os
from collections.abc import AsyncIterator

import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI
from mcp.server.fastmcp import FastMCP

from .tracing import TraceASGIMiddleware, WireTracer

# Load local configuration before module-level settings are constructed.
# Existing shell variables take precedence over values in .env.
load_dotenv()

wire = WireTracer("server", os.getenv("MCP_SERVER_TRACE", "traces/server.jsonl"))

mcp = FastMCP(
    "MCP Lifecycle Studio",
    instructions="A learning server that exposes every lifecycle exchange.",
    json_response=True,
    stateless_http=False,
    # FastAPI provides the external /mcp mount; keep the nested MCP app at root.
    streamable_http_path="/",
)


@mcp.tool()
def add(a: float, b: float) -> dict[str, float]:
    """Add two numbers."""
    return {"a": a, "b": b, "sum": a + b}


@mcp.tool()
def echo(message: str) -> dict[str, str]:
    """Echo a message back to the caller."""
    return {"echo": message}


@contextlib.asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    wire.record(
        layer="application",
        direction="local",
        event="server startup",
        data={"mcp_endpoint": "/mcp"},
    )
    async with mcp.session_manager.run():
        yield
    wire.record(
        layer="application",
        direction="local",
        event="server shutdown",
        data={"reason": "ASGI lifespan ended"},
    )


app = FastAPI(
    title="MCP Lifecycle Studio",
    description="FastAPI host for a fully traced MCP Streamable HTTP server.",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


app.mount("/mcp", TraceASGIMiddleware(mcp.streamable_http_app(), wire))


def main() -> None:
    uvicorn.run(
        "mcp_studio.server:app",
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8000")),
        reload=False,
    )


if __name__ == "__main__":
    main()
