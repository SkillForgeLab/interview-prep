"""Optional interactive checkpoints for walking through the MCP lifecycle."""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel


def _enabled(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}


def _display(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)
    if isinstance(value, dict):
        return {str(key): _display(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_display(item) for item in value]
    return value


@dataclass(frozen=True, slots=True)
class LearningController:
    """Pause or enter a debugger at named lifecycle boundaries."""

    enabled: bool = False
    style: str = "pause"

    @classmethod
    def from_environment(cls) -> "LearningController":
        style = os.getenv("MCP_LEARNING_BREAK_STYLE", "pause").strip().lower()
        if style not in {"pause", "debugger"}:
            raise ValueError(
                "MCP_LEARNING_BREAK_STYLE must be either 'pause' or 'debugger'"
            )
        return cls(
            enabled=_enabled(os.getenv("MCP_LEARNING_MODE")),
            style=style,
        )

    async def checkpoint(self, step: str, **state: Any) -> None:
        """Expose state and optionally interrupt before execution continues."""
        if not self.enabled:
            return

        snapshot = {
            "learning_checkpoint": step,
            "state": _display(state),
        }
        print(
            "\n" + "=" * 72 + "\n"
            + json.dumps(snapshot, indent=2, ensure_ascii=False, default=str)
            + "\n" + "=" * 72,
            flush=True,
        )

        if self.style == "debugger":
            # Inspect `step` and `snapshot` from pdb or an IDE debugger.
            breakpoint()
            return

        prompt = (
            f"[learning mode] {step}\n"
            "Inspect the trace and state above, then press Enter to continue..."
        )
        try:
            await asyncio.to_thread(input, prompt)
        except EOFError:
            # Non-interactive runners have no stdin; showing the snapshot still
            # provides value, and the lifecycle continues instead of hanging.
            print("\n[learning mode] stdin unavailable; continuing.", flush=True)
