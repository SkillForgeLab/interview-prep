## HTTP / WebSocket, ASGI, AnyIO and FASTAPI

- `HTTP / WebSocket = client-server network protocols`
    - Carries data between the client and Uvicorn.


- `ASGI(Asynchronous Server Gateway Interface) = server-application interface`
    - Represents HTTP activity as asynchronous events.
    - Defines how asynchronous Python web servers and applications communicate.
      **It's not a network protocol.**
    - Uvicorn supports Python’s asyncio event loop and uvloop, which is
      an alternative implementation of the asyncio event-loop interface.


- `Event loop (asyncio / uvloop) = execution runtime`
    - Schedules asynchronous work for both Uvicorn and the application.


- `FastAPI` is a modern Python **web framework used to build APIs**


- `Uvicorn` is the underlying **web server (software engine)** that:
    - listens for network traffic,
    - handles incoming HTTP, WebSocket requests and
    - passes them to FastAPI for processing.


- `AnyIO = concurrency abstraction/library`
    - It is a concurrency utility library to run code over supported
      async backends — not an interface between Uvicorn and FastAPI.
    - Runs application code over supported async backends.
    - It is not a separate mandatory layer between ASGI and application logic.

```
Client
  │
  │ HTTP / WebSocket
  ▼
┌────────────────────────────────────────────────────────────────────────┐
│ OS process / container                                                 │
│     ┌────────────────────────────────────────────────────────────┐     │
│     │ Python runtime                                             │     │
│     │                                                            │     │
│     │ Event loop: asyncio or uvloop                              │     │
│     │                                                            │     │
│     │ ┌──────────────┐ ASGI Interface     ┌──────────────────┐   │     │
│     │ │ ASGI server  │ ───────────────▶   │ App/framework    │   │     │
│     │ │ (Uvicorn)    │ (scope, receive,   │ (FastAPI)        │   │     │
│     │ └──────────────┘  send)             │   │              │   │     │
│     │                                     │   ├─ Routing     │   │     │
│     │                                     │   ├─ Dependencies│   │     │
│     │                                     │   ├─ App logic   │   │     │
│     │                                     │   │              │   │     │
│     │                                     │   └─ Starlette   │   │     │
│     │                                     │       │          │   │     │
│     │                                     │       └─ AnyIO   │   │     │
│     │                                     └──────────────────┘   │     │
│     │                                             │              │     │
│     │                                             ▼              │     │
│     │                                     Application logic      │     │
│     │                                                            │     │
│     │ Optional:                                                  │     │
│     │ App/framework     → AnyIO APIs                             │     │
│     │ For Blocking work → thread pool                            │     │
│     └────────────────────────────────────────────────────────────┘     │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```        

### WSGI & ASGI

**WSGI** is the main synchronous Python alternative. However, its single
request/response callable is not naturally designed for long-lived,
bidirectional protocols.

A standard calling convention for Python web servers to communicate with
asynchronous-capable applications and frameworks.

It's a contract that defines:

- how a Python server calls an application;
- the function signature: application(scope, receive, send);
- the structure of messages exchanged between them.

**ASGI also includes protocol-specific specifications** for translating HTTP,
WebSocket, and lifespan events into these messages.

As the successor to WSGI, it is designed for high-concurrency web applications,
WebSockets, and modern APIs.

| Option   | Execution model                | Best suited for                                     |
|----------|--------------------------------|-----------------------------------------------------|
| **WSGI** | Synchronous request/response   | Traditional Flask or Django-style HTTP applications |
| **ASGI** | Async, with sync compatibility | Streaming HTTP, SSE, WebSockets, high concurrency   |

