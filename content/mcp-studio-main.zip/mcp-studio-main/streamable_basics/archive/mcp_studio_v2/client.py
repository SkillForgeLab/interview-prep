# client.py
"""MCP client that demonstrates and traces the complete lifecycle."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from dotenv import load_dotenv
from mcp import Client  # was: ClientSession + manual session.initialize()

from .learning import LearningController
from .tracing import TracedReceiveStream, TracedSendStream, WireTracer

load_dotenv()


@asynccontextmanager
async def _traced_transport(url: str, tracer: WireTracer) -> AsyncIterator[tuple[Any, Any]]:
    """Wrap the Streamable HTTP transport so every JSON-RPC message is traced.

    v2's streamable_http_client(url) now yields a 2-tuple (read, write) —
    the get_session_id callback was removed, since there's no protocol-level
    session to identify under 2026-07-28.
    """
    from mcp.client.streamable_http import streamable_http_client

    async with streamable_http_client(url) as (read, write):
        yield TracedReceiveStream(read, tracer), TracedSendStream(write, tracer)


async def run_lifecycle(url: str, tool: str, arguments: dict[str, Any]) -> None:
    tracer = WireTracer("client", os.getenv("MCP_CLIENT_TRACE", "traces/client.jsonl"))
    learning = LearningController.from_environment()
    tracer.record(layer="application", direction="local", event="connect", data={"url": url})
    await learning.checkpoint(
        "01_before_connect",
        url=url,
        explanation=(
            "No protocol handshake has happened yet. Client defaults to "
            "mode='auto': it will probe server/discover and fall back to "
            "the legacy initialize handshake only if the server doesn't "
            "support the current protocol."
        ),
    )

    # Entering `Client` performs connect + negotiate in one step — there's
    # no separate initialize()/initialized notification to call manually.
    async with Client(_traced_transport(url, tracer)) as client:
        tracer.record(
            layer="lifecycle",
            direction="local",
            event="negotiation complete",
            data={
                "protocol_version": client.protocol_version,
                "server_info": client.server_info,
            },
        )
        await learning.checkpoint(
            "02_after_connect",
            protocol_version=client.protocol_version,
            server_info=client.server_info,
            explanation="Protocol version and capabilities are negotiated.",
        )

        await learning.checkpoint(
            "03_before_tools_list",
            explanation="The next call discovers server tool schemas.",
        )
        tools = await client.list_tools()
        tracer.record(layer="lifecycle", direction="local", event="tools/list complete", data=tools)
        await learning.checkpoint(
            "04_after_tools_list",
            tools=tools,
            explanation="Tool names, descriptions, and JSON Schemas are available.",
        )

        await learning.checkpoint(
            "05_before_tools_call",
            tool=tool,
            arguments=arguments,
            explanation="The next call validates arguments and invokes the tool.",
        )
        result = await client.call_tool(tool, arguments)
        tracer.record(layer="lifecycle", direction="local", event="tools/call complete", data=result)
        await learning.checkpoint(
            "06_after_tools_call",
            tool=tool,
            result=result,
            explanation="The tool result has returned as MCP content.",
        )

        print(
            json.dumps(
                {
                    "server": client.server_info.model_dump(mode="json", by_alias=True),
                    "available_tools": [item.name for item in tools.tools],
                    "called": tool,
                    "result": result.model_dump(mode="json", by_alias=True, exclude_none=True),
                },
                indent=2,
            )
        )
        await learning.checkpoint(
            "07_before_disconnect",
            explanation="Leaving `async with Client(...)` disconnects.",
        )

    tracer.record(layer="lifecycle", direction="local", event="disconnected", data={})
    await learning.checkpoint(
        "08_lifecycle_complete",
        explanation=(
            "Connection closed. Under 2026-07-28 there's no session to "
            "tear down; if the server had negotiated down to a legacy "
            "2025-11-25 connection instead, the SDK handles that session's "
            "teardown transparently."
        ),
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default=os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp/"))
    parser.add_argument("--tool", default=os.getenv("MCP_TOOL", "add"))
    parser.add_argument(
        "--arguments",
        default=os.getenv("MCP_TOOL_ARGUMENTS", '{"a": 20, "b": 22}'),
        type=json.loads,
        help="Tool arguments as JSON",
    )
    return parser


def main() -> None:
    args = _parser().parse_args()
    asyncio.run(run_lifecycle(args.url, args.tool, args.arguments))


if __name__ == "__main__":
    main()