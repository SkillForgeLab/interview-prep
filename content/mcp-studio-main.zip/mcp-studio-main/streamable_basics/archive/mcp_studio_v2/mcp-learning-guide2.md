
# MCP Learning Guide (rev. 2026-07-28)

> ⚠️ VERSION NOTICE — READ FIRST
> The Model Context Protocol specification was revised to **2026-07-28** on
> today's date, replacing 2025-11-25. This is the largest breaking change
> since MCP launched: it removes the session/handshake model in favor of a
> stateless, per-request protocol. The 2025-11-25 (and earlier) model is not
> switched off — it is deprecated with a 12-month minimum support window —
> but it is no longer current. Sections below are labeled LEGACY or CURRENT
> accordingly. Primary sources:
>   - https://modelcontextprotocol.io/specification/2026-07-28
>   - https://modelcontextprotocol.io/specification/draft/changelog
>   - https://blog.modelcontextprotocol.io/posts/2026-07-28/

---

## 1. MCP OVERVIEW

### 1.1 What is MCP?

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  MCP = Model Context Protocol                                               │
│                                                                             │
│  DEFINITION:                                                                │
│  A standardized protocol letting an AI client discover                      │
│  and call tools/data/prompts exposed by a server.                           │
│                                                                             │
│  Think of it as:                                                            │
│  • A "USB port" for AI — plug in any tool                                   │
│  • A contract between AI and tools                                          │
│  • Language-agnostic protocol (works with any programming language)         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 The problem MCP solves

Without a shared protocol, every AI-to-tool integration reinvents discovery,
argument typing, invocation, error handling, and (historically) session
management. MCP standardizes those conversations. It does not run a model and
does not decide when a model should use a tool — that's the client/agent's job.

```
WITHOUT MCP:                          WITH MCP:
─────────────────────────────────     ─────────────────────────────────
- Custom integration per tool         • Standard interface for all tools
- Tight coupling                      • Loose coupling
- Hard to swap tools                  • Easy to add/remove tools
- Vendor lock-in                      • Interoperability
- No standard discovery               • Built-in tool discovery
```

### 1.3 Official sources

- Specification (
  current): https://modelcontextprotocol.io/specification/2026-07-28
- Docs: https://modelcontextprotocol.io/docs
- Changelog: https://modelcontextprotocol.io/specification/draft/changelog

---

## 2. CONCEPT HIERARCHY (corrected)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          MCP CONCEPT HIERARCHY                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PROTOCOL LAYER                                                             │
│  ├── JSON-RPC 2.0 ─────────── message format                                │
│  └── Transport ────────────── how messages travel                           │
│       ├── Streamable HTTP (now stateless, no session ID)                    │
│       └── stdio                                                             │
│                                                                             │
│  COMPONENT LAYER                                                            │
│  ├── MCP Server ───────────── exposes capabilities                          │
│  └── MCP Client ───────────── consumes capabilities                         │
│                                                                             │
│  CAPABILITY LAYER (core)                                                    │
│  ├── Tools ────────────────── executable functions                          │
│  ├── Resources ────────────── readable data by URI                          │
│  └── Prompts ──────────────── reusable prompt templates                     │
│                                                                             │
│  CAPABILITY LAYER (deprecated, still functional ≥12 months)                 │
│  ├── Roots ────────────────── client-exposed workspace boundaries           │
│  ├── Sampling ─────────────── server can request an LLM completion          │
│  └── Logging ──────────────── server-to-client log forwarding               │
│                                                                             │
│  EXTENSIONS LAYER (new, official as of 2026-07-28)                          │
│  ├── Tasks ─────────────────  long-running work (was experimental core)     │
│  ├── MCP Apps ─────────────── server-rendered HTML UI in sandboxed iframe   │
│  └── Enterprise Managed Authorization (EMA)                                 │
│                                                                             │
│  LIFECYCLE LAYER                                                            │
│  ├── LEGACY: Initialization ── initialize/initialized handshake + session   │
│  ├── CURRENT: Per-request negotiation ── version/identity in every request  │
│  ├── Discovery ─────────────── list available items (now cacheable)         │
│  ├── Invocation ────────────── call tools / read resources                  │
│  └── Elicitation / Sampling ── now delivered via Multi Round-Trip Requests  │
│                                (MRTR) instead of a held-open stream         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

Elicitation itself is not deprecated — only its old delivery mechanism
(a permanently open bidirectional stream) is. It's been redesigned onto MRTR
(see §9).

---

## 3. HIGH-LEVEL ARCHITECTURE

```
                 ┌──────────────────────────┐
                 │        MCP CLIENT        │
                 │   ( Agent / App / IDE )  │
                 └────────────┬─────────────┘
                              │ JSON-RPC Messages (self-describing;
                              │ each request carries its own version,
                              │ identity, and capabilities in `_meta`)
                              ▼
                 ┌──────────────────────────┐
                 │        TRANSPORT         │
                 ├──────────────────────────┤
                 │     stdio                │
                 │     Streamable HTTP      │  (stateless as of 2026-07-28)
                 └────────────┬─────────────┘
                              │
                              ▼
                 ┌──────────────────────────┐
                 │        MCP SERVER        │
                 │ (tools + data + prompts) │
                 └────────────┬─────────────┘
                              │
          ┌───────────────────┼───────────────────┬─────────────────┐
          │                   │                    │                 │
          ▼                   ▼                    ▼                 ▼
┌───────────────────┐ ┌──────────────────┐ ┌─────────────────┐ ┌──────────────┐
│   TOOLS           │ │   RESOURCES      │ │  PROMPTS        │ │ EXTENSIONS   │
│   (actions)       │ │   (data)         │ │  (templates)    │ │ (Tasks, Apps)│
├───────────────────┤ ├──────────────────┤ ├─────────────────┤ ├──────────────┤
│   tools/list      │ │  resources/list  │ │  prompts/list   │ │ negotiated   │
│   tools/call      │ │  resources/read  │ │  prompts/get    │ │ via the      │
│   streaming       │ │  subscriptions   │ │  arguments      │ │ `extensions` │
│   progress        │ │  templates       │ │                 │ │ capability   │
└───────────────────┘ └──────────────────┘ └─────────────────┘ └──────────────┘
```

---

## 4. CORE PRIMITIVES

### 4.1 Tools

Tools are invocable functions with `name`, `description`, an input schema, and
an output.

```
{
 "name": "get_weather",
 "description": "Get weather for a city",
 "inputSchema": {
   "type": "object",
   "properties": { "city": { "type": "string" } }
 }
}
```

```
 ┌─────────────────────────┬───────────────────────────────────────────────┐
 │ OPERATION               │ MEANING                                       │
 ├─────────────────────────┼───────────────────────────────────────────────┤
 │ tools/list              │ discover available tools (now cacheable —     │
 │                         │ carries ttlMs / cacheScope, deterministic     │
 │                         │ order)                                        │
 │ tools/call              │ execute tool                                  │
 │ streaming               │ partial outputs                               │
 │ progress notifications  │ execution status                              │
 │ notifications/cancelled │ client cancels an in-flight request           │
 └─────────────────────────┴───────────────────────────────────────────────┘
```

**Good tool design:** one clear purpose · typed inputs · small output ·
deterministic where possible · explicit errors · no hidden side effects.

**Bad tool design:** many unrelated arguments · printing instead of returning
· leaking raw internal objects · mixing logs with the stdio wire channel.

### 4.2 Resources

Resources expose **data**, addressed by URI, instead of actions.

```
Client → resources/list → Server returns resource list (cacheable)
Client → resources/read → Server returns content
```

Examples: `file://docs/api.md`, `db://users/123`, `logs://server/errors`

| Feature              | Description                                |
|----------------------|--------------------------------------------|
| Templates            | Parameterized resource URIs                |
| Subscriptions        | Subscribe to resource update notifications |
| BlobResourceContents | Binary resource content support            |
| Pagination           | Partial listing of resources               |

### 4.3 Prompts

Prompts are reusable, parameterized templates for AI input.

```
Client → prompts/list → Server returns prompts
Client → prompts/get  → Server returns prompt template
```

```
Prompt: summarize_document
Template: "Summarize the following document: {{document}}
           Focus on: key insights / decisions / risks"
Arguments: { "document": "text here" }
```

---

## 5. TERM DEFINITIONS

```
┌──────────────────┬─────────────────────────────────────────────────────────┐
│ TERM             │ DEFINITION                                              │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ MCP Server       │ EXPOSES tools/resources/prompts.                        │
│                  │ MEMORIZE: "Server = Provider = Exposes"                 │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ MCP Client       │ CALLS what a server exposes.                            │
│                  │ MEMORIZE: "Client = Consumer = Calls"                   │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Tool             │ Invocable function: name, description, input schema,    │
│                  │ output. Example: search_transactions, send_email        │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Resource         │ Read-only data by URI: URI, name, mime type, contents.  │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Prompt           │ Reusable template with arguments.                       │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Transport        │ Channel messages travel over: stdio, Streamable HTTP.   │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ JSON-RPC 2.0     │ Message format used by MCP. jsonrpc, method/result, id. │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Capability       │ A feature a peer supports. As of 2026-07-28, negotiated │
│                  │ per-request (legacy: negotiated once at initialize).    │
│                  │ Advertised ≠ non-empty — a capability being advertised  │
│                  │ doesn't guarantee its list has items.                   │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Session          │ ⚠️ CHANGED. No longer a protocol concept as of          │
│                  │ 2026-07-28 — MCP is explicitly stateless; a connection  │
│                  │ is not a conversation. State spanning calls must use an │
│                  │ explicit, server-minted handle passed as a tool arg.    │
│                  │ ("Session" still applies to servers/clients running the │
│                  │ legacy 2025-11-25-and-earlier lifecycle.)               │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ Extension        │ Optional capability beyond the core protocol, ID'd by   │
│                  │ reverse-DNS name (e.g. io.modelcontextprotocol/tasks),  │
│                  │ negotiated via the `extensions` capability field.       │
├──────────────────┼─────────────────────────────────────────────────────────┤
│ MRTR             │ Multi Round-Trip Requests — replaces held-open streams  │
│                  │ for server-initiated elicitation/sampling/roots.        │
└──────────────────┴─────────────────────────────────────────────────────────┘
```

---

## 6. TRANSPORTS

```
┌─────────────────┬──────────────────────────────────────────────────────────┐
│ TRANSPORT       │ DETAILS                                                  │
├─────────────────┼──────────────────────────────────────────────────────────┤
│ Streamable HTTP │ Single MCP endpoint, POST + optional GET (SSE) stream.   │
│                 │ ⚠️ CHANGED (2026-07-28): stateless — no more             │
│                 │ Mcp-Session-Id header. Every POST must carry the         │
│                 │ Mcp-Method and Mcp-Name headers so gateways can route    │
│                 │ and meter without parsing the JSON body.                 │
│                 │ Best for: remote/deployed servers, scaling behind a      │
│                 │ plain round-robin load balancer (no shared session       │
│                 │ storage needed).                                         │
├─────────────────┼──────────────────────────────────────────────────────────┤
│ stdio           │ Client spawns server as subprocess; stdin/stdout pipes.  │
│                 │ Process identity is NOT a proxy for conversation state — │
│                 │ each request is still independent.                       │
│                 │ Do NOT print logs to stdout — it's the wire.             │
│                 │ Best for: local tools, IDE plugins, CLIs.                │
└─────────────────┴──────────────────────────────────────────────────────────┘

DEPRECATED:
"HTTP+SSE" (legacy, pre-2025-03-26 transport with separate GET/POST
endpoints) — officially deprecated with a 12-month offramp as of 2026-07-28.
```

> **Legacy/modern discovery pattern** (a client that doesn't know which era
> a server speaks):
> - HTTP: send a modern request. On `400`, inspect the *body* — modern
    > servers also use 400 for `UnsupportedProtocolVersionError` and similar.
    > Only fall back to `initialize` if the body is empty/unrecognized.
> - stdio: probe with `server/discover` first. A `Method not found` (-32601)
    > means fall back to legacy `initialize`.
    > ⚠️ Sourced from the official lifecycle spec; exact response-shape edge
    > cases are worth re-checking against the live spec page if you're
    > implementing this yourself.

---

## 7. LIFECYCLE

### 7A. CURRENT (2026-07-28): stateless, per-request

MCP is now a **stateless protocol**: everything needed to process a request
is in the request itself. No state is inferred from a shared connection.

```
Client                              Server
  │  request (method + _meta:         │
  │  protocolVersion, clientInfo,     │
  │  clientCapabilities)              │
  │──────────────────────────────────▶│
  │                                   │  version supported?
  │◀──────────────────────────────────│  yes → result
  │  result / UnsupportedProtocol-    │  no  → UnsupportedProtocolVersionError
  │  VersionError                     │       (lists supported versions)
```

Key rules:

- Servers **MUST NOT** rely on prior requests on the same connection for
  context (capabilities, protocol version, client identity) — every request
  restates these in `_meta`.
- Servers **MUST NOT** require a client to reuse the same connection for
  related operations.
- Cross-call state (long-running tasks, app-level handles) **MUST** be
  referenced by an explicit identifier passed back on each request.
- Servers **MUST** implement `server/discover`; clients **MAY** call it
  up front to learn supported versions, but aren't required to.
- Error example (replaces old negotiation failure):

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32004,
    "message": "Unsupported protocol version",
    "data": {
      "supported": [
        "2026-07-28",
        "2025-11-25"
      ],
      "requested": "1900-01-01"
    }
  }
}
```

⚠️ I have not verified the exact client-SDK method names for issuing a
stateless call (e.g., what replaces `session.initialize()` in Python/TS) —
check current SDK release notes before writing code against this.

### 7B. LEGACY (2025-11-25 and earlier): handshake + session

Still supported for backward compatibility (≥12-month deprecation window).
This is what your original document described.

```
ClientSession       Client HTTP transport       FastMCP server
     │                        │                         │
     │ initialize             │                         │
     │───────────────────────>│ POST initialize         │
     │                        │────────────────────────>│
     │                        │ session + capabilities  │
     │ initialize result      │<────────────────────────│
     │<───────────────────────│                         │
     │ initialized notice     │ POST notification       │
     │───────────────────────>│────────────────────────>│
     │                        │ 202 acknowledgement     │
     │                        │<────────────────────────│
     │                        │ GET event stream        │
     │                        │────────────────────────>│
     │             ***** READY STATE *****              │
     │ tools/list             │ POST tools/list         │
     │───────────────────────>│────────────────────────>│
     │ list result            │<────────────────────────│
     │<───────────────────────│                         │
     │ tools/call             │ POST tools/call         │
     │───────────────────────>│────────────────────────>│
     │ call result            │<────────────────────────│
     │<───────────────────────│                         │
     │ close                  │ DELETE + session ID     │
     │───────────────────────>│────────────────────────>│
     │                        │ 200; event stream ends  │
     │                        │<────────────────────────│
```

```
┌─────────────────────┬───────────────────────────────────────────────────────┐
│ METHOD              │ PURPOSE                                               │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ initialize          │ LEGACY: start session, negotiate capabilities         │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ tools/list          │ Get available tools                                   │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ tools/call          │ Execute a tool                                        │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ resources/list      │ Get available resources                               │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ resources/read      │ Read a resource's content                             │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ prompts/list        │ Get available prompts                                 │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ prompts/get         │ Get a prompt template                                 │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ server/discover     │ CURRENT: optional up-front capability discovery       │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ tasks/get,          │ Extension: poll/update long-running work              │
│  tasks/update       │                                                       │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ notifications/*     │ Fire-and-forget notifications                         │
├─────────────────────┼───────────────────────────────────────────────────────┤
│ ping                │ Keep connection alive                                 │
└─────────────────────┴───────────────────────────────────────────────────────┘
```

There is no JSON-RPC `shutdown` method. In the legacy model, `DELETE` is the
graceful session-termination mechanism. In the current stateless model there
is no session to terminate — the transport connection just closes.

---

## 8. EXTENSIONS FRAMEWORK (new in 2026-07-28)

Extensions are officially-recognized additions to core MCP, identified by
reverse-DNS IDs, negotiated through the `extensions` field on client/server
capabilities, versioned independently of the base spec.

```json
"capabilities": {
"tools": {},
"extensions": {"io.modelcontextprotocol/apps": {}}
}
```

| Extension                                   | Purpose                                                                                                                                                                                                                           |
|---------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `io.modelcontextprotocol/tasks`             | Long-running work. Was experimental core in 2025-11-25; now a formal extension. Poll via `tasks/get`, update via `tasks/update`; change notifications via a `subscriptions/listen` stream clients opt into per notification type. |
| `io.modelcontextprotocol/apps` ("MCP Apps") | Servers ship interactive HTML UIs that hosts render in a sandboxed iframe. UI actions round-trip through the same JSON-RPC/consent path as a direct tool call.                                                                    |
| Enterprise Managed Authorization (EMA)      | ⚠️ Named in the official announcement as a third flagship extension; I have not fetched its detailed spec page to describe its mechanics accurately — treat as "exists" only until verified.                                      |

---

## 9. MULTI ROUND-TRIP REQUESTS (MRTR) — new delivery mechanism

Replaces the old held-open bidirectional stream previously used for
server-initiated `elicitation/create`, `sampling/createMessage`, and
`roots/list`. Necessary because the protocol is now stateless.

```
Server needs input mid-call (e.g. user confirmation)
        │
        ▼
Server returns: resultType: "input_required" + the sub-requests it needs
        │
        ▼
Client collects answers, retries the ORIGINAL call with
inputResponses attached
```

---

## 10. AUTHORIZATION (corrected: this is a protocol feature, not just an "implementation concern")

MCP defines a normative, OAuth-based authorization model — this was already
true before today's release, and your source mis-filed it as "IC." As of
2026-07-28 it's been hardened further:

| Change                              | What it does                                                                                                           |
|-------------------------------------|------------------------------------------------------------------------------------------------------------------------|
| RFC 9207 issuer validation          | Authorization servers return `iss`; clients must validate before redeeming a code — closes an auth-server mix-up hole. |
| Client ID Metadata Documents (CIMD) | New standard for client identity, replacing Dynamic Client Registration (DCR).                                         |
| DCR                                 | Formally deprecated (still works for backward compatibility; will be removed in a future version).                     |
| `application_type` at DCR           | Prevents auth servers from wrongly rejecting `localhost` redirects for desktop/CLI apps.                               |
| Credential–issuer binding           | Client credentials are bound to the issuer that minted them; no cross-issuer reuse.                                    |

---

## 11. NOTIFICATIONS & MESSAGE FORMAT (JSON-RPC 2.0)

Two message types: **Request** (expects a response) and **Notification**
(fire-and-forget, no `id`, no response expected — used for
`progress/update`, `log/message`, `resource/changed`).

**Request:**

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "add",
    "arguments": {
      "a": 20,
      "b": 22
    }
  }
}
```

**Matching success response** (same `id`):

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "structuredContent": {
      "a": 20.0,
      "b": 22.0,
      "sum": 42.0
    },
    "isError": false
  }
}
```

**Notification** (corrected — no `id`, not a duplicate of the response above):

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/initialized"
}
```

HTTP `202 Accepted` confirms transport-level receipt of a notification;
there is no JSON-RPC result for it.

**Error response:**

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32600,
    "message": "Invalid Request",
    "data": {}
  }
}
```

**Key distinction:** HTTP status tells you the transport exchange worked.
JSON-RPC `result`/`error` tells you the requested operation worked. A `200
OK` does not by itself prove a tool call succeeded — check `isError`.

---

## 12. GENERIC CODE PATTERNS (legacy, stateful — still valid for 2025-11-25)

```python
# --- SERVER SIDE ---
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("my-server")


@mcp.tool()
def example_tool(x: float, y: float) -> dict[str, float]:
    """One clear purpose. Typed inputs. Small, deterministic output."""
    return {"x": x, "y": y, "sum": x + y}


mcp.run(transport="stdio")
# or: mcp.run(transport="http", host="0.0.0.0", port=8000)
```

```python
# --- CLIENT SIDE (Streamable HTTP, legacy stateful pattern) ---
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

async with streamable_http_client(url) as (read, write, get_session_id):
    async with ClientSession(read, write) as session:
        await session.initialize()
        tools = await session.list_tools()
        result = await session.call_tool("example_tool", {"x": 1, "y": 2})
```

⚠️ MISSING / UNVERIFIED: I could not confirm the exact API shape for a
**stateless** 2026-07-28 client call in Python/TS/Go/C# — the official blog
notes migration cost "especially for developers who depended on session
identifiers." Check the SDK repos' migration notes before writing new code:

- https://github.com/modelcontextprotocol/python-sdk
- https://github.com/modelcontextprotocol/typescript-sdk

---

## 13. ASGI / NETWORK STACK (Python HTTP servers only)

Implementation detail, not MCP itself — relevant only when a Python MCP
server runs over Streamable HTTP via an ASGI server (e.g. Uvicorn).

```
Application intent: call a tool
        │
MCP: capabilities, tools/resources/prompts
        │
JSON-RPC 2.0: method, params, id, result/error
        │
Streamable HTTP: POST, optional GET event stream, Mcp-Method/Mcp-Name headers
        │
ASGI / async runtime: async messages, event loop (asyncio/uvloop)
        │
TCP/IP: bytes between host:port
```

stdio-based servers skip this entire stack — no HTTP, no ASGI, just process
pipes.

---

## 14. ERROR BOUNDARIES

```
┌──────────────┬────────────────────────────────┬────────────────────────────┐
│ LAYER        │ EXAMPLE                        │ OBSERVABLE FORM            │
├──────────────┼────────────────────────────────┼────────────────────────────┤
│ Tool         │ Tool raises or returns an error│ Call result, isError:true  │
│ MCP/JSON-RPC │ Unknown method, bad request    │ JSON-RPC error object      │
│ Version      │ Requested version unsupported  │ UnsupportedProtocolVersion │
│              │                                │ Error (-32004)             │
│ HTTP         │ Wrong route, bad media type    │ HTTP 4xx/5xx               │
│ Network      │ Server unreachable             │ Client transport exception │
│ Process      │ Startup/config failure         │ Runtime/lifespan error     │
└──────────────┴────────────────────────────────┴────────────────────────────┘
```

(Removed: "Session — missing/expired session ID" as its own layer, since
sessions are no longer a protocol concept in the current spec. Still
applicable if you're running/interfacing with a legacy 2025-11-25 server.)

---

## 15. DEBUGGING CHECKLIST

```
┌─────────────────────────────┬───────────────────────────────────────────────┐
│ PROBLEM                     │ CHECK                                         │
├─────────────────────────────┼───────────────────────────────────────────────┤
│ Tools not discovered        │ Is MCP server running? Check /health          │
│ 404 on endpoint             │ Transport mismatch (stdio vs HTTP)            │
│ Tool returns empty          │ Check underlying data source                  │
│ Connection refused          │ Check port / process / networking             │
│ JSON parse error            │ Tool not returning valid JSON string          │
│ Timeout                     │ Long-running tool → consider Tasks extension  │
│ Unexpected UnsupportedProtocol- │ Client/server on mismatched spec eras —   │
│ VersionError                    │ check both sides' supported versions      │
└─────────────────────────────┴───────────────────────────────────────────────┘
```

---

## SUMMARY: KEY TAKEAWAYS

```
┌─────────────────────────────────────────────────────────────────────────────┐

 1. MCP = standard protocol for AI clients to call tools/data/prompts.
 2. Server EXPOSES capabilities, Client CALLS them.
 3. All messages use JSON-RPC 2.0.
 4. Two transports: stdio (local) and Streamable HTTP (remote).
    Legacy HTTP+SSE is deprecated (12-month offramp from 2026-07-28).
 5. Discovery: */list · Execution: */call.
 6. ⚠️ CHANGED: As of 2026-07-28, MCP is stateless. There is no
    initialize/initialized handshake and no Mcp-Session-Id — every request
    carries its own version, identity, and capabilities. The old handshake
    model still works for backward compatibility (≥12 months).
 7. A capability being advertised ≠ its list being non-empty.
 8. HTTP 200 ≠ tool success — check isError in the JSON-RPC result.
 9. NEW: Extensions (Tasks, MCP Apps, EMA) are the sanctioned way to add
    capability beyond core MCP, negotiated via the `extensions` field.
10. DEPRECATED (still functional ≥12 months): Roots, Sampling, Logging,
    Dynamic Client Registration.

└─────────────────────────────────────────────────────────────────────────────┘
```




