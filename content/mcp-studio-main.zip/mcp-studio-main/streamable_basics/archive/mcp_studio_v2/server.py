# server.py
"""FastAPI-hosted MCP server with automatic wire tracing."""

from __future__ import annotations

import contextlib
import os
from collections.abc import AsyncIterator

import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI
from mcp.server import MCPServer  # was: mcp.server.fastmcp.FastMCP

from .tracing import TraceASGIMiddleware, WireTracer

load_dotenv()

wire = WireTracer("server", os.getenv("MCP_SERVER_TRACE", "traces/server.jsonl"))

# v2: MCPServer's constructor only handles identity + auth now.
# Transport behavior (json_response, stateless_http, streamable_http_path)
# moved to streamable_http_app() below.
mcp = MCPServer(
    "MCP Lifecycle Studio",
    instructions="A learning server that exposes every lifecycle exchange.",
)


@mcp.tool()
def add(a: float, b: float) -> dict[str, float]:
    """Add two numbers."""
    return {"a": a, "b": b, "sum": a + b}


@mcp.tool()
def echo(message: str) -> dict[str, str]:
    """Echo a message back to the caller."""
    return {"echo": message}


# ⚠️ stateless_http still exists as an option in v2, but its exact meaning
# under the new spec (whether it governs legacy-client session bookkeeping
# specifically, vs. something broader) I could not fully verify — the docs'
# CORS example still references Mcp-Session-Id and a session-ending DELETE,
# implying the SDK keeps session plumbing around for 2025-11-25 clients even
# under v2. stateless_http=True is the closer match to "target the current
# spec"; check https://py.sdk.modelcontextprotocol.io/v2/run/legacy-clients/
# before treating this as settled.
streamable_app = mcp.streamable_http_app(
    json_response=True,
    stateless_http=True,
    streamable_http_path="/",
)


@contextlib.asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    wire.record(
        layer="application",
        direction="local",
        event="server startup",
        data={"mcp_endpoint": "/mcp"},
    )
    # Unchanged in v2: the host app still owns mcp.session_manager's lifespan.
    async with mcp.session_manager.run():
        yield
    wire.record(
        layer="application",
        direction="local",
        event="server shutdown",
        data={"reason": "ASGI lifespan ended"},
    )


app = FastAPI(
    title="MCP Lifecycle Studio",
    description="FastAPI host for a fully traced MCP Streamable HTTP server.",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


app.mount("/mcp", TraceASGIMiddleware(streamable_app, wire))


def main() -> None:
    uvicorn.run(
        "mcp_studio.server:app",
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8000")),
        reload=False,
    )


if __name__ == "__main__":
    main()