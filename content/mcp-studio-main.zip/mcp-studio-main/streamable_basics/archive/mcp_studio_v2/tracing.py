"""Transport-level tracing that automatically covers every current and future call."""

from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from collections import deque
from collections.abc import Awaitable, Callable
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel

logger = logging.getLogger("mcp_studio.wire")


def _jsonable(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)
    if hasattr(value, "message"):
        return _jsonable(value.message)
    if isinstance(value, bytes):
        try:
            return json.loads(value)
        except (UnicodeDecodeError, json.JSONDecodeError):
            return value.decode("utf-8", errors="replace")
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


@dataclass(slots=True)
class TraceEvent:
    sequence: int
    timestamp: str
    elapsed_ms: float
    side: str
    layer: str
    direction: str
    event: str
    correlation_id: str
    data: Any


class WireTracer:
    """Structured console + JSONL event recorder.

    One recorder call lives at each transport boundary, so adding tools, resources,
    prompts, notifications, or custom JSON-RPC calls requires no new tracing code.
    """

    def __init__(self, side: str, output: str | Path | None = None) -> None:
        self.side = side
        self.output = Path(output) if output else None
        self._sequence = 0
        self._started = time.perf_counter()

    def record(
        self,
        *,
        layer: str,
        direction: str,
        event: str,
        data: Any,
        correlation_id: str | None = None,
    ) -> TraceEvent:
        self._sequence += 1
        payload = _jsonable(data)
        correlation_id = correlation_id or _correlation_id(payload)
        trace = TraceEvent(
            sequence=self._sequence,
            timestamp=datetime.now(timezone.utc).isoformat(),
            elapsed_ms=round((time.perf_counter() - self._started) * 1000, 3),
            side=self.side,
            layer=layer,
            direction=direction,
            event=event,
            correlation_id=correlation_id,
            data=payload,
        )
        encoded = json.dumps(asdict(trace), indent=2, ensure_ascii=False, default=str)
        print(encoded, file=sys.stderr, flush=True)
        if self.output:
            self.output.parent.mkdir(parents=True, exist_ok=True)
            with self.output.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(asdict(trace), ensure_ascii=False, default=str) + "\n")
        return trace


# def _correlation_id(data: Any) -> str:
#     if isinstance(data, dict):
#         rpc_id = data.get("id")
#         if rpc_id is not None:
#             return f"jsonrpc:{rpc_id}"
#         headers = data.get("headers", {})
#         if isinstance(headers, dict):
#             session = headers.get("mcp-session-id")
#             if session:
#                 return f"session:{session}"
#     return f"event:{uuid.uuid4().hex[:12]}"

def _correlation_id(data: Any) -> str:
    if isinstance(data, dict):
        rpc_id = data.get("id")
        if rpc_id is not None:
            return f"jsonrpc:{rpc_id}"
        # Removed: the old `headers.get("mcp-session-id")` branch. There's
        # no protocol-level session under 2026-07-28, so a session ID is no
        # longer a reliable correlation key — it may not exist on the wire
        # at all for a modern client. Mcp-Method/Mcp-Name headers are
        # already visible at the HTTP layer via TraceASGIMiddleware, so
        # nothing is lost by dropping this branch.
    return f"event:{uuid.uuid4().hex[:12]}"


class TracedReceiveStream:
    """Transparent proxy for the SDK's incoming AnyIO object stream."""

    def __init__(self, stream: Any, tracer: WireTracer) -> None:
        self._stream = stream
        self._tracer = tracer

    async def receive(self) -> Any:
        item = await self._stream.receive()
        self._record(item)
        return item

    def __aiter__(self) -> "TracedReceiveStream":
        return self

    async def __anext__(self) -> Any:
        item = await self._stream.__anext__()
        self._record(item)
        return item

    def _record(self, item: Any) -> None:
        self._tracer.record(
            layer="jsonrpc", direction="server -> client", event="receive", data=item
        )

    async def __aenter__(self) -> "TracedReceiveStream":
        await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        return await self._stream.__aexit__(*args)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


class TracedSendStream:
    """Transparent proxy for the SDK's outgoing AnyIO object stream."""

    def __init__(self, stream: Any, tracer: WireTracer) -> None:
        self._stream = stream
        self._tracer = tracer

    async def send(self, item: Any) -> None:
        self._tracer.record(
            layer="jsonrpc", direction="client -> server", event="send", data=item
        )
        await self._stream.send(item)

    async def __aenter__(self) -> "TracedSendStream":
        await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        return await self._stream.__aexit__(*args)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


class TraceASGIMiddleware:
    """Capture raw HTTP requests and responses without knowing MCP methods."""

    def __init__(self, app: Any, tracer: WireTracer) -> None:
        self.app = app
        self.tracer = tracer

    async def __call__(
        self,
        scope: dict[str, Any],
        receive: Callable[[], Awaitable[dict[str, Any]]],
        send: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request_chunks: list[bytes] = []
        response_chunks: list[bytes] = []
        response_start: dict[str, Any] = {}

        buffered_messages: deque[dict[str, Any]] = deque()
        while True:
            message = await receive()
            buffered_messages.append(message)
            if message["type"] != "http.request":
                break
            request_chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                break

        self.tracer.record(
            layer="http",
            direction="client -> server",
            event=f'{scope["method"]} {scope["path"]}',
            data={
                "method": scope["method"],
                "path": scope["path"],
                "headers": _headers(scope.get("headers", [])),
                "body": b"".join(request_chunks),
            },
        )

        async def traced_receive() -> dict[str, Any]:
            return buffered_messages.popleft() if buffered_messages else await receive()

        async def traced_send(message: dict[str, Any]) -> None:
            if message["type"] == "http.response.start":
                response_start.update(message)
            elif message["type"] == "http.response.body":
                response_chunks.append(message.get("body", b""))
                if not message.get("more_body", False):
                    self.tracer.record(
                        layer="http",
                        direction="server -> client",
                        event=f'HTTP {response_start.get("status", "?")}',
                        data={
                            "status": response_start.get("status"),
                            "headers": _headers(response_start.get("headers", [])),
                            "body": b"".join(response_chunks),
                        },
                    )
            await send(message)

        await self.app(scope, traced_receive, traced_send)


def _headers(raw_headers: list[tuple[bytes, bytes]]) -> dict[str, str]:
    show_secrets = os.getenv("MCP_TRACE_SHOW_SECRETS", "").lower() in {"1", "true", "yes"}
    sensitive = {"authorization", "cookie", "set-cookie", "proxy-authorization"}
    result: dict[str, str] = {}
    for raw_name, raw_value in raw_headers:
        name = raw_name.decode("latin-1").lower()
        value = raw_value.decode("latin-1")
        result[name] = value if show_secrets or name not in sensitive else "<redacted>"
    return result
