"""MCP client that demonstrates the complete lifecycle."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from typing import Any

from dotenv import load_dotenv
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

load_dotenv()


async def run_lifecycle(url: str, tool: str,
                        arguments: dict[str, Any]) -> None:
    # Closing these contexts performs the Streamable HTTP session teardown.
    async with streamable_http_client(url) as (read, write, get_session_id):
        async with ClientSession(read, write) as session:
            initialized = await session.initialize()
            mcp_session_id = get_session_id()
            tools = await session.list_tools()
            result = await session.call_tool(tool, arguments=arguments)

            print(
                json.dumps(
                    {
                        "server": initialized.serverInfo.model_dump(
                            mode="json", by_alias=True
                        ),
                        "mcp_session_id": mcp_session_id,
                        "available_tools": [item.name for item in tools.tools],
                        "called": tool,
                        "result": result.model_dump(
                            mode="json", by_alias=True, exclude_none=True
                        ),
                    },
                    indent=2,
                )
            )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--url",
        default=os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp/"),
    )
    parser.add_argument("--tool", default=os.getenv("MCP_TOOL", "add"))
    parser.add_argument(
        "--arguments",
        default=os.getenv("MCP_TOOL_ARGUMENTS", '{"a": 20, "b": 22}'),
        type=json.loads,
        help="Tool arguments as JSON",
    )
    return parser


def main() -> None:
    args = _parser().parse_args()
    asyncio.run(run_lifecycle(args.url, args.tool, args.arguments))


if __name__ == "__main__":
    main()
