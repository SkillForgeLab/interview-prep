"""FastAPI-hosted MCP server."""

from __future__ import annotations

import contextlib
import os
from collections.abc import AsyncIterator

import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI
from mcp.server.fastmcp import FastMCP

from mcp_studio.debug.request_inspector import InspectRequestMiddleware

# Load local configuration before module-level settings are constructed.
# Existing shell variables take precedence over values in .env.
load_dotenv()

mcp = FastMCP(
    "MCP Lifecycle Studio",
    instructions="An MCP server that demonstrates the client/server lifecycle.",
    json_response=True,
    stateless_http=False,
    # FastAPI provides the external /mcp mount; keep the nested MCP app at root.
    streamable_http_path="/",
)


@mcp.tool()
def add(a: float, b: float) -> dict[str, float]:
    """Add two numbers."""
    return {"a": a, "b": b, "sum": a + b}


@mcp.tool()
def echo(message: str) -> dict[str, str]:
    """Echo a message back to the caller."""
    return {"echo": message}


@contextlib.asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    async with mcp.session_manager.run():
        yield


app = FastAPI(
    title="MCP Lifecycle Studio",
    description="FastAPI host for an MCP Streamable HTTP server.",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


app.mount("/mcp", InspectRequestMiddleware(mcp.streamable_http_app()))


def main() -> None:
    uvicorn.run(
        "mcp_studio.foundation.server:app",
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8000")),
        reload=False,
    )


if __name__ == "__main__":
    main()
