"""Core MCP client and server example."""

__version__ = "0.1.0"
