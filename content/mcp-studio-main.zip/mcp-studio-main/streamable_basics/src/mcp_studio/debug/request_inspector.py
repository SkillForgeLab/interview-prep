from typing import Any


class InspectRequestMiddleware:
    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # ASGI preserves duplicate header entries and their byte values. The HTTP
        # server may normalize header-name casing before constructing the scope.
        print("REQUEST", scope["method"], scope.get("raw_path", scope["path"]))
        print("HEADERS")
        for name, value in scope["headers"]:
            print(f"{name!r}: {value!r}")

        body = bytearray()

        async def inspect_receive():
            message = await receive()

            if message["type"] == "http.request":
                chunk = message.get("body", b"")
                body.extend(chunk)
                print("BODY CHUNK", chunk)
                print("MORE BODY", message.get("more_body", False))
                if not message.get("more_body", False):
                    print("BODY", bytes(body))

            return message

        await self.app(scope, inspect_receive, send)
