from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

import pytest

from mcp_studio.debug.request_inspector import InspectRequestMiddleware


@pytest.mark.asyncio
async def test_inspector_forwards_and_reconstructs_chunked_body(capsys) -> None:
    messages = iter(
        [
            {
                "type": "http.request",
                "body": b'{"json',
                "more_body": True,
            },
            {
                "type": "http.request",
                "body": b'rpc":"2.0"}',
                "more_body": False,
            },
        ]
    )
    received: list[dict[str, Any]] = []

    async def receive() -> dict[str, Any]:
        return next(messages)

    async def send(_: dict[str, Any]) -> None:
        pass

    async def downstream(
        _: dict[str, Any],
        downstream_receive: Callable[[], Awaitable[dict[str, Any]]],
        __: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        received.append(await downstream_receive())
        received.append(await downstream_receive())

    scope = {
        "type": "http",
        "method": "POST",
        "path": "/",
        "raw_path": b"/mcp/",
        "headers": [(b"content-type", b"application/json")],
    }

    await InspectRequestMiddleware(downstream)(scope, receive, send)

    assert received[0]["body"] == b'{"json'
    assert received[1]["body"] == b'rpc":"2.0"}'
    assert "BODY b'{\"jsonrpc\":\"2.0\"}'" in capsys.readouterr().out


@pytest.mark.asyncio
async def test_inspector_passes_through_non_http_scope() -> None:
    called = False

    async def downstream(scope, receive, send) -> None:
        nonlocal called
        called = True
        assert scope["type"] == "lifespan"

    middleware = InspectRequestMiddleware(downstream)
    await middleware({"type": "lifespan"}, None, None)

    assert called
